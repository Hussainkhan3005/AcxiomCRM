using AcxiomCRM.Common;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Data;

/// <summary>
/// Creates the database, the three roles, demo users and (optionally) sample CRM data.
/// Demo passwords come from configuration (appsettings.Development.json) - change them for any real deployment.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services, IConfiguration config)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        await db.Database.EnsureCreatedAsync();

        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var role in AppRoles.All)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        var seed = config.GetSection("Seed");
        if (!seed.GetValue("Enabled", true)) return;

        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var adminPassword = seed["AdminPassword"] ?? "Admin@123";
        var managerPassword = seed["ManagerPassword"] ?? "Manager@123";
        var salesPassword = seed["SalesPassword"] ?? "Sales@123";

        await EnsureUserAsync(userManager, "admin@acxiomcrm.com", "System Administrator", AppRoles.Admin, adminPassword, null);
        var manager = await EnsureUserAsync(userManager, "manager@acxiomcrm.com", "Priya Sharma", AppRoles.Manager, managerPassword, null);
        var sales1 = await EnsureUserAsync(userManager, "sales1@acxiomcrm.com", "Ravi Kumar", AppRoles.SalesExecutive, salesPassword, manager.Id);
        var sales2 = await EnsureUserAsync(userManager, "sales2@acxiomcrm.com", "Anita Reddy", AppRoles.SalesExecutive, salesPassword, manager.Id);

        if (!seed.GetValue("SampleData", true) || await db.Customers.AnyAsync()) return;
        await SeedSampleDataAsync(db, manager, sales1, sales2);
    }

    private static async Task<ApplicationUser> EnsureUserAsync(UserManager<ApplicationUser> userManager, string email,
        string fullName, string role, string password, string? managerId)
    {
        var user = await userManager.FindByEmailAsync(email);
        if (user is not null) return user;

        user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            FullName = fullName,
            IsActive = true,
            CreatedDate = DateTime.Now,
            ManagerId = managerId
        };

        var result = await userManager.CreateAsync(user, password);
        if (!result.Succeeded)
            throw new InvalidOperationException($"Could not create seed user {email}: {string.Join("; ", result.Errors.Select(e => e.Description))}");

        await userManager.AddToRoleAsync(user, role);
        return user;
    }

    private static async Task SeedSampleDataAsync(ApplicationDbContext db, ApplicationUser manager, ApplicationUser sales1, ApplicationUser sales2)
    {
        var today = DateTime.Today;
        var owners = new[] { sales1, sales2, manager };

        // ---------- Customers ----------
        var companies = new (string Company, string Contact, string City, string State)[]
        {
            ("Sunrise Textiles Pvt Ltd", "Arjun Mehta", "Surat", "Gujarat"),
            ("BlueWave Logistics", "Kavya Nair", "Kochi", "Kerala"),
            ("Greenfield Agro Foods", "Suresh Patil", "Pune", "Maharashtra"),
            ("Vertex Software Solutions", "Meera Iyer", "Bengaluru", "Karnataka"),
            ("Coastal Pharma Ltd", "Rahul Verma", "Chennai", "Tamil Nadu"),
            ("Metro Builders & Co", "Sneha Gupta", "Hyderabad", "Telangana"),
            ("Nova Electronics", "Vikram Singh", "Noida", "Uttar Pradesh"),
            ("Pinnacle Foods", "Lakshmi Rao", "Vijayawada", "Andhra Pradesh"),
            ("Orbit Telecom Services", "Imran Khan", "Kolkata", "West Bengal"),
            ("Silverline Motors", "Deepa Joshi", "Jaipur", "Rajasthan")
        };

        var customers = new List<Customer>();
        for (var i = 0; i < companies.Length; i++)
        {
            var (company, contact, city, state) = companies[i];
            var owner = owners[i % 3];
            customers.Add(new Customer
            {
                CustomerCode = $"CUS-{i + 1:D5}",
                CustomerName = contact,
                CompanyName = company,
                Email = $"{contact.Split(' ')[0].ToLowerInvariant()}.{i + 1}@example.com",
                Phone = $"98765{43210 + i}",
                Address = $"{12 + i * 7}, Industrial Area Road",
                City = city,
                State = state,
                Status = i == 9 ? CustomerStatus.Inactive : (i == 8 ? CustomerStatus.Prospect : CustomerStatus.Active),
                AssignedTo = owner.Id,
                CreatedBy = owner.UserName!,
                CreatedDate = today.AddDays(-(150 - i * 12))
            });
        }
        db.Customers.AddRange(customers);
        await db.SaveChangesAsync();

        // ---------- Leads ----------
        var leadSeeds = new (string Name, string Company, LeadSource Source, LeadStatus Status, LeadPriority Priority, decimal Value)[]
        {
            ("Arjun Mehta", "Sunrise Textiles Pvt Ltd", LeadSource.Referral, LeadStatus.Converted, LeadPriority.High, 850000),
            ("Kavya Nair", "BlueWave Logistics", LeadSource.Website, LeadStatus.Converted, LeadPriority.Medium, 420000),
            ("Nikhil Bose", "Aurora Hospitality", LeadSource.Website, LeadStatus.New, LeadPriority.Medium, 300000),
            ("Fatima Sheikh", "Crescent Retail", LeadSource.SocialMedia, LeadStatus.Contacted, LeadPriority.High, 650000),
            ("Rohit Agarwal", "Agarwal Steels", LeadSource.ColdCall, LeadStatus.Qualified, LeadPriority.High, 1200000),
            ("Pooja Menon", "Menon Diagnostics", LeadSource.Event, LeadStatus.Qualified, LeadPriority.Medium, 500000),
            ("Sanjay Kulkarni", "Kulkarni Exports", LeadSource.Email, LeadStatus.Lost, LeadPriority.Low, 150000),
            ("Ayesha Siddiqui", "Bright Minds Academy", LeadSource.Advertisement, LeadStatus.New, LeadPriority.Low, 90000),
            ("Harish Chandra", "Chandra Infra", LeadSource.Referral, LeadStatus.Contacted, LeadPriority.Medium, 780000),
            ("Neha Kapoor", "Kapoor Fashion House", LeadSource.Website, LeadStatus.Unqualified, LeadPriority.Low, 60000),
            ("Gautam Das", "Das Fisheries", LeadSource.Other, LeadStatus.New, LeadPriority.Medium, 220000),
            ("Ritu Malhotra", "Malhotra Clinics", LeadSource.Event, LeadStatus.Contacted, LeadPriority.High, 940000)
        };

        var leads = new List<Lead>();
        for (var i = 0; i < leadSeeds.Length; i++)
        {
            var s = leadSeeds[i];
            var owner = owners[i % 3];
            var lead = new Lead
            {
                LeadCode = $"LEAD-{i + 1:D5}",
                LeadName = s.Name,
                CompanyName = s.Company,
                Email = $"{s.Name.Split(' ')[0].ToLowerInvariant()}@prospect{i + 1}.example.com",
                Phone = $"91234{56700 + i}",
                Source = s.Source,
                Status = s.Status,
                Priority = s.Priority,
                ExpectedValue = s.Value,
                AssignedTo = owner.Id,
                CreatedBy = owner.UserName!,
                CreatedDate = today.AddDays(-(100 - i * 7))
            };
            if (s.Status == LeadStatus.Converted)
            {
                lead.ConvertedCustomerId = customers[i].CustomerId;
                lead.AssignedTo = customers[i].AssignedTo;
                lead.ConvertedDate = lead.CreatedDate.AddDays(10);
            }
            leads.Add(lead);
        }
        db.Leads.AddRange(leads);
        await db.SaveChangesAsync();

        // ---------- Opportunities ----------
        var oppSeeds = new (string Name, int Customer, OpportunityStage Stage, decimal Amount, int Probability, int CloseOffsetDays)[]
        {
            ("Uniform supply contract", 0, OpportunityStage.Won, 850000, 100, -150),
            ("Fleet tracking rollout", 1, OpportunityStage.Won, 420000, 100, -120),
            ("Cold storage expansion", 2, OpportunityStage.Negotiation, 1500000, 75, 20),
            ("ERP implementation", 3, OpportunityStage.Proposal, 2400000, 50, 35),
            ("Annual maintenance", 4, OpportunityStage.Won, 320000, 100, -90),
            ("Site safety systems", 5, OpportunityStage.Qualification, 980000, 20, 60),
            ("Component sourcing", 6, OpportunityStage.Lost, 610000, 0, -60),
            ("Distribution partnership", 7, OpportunityStage.Won, 730000, 100, -45),
            ("Network upgrade", 8, OpportunityStage.Proposal, 1250000, 50, 45),
            ("Dealer software", 3, OpportunityStage.Won, 560000, 100, -20),
            ("Warehouse automation", 1, OpportunityStage.Negotiation, 1800000, 75, 15),
            ("Packaging redesign", 2, OpportunityStage.Lost, 270000, 0, -10),
            ("Clinic CRM pilot", 4, OpportunityStage.Qualification, 450000, 20, 75)
        };

        var opportunities = new List<Opportunity>();
        foreach (var s in oppSeeds)
        {
            var customer = customers[s.Customer];
            var closed = OpportunityWorkflow.IsClosed(s.Stage);
            var closeDate = today.AddDays(s.CloseOffsetDays);
            opportunities.Add(new Opportunity
            {
                OpportunityName = s.Name,
                CustomerId = customer.CustomerId,
                LeadId = s.Customer < 2 && s.Stage == OpportunityStage.Won ? leads[s.Customer].LeadId : null,
                Amount = s.Amount,
                Stage = s.Stage,
                Status = OpportunityWorkflow.StatusFor(s.Stage),
                Probability = s.Probability,
                ExpectedCloseDate = closeDate,
                ClosedDate = closed ? closeDate : null,
                Source = "Direct",
                AssignedTo = customer.AssignedTo,
                CreatedBy = customer.CreatedBy,
                CreatedDate = closed ? closeDate.AddDays(-40) : today.AddDays(-25)
            });
        }
        db.Opportunities.AddRange(opportunities);
        await db.SaveChangesAsync();

        leads[0].ConvertedOpportunityId = opportunities[0].OpportunityId;
        leads[1].ConvertedOpportunityId = opportunities[1].OpportunityId;

        // ---------- Follow-ups ----------
        var now = DateTime.Now;
        var followUps = new List<FollowUp>
        {
            NewFollowUp("Discuss revised quotation", FollowUpType.Call, today.AddDays(1).AddHours(11), customers[2], opportunities[2], FollowUpStatus.Planned),
            NewFollowUp("Product demo for ERP", FollowUpType.Meeting, today.AddDays(3).AddHours(15), customers[3], opportunities[3], FollowUpStatus.Planned),
            NewFollowUp("Send safety compliance brochure", FollowUpType.Email, today.AddHours(17), customers[5], opportunities[5], FollowUpStatus.Planned),
            NewFollowUp("Contract signing visit", FollowUpType.Visit, today.AddDays(6).AddHours(10), customers[1], opportunities[10], FollowUpStatus.Planned),
            NewFollowUp("Check budget approval", FollowUpType.Call, today.AddDays(-2).AddHours(12), customers[8], opportunities[8], FollowUpStatus.Planned),
            NewFollowUp("Quarterly review", FollowUpType.Meeting, today.AddDays(-12).AddHours(14), customers[4], null, FollowUpStatus.Completed),
            NewFollowUp("Renewal reminder", FollowUpType.Call, today.AddDays(-6).AddHours(10), customers[7], null, FollowUpStatus.Missed)
        };
        followUps.Add(new FollowUp
        {
            Subject = "Introductory call",
            FollowUpType = FollowUpType.Call,
            FollowUpDate = today.AddDays(2).AddHours(10),
            LeadId = leads[2].LeadId,
            Status = FollowUpStatus.Planned,
            AssignedTo = leads[2].AssignedTo,
            CreatedBy = "seed",
            CreatedDate = now
        });
        followUps.Add(new FollowUp
        {
            Subject = "Share pricing sheet",
            FollowUpType = FollowUpType.Email,
            FollowUpDate = today.AddDays(-1).AddHours(16),
            LeadId = leads[3].LeadId,
            Status = FollowUpStatus.Planned,
            AssignedTo = leads[3].AssignedTo,
            CreatedBy = "seed",
            CreatedDate = now
        });
        db.FollowUps.AddRange(followUps);

        // ---------- Activities ----------
        var activities = new List<Activity>
        {
            NewActivity(ActivityType.Call, "Requirement discussion", today.AddDays(-14).AddHours(11), customers[2], ActivityStatus.Completed),
            NewActivity(ActivityType.Meeting, "Kick-off meeting", today.AddDays(-10).AddHours(15), customers[3], ActivityStatus.Completed),
            NewActivity(ActivityType.Email, "Sent proposal document", today.AddDays(-7).AddHours(10), customers[8], ActivityStatus.Completed),
            NewActivity(ActivityType.Task, "Prepare commercial terms", today.AddDays(2).AddHours(12), customers[1], ActivityStatus.Planned),
            NewActivity(ActivityType.Call, "Payment follow-up", today.AddDays(-3).AddHours(16), customers[0], ActivityStatus.Completed),
            NewActivity(ActivityType.Meeting, "Site survey", today.AddDays(4).AddHours(10), customers[5], ActivityStatus.Planned)
        };
        db.Activities.AddRange(activities);

        await db.SaveChangesAsync();

        FollowUp NewFollowUp(string subject, FollowUpType type, DateTime date, Customer customer, Opportunity? opportunity, FollowUpStatus status) => new()
        {
            Subject = subject,
            FollowUpType = type,
            FollowUpDate = date,
            CustomerId = customer.CustomerId,
            OpportunityId = opportunity?.OpportunityId,
            Status = status,
            CompletedDate = status == FollowUpStatus.Completed ? date : null,
            AssignedTo = customer.AssignedTo,
            CreatedBy = "seed",
            CreatedDate = now
        };

        Activity NewActivity(ActivityType type, string subject, DateTime date, Customer customer, ActivityStatus status) => new()
        {
            ActivityType = type,
            Subject = subject,
            ActivityDate = date,
            CustomerId = customer.CustomerId,
            Status = status,
            AssignedTo = customer.AssignedTo,
            CreatedBy = "seed",
            CreatedDate = now
        };
    }
}
