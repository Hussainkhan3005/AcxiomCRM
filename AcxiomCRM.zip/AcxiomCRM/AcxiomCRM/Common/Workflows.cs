using AcxiomCRM.Models;

namespace AcxiomCRM.Common;

/// <summary>Allowed lead status transitions. "Converted" can only be reached through the Convert action.</summary>
public static class LeadWorkflow
{
    private static readonly Dictionary<LeadStatus, LeadStatus[]> Allowed = new()
    {
        [LeadStatus.New] = new[] { LeadStatus.Contacted, LeadStatus.Unqualified, LeadStatus.Lost },
        [LeadStatus.Contacted] = new[] { LeadStatus.Qualified, LeadStatus.Unqualified, LeadStatus.Lost },
        [LeadStatus.Qualified] = new[] { LeadStatus.Contacted, LeadStatus.Unqualified, LeadStatus.Lost },
        [LeadStatus.Unqualified] = new[] { LeadStatus.Contacted, LeadStatus.Lost },
        [LeadStatus.Lost] = new[] { LeadStatus.New },
        [LeadStatus.Converted] = Array.Empty<LeadStatus>()
    };

    public static readonly LeadStatus[] CreatableStatuses = { LeadStatus.New, LeadStatus.Contacted, LeadStatus.Qualified };
    public static readonly LeadStatus[] OpenStatuses = { LeadStatus.New, LeadStatus.Contacted, LeadStatus.Qualified };

    public static bool CanTransition(LeadStatus current, LeadStatus target) =>
        current == target || (Allowed.TryGetValue(current, out var next) && next.Contains(target));

    public static IEnumerable<LeadStatus> AvailableFrom(LeadStatus current) =>
        new[] { current }.Concat(Allowed[current]);
}

public static class OpportunityWorkflow
{
    public static readonly OpportunityStage[] OpenStages =
        { OpportunityStage.Qualification, OpportunityStage.Proposal, OpportunityStage.Negotiation };

    public static bool IsClosed(OpportunityStage stage) => stage is OpportunityStage.Won or OpportunityStage.Lost;

    /// <summary>Won/Lost are final; open stages can move freely (forwards or backwards).</summary>
    public static bool CanTransition(OpportunityStage current, OpportunityStage target) => current == target || !IsClosed(current);

    public static OpportunityStatus StatusFor(OpportunityStage stage) => stage switch
    {
        OpportunityStage.Won => OpportunityStatus.Won,
        OpportunityStage.Lost => OpportunityStatus.Lost,
        _ => OpportunityStatus.Open
    };

    public static int DefaultProbability(OpportunityStage stage) => stage switch
    {
        OpportunityStage.Qualification => 20,
        OpportunityStage.Proposal => 50,
        OpportunityStage.Negotiation => 75,
        OpportunityStage.Won => 100,
        _ => 0
    };
}

public static class FollowUpWorkflow
{
    /// <summary>Planned can be completed/missed/cancelled; a missed follow-up can be rescheduled (Planned) or completed.</summary>
    public static bool CanTransition(FollowUpStatus current, FollowUpStatus target) => current == target || current switch
    {
        FollowUpStatus.Planned => target is FollowUpStatus.Completed or FollowUpStatus.Missed or FollowUpStatus.Cancelled,
        FollowUpStatus.Missed => target is FollowUpStatus.Planned or FollowUpStatus.Completed or FollowUpStatus.Cancelled,
        _ => false
    };

    public static IEnumerable<FollowUpStatus> AvailableFrom(FollowUpStatus current) =>
        Enum.GetValues<FollowUpStatus>().Where(s => CanTransition(current, s));
}
