using System.Globalization;

namespace AcxiomCRM.Common;

public static class UiHelpers
{
    private static readonly CultureInfo India = CultureInfo.GetCultureInfo("en-IN");

    /// <summary>Indian currency format, e.g. ₹12,50,000.</summary>
    public static string Money(decimal amount) => amount.ToString("C0", India);

    public static string Number(decimal amount) => amount.ToString("N0", India);

    public static string Date(DateTime? date) => date?.ToString("dd MMM yyyy", India) ?? "-";

    public static string DateAndTime(DateTime? date) => date?.ToString("dd MMM yyyy, hh:mm tt", India) ?? "-";

    /// <summary>Bootstrap badge classes for statuses and stages.</summary>
    public static string BadgeClass(object? status) => status?.ToString() switch
    {
        "Active" or "Won" or "Completed" or "Converted" or "Success" or "Qualified"
            => "badge-soft badge-good",
        "Lost" or "Missed" or "Failure" or "High" or "Overdue" or "Locked"
            => "badge-soft badge-bad",
        "Negotiation" or "Medium" or "Contacted" or "Prospect"
            => "badge-soft badge-warm",
        "New" or "Planned" or "Qualification" or "Proposal"
            => "badge-soft badge-info",
        _ => "badge-soft badge-muted"
    };

    public static string ActivityIcon(object? type) => type?.ToString() switch
    {
        "Call" => "bi-telephone",
        "Meeting" => "bi-people",
        "Email" => "bi-envelope",
        "Visit" => "bi-geo-alt",
        "Task" => "bi-check2-square",
        _ => "bi-dot"
    };
}
