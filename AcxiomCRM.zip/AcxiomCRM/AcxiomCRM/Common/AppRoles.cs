namespace AcxiomCRM.Common;

public static class AppRoles
{
    public const string Admin = "Admin";
    public const string Manager = "Manager";
    public const string SalesExecutive = "SalesExecutive";

    public const string AdminOrManager = Admin + "," + Manager;

    public static readonly string[] All = { Admin, Manager, SalesExecutive };

    public static string DisplayName(string? role) => role switch
    {
        SalesExecutive => "Sales Executive",
        null or "" => "-",
        _ => role
    };
}

public static class AuditActions
{
    public const string Login = "Login";
    public const string FailedLogin = "FailedLogin";
    public const string Lockout = "Lockout";
    public const string LockedOutAttempt = "LockedOutAttempt";
    public const string Logout = "Logout";
    public const string Register = "Register";
    public const string Create = "Create";
    public const string Update = "Update";
    public const string Delete = "Delete";
    public const string StatusChange = "StatusChange";
    public const string StageChange = "StageChange";
    public const string Convert = "Convert";
    public const string Complete = "Complete";
    public const string Missed = "Missed";
    public const string Reschedule = "Reschedule";
    public const string RoleChange = "RoleChange";
    public const string Activate = "Activate";
    public const string Deactivate = "Deactivate";
    public const string Unlock = "Unlock";
    public const string PasswordReset = "PasswordReset";
    public const string PasswordChange = "PasswordChange";

    public static readonly string[] All =
    {
        Login, FailedLogin, Lockout, LockedOutAttempt, Logout, Register, Create, Update, Delete,
        StatusChange, StageChange, Convert, Complete, Missed, Reschedule, RoleChange, Activate,
        Deactivate, Unlock, PasswordReset, PasswordChange
    };
}

public static class AuditResults
{
    public const string Success = "Success";
    public const string Failure = "Failure";
}

public static class AuditEntities
{
    public const string Account = "Account";
    public const string User = "User";
    public const string Customer = "Customer";
    public const string Lead = "Lead";
    public const string Opportunity = "Opportunity";
    public const string FollowUp = "FollowUp";
    public const string Activity = "Activity";

    /// <summary>Security-related modules that only Admins may see in the audit log.</summary>
    public static readonly string[] Security = { Account, User };

    public static readonly string[] All = { Account, User, Customer, Lead, Opportunity, FollowUp, Activity };
}
