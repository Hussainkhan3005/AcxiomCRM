namespace AcxiomCRM.Common;

/// <summary>
/// Central validation rules and messages. The same constants feed the data
/// annotations (client + server) and the explicit business checks in services.
/// </summary>
public static class ValidationRules
{
    // 10-digit Indian mobile number starting with 6-9.
    public const string PhonePattern = @"^[6-9][0-9]{9}$";
    public const string PhoneMessage = "Enter a valid phone number.";
    public const string PhoneHint = "10-digit mobile number, e.g. 9876543210";

    public const string EmailPattern = @"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$";
    public const string EmailMessage = "Enter a valid email address.";

    public const string PasswordPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$";
    public const string PasswordMessage = "Password must have at least 8 characters, with upper and lower case letters, a number and a special character.";

    public const string AmountMessage = "Opportunity Amount must be greater than 0.";
    public const string ProbabilityMessage = "Probability must be between 0 and 100.";
    public const string CloseDateMessage = "Expected Close Date cannot be in the past.";
    public const string FollowUpDateMessage = "Follow-up date cannot be earlier than today.";
    public const string ExpectedValueMessage = "Expected Value must be between 0 and 10,00,00,000.";

    public const int NameMaxLength = 100;
    public const int EmailMaxLength = 150;
    public const int CompanyMaxLength = 150;
    public const int SubjectMaxLength = 150;
    public const int NotesMaxLength = 1000;

    public const double MaxAmount = 10_000_000_000;      // 1,000 crore
    public const double MaxLeadValue = 100_000_000;      // 10 crore
}
