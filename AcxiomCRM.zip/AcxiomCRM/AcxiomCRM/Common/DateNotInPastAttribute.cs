using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace AcxiomCRM.Common;

/// <summary>
/// Rejects dates earlier than today. Works on the server (DataAnnotations) and in the
/// browser (jQuery unobtrusive adapter "datenotinpast" in wwwroot/js/validation.js).
///
/// The rule can be switched off depending on another property, e.g. an opportunity that
/// is already Won/Lost, or a follow-up that is Completed:
/// [DateNotInPast(IgnoreWhenProperty = nameof(Stage), IgnoreWhenValues = "Won,Lost")]
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class DateNotInPastAttribute : ValidationAttribute, IClientModelValidator
{
    public string? IgnoreWhenProperty { get; set; }
    public string? IgnoreWhenValues { get; set; }

    public DateNotInPastAttribute() : base("{0} cannot be in the past.") { }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is not DateTime date) return ValidationResult.Success;
        if (ShouldIgnore(validationContext.ObjectInstance)) return ValidationResult.Success;

        if (date.Date < DateTime.Today)
        {
            var members = validationContext.MemberName is null ? null : new[] { validationContext.MemberName };
            return new ValidationResult(FormatErrorMessage(validationContext.DisplayName), members);
        }
        return ValidationResult.Success;
    }

    private bool ShouldIgnore(object? instance)
    {
        if (instance is null || string.IsNullOrEmpty(IgnoreWhenProperty) || string.IsNullOrEmpty(IgnoreWhenValues))
            return false;

        var current = instance.GetType().GetProperty(IgnoreWhenProperty)?.GetValue(instance)?.ToString();
        if (current is null) return false;

        return IgnoreWhenValues
            .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Contains(current, StringComparer.OrdinalIgnoreCase);
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        Merge(context.Attributes, "data-val", "true");
        Merge(context.Attributes, "data-val-datenotinpast", FormatErrorMessage(context.ModelMetadata.GetDisplayName()));
        if (!string.IsNullOrEmpty(IgnoreWhenProperty))
        {
            Merge(context.Attributes, "data-val-datenotinpast-ignoreprop", IgnoreWhenProperty);
            Merge(context.Attributes, "data-val-datenotinpast-ignorevalues", IgnoreWhenValues ?? string.Empty);
        }
    }

    private static void Merge(IDictionary<string, string> attributes, string key, string value)
    {
        if (!attributes.ContainsKey(key)) attributes.Add(key, value);
    }
}
