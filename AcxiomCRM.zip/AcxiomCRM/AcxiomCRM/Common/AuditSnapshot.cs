using System.Reflection;
using System.Text.Json;

namespace AcxiomCRM.Common;

/// <summary>
/// Turns an entity into a JSON snapshot of its simple (scalar) properties for the audit log.
/// Navigation properties and anything security-sensitive are skipped.
/// </summary>
public static class AuditSnapshot
{
    private static readonly HashSet<string> Sensitive = new(StringComparer.OrdinalIgnoreCase)
    {
        "Password", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "Token",
        "ConfirmPassword", "NewPassword", "CurrentPassword", "TwoFactorEnabled"
    };

    private static readonly JsonSerializerOptions Options = new() { WriteIndented = false };

    public static string? ToJson(object? value)
    {
        if (value is null) return null;
        if (value is string text) return text;

        var snapshot = new Dictionary<string, object?>();
        foreach (var property in value.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            if (!property.CanRead || property.GetIndexParameters().Length > 0) continue;
            if (Sensitive.Contains(property.Name)) continue;

            var type = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
            var isSimple = type.IsPrimitive || type.IsEnum || type == typeof(string) || type == typeof(decimal)
                           || type == typeof(DateTime) || type == typeof(Guid);
            if (!isSimple) continue;

            var propertyValue = property.GetValue(value);
            snapshot[property.Name] = type.IsEnum ? propertyValue?.ToString() : propertyValue;
        }

        return JsonSerializer.Serialize(snapshot, Options);
    }
}
