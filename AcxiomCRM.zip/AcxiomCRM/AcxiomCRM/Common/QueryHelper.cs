using Microsoft.AspNetCore.Http;

namespace AcxiomCRM.Common;

/// <summary>Builds list-page URLs that keep the current filters while changing page or sort.</summary>
public static class QueryHelper
{
    public static string With(HttpRequest request, params (string Key, string? Value)[] overrides)
    {
        var values = request.Query.ToDictionary(q => q.Key, q => (string?)q.Value.ToString(), StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in overrides)
        {
            if (string.IsNullOrEmpty(value)) values.Remove(key);
            else values[key] = value;
        }

        var query = QueryString.Create(values.Where(v => !string.IsNullOrEmpty(v.Value)));
        return (request.PathBase + request.Path) + query;
    }

    public static string SortLink(HttpRequest request, string? currentSort, string column)
    {
        var next = string.Equals(currentSort, column, StringComparison.OrdinalIgnoreCase) ? column + "_desc" : column;
        return With(request, ("sort", next), ("page", null));
    }

    public static string SortIcon(string? currentSort, string column)
    {
        if (string.Equals(currentSort, column, StringComparison.OrdinalIgnoreCase)) return "bi-caret-up-fill";
        if (string.Equals(currentSort, column + "_desc", StringComparison.OrdinalIgnoreCase)) return "bi-caret-down-fill";
        return "bi-chevron-expand text-muted";
    }
}
