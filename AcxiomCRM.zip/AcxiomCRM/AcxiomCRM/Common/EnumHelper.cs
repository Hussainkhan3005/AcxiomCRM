using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AcxiomCRM.Common;

public static class EnumHelper
{
    public static string DisplayName(this Enum value)
    {
        var member = value.GetType().GetMember(value.ToString()).FirstOrDefault();
        var name = member?.GetCustomAttribute<DisplayAttribute>()?.GetName();
        return name ?? Regex.Replace(value.ToString(), "(?<!^)([A-Z])", " $1");
    }

    /// <summary>
    /// Select list whose option values are enum NAMES (e.g. "Won"), so client-side rules
    /// and server-side model binding agree.
    /// </summary>
    public static List<SelectListItem> SelectList<TEnum>(IEnumerable<TEnum>? only = null) where TEnum : struct, Enum
        => (only ?? Enum.GetValues<TEnum>())
            .Select(v => new SelectListItem(((Enum)(object)v).DisplayName(), v.ToString()))
            .ToList();
}
