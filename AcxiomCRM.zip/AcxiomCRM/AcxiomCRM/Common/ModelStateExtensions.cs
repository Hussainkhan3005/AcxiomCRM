using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace AcxiomCRM.Common;

public static class ModelStateExtensions
{
    public static void AddServiceErrors<T>(this ModelStateDictionary modelState, ServiceResult<T> result)
    {
        foreach (var (key, message) in result.Errors)
            modelState.AddModelError(key, message);
    }
}
