using AcxiomCRM.Models;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Common;

public class PagedResult<T>
{
    public PagedResult(IReadOnlyList<T> items, int page, int pageSize, int totalCount)
    {
        Items = items;
        Page = page;
        PageSize = pageSize;
        TotalCount = totalCount;
    }

    public IReadOnlyList<T> Items { get; }
    public int Page { get; }
    public int PageSize { get; }
    public int TotalCount { get; }
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasPrevious => Page > 1;
    public bool HasNext => Page < TotalPages;
    public int FirstItem => TotalCount == 0 ? 0 : (Page - 1) * PageSize + 1;
    public int LastItem => Math.Min(Page * PageSize, TotalCount);

    public PagerInfo Pager => new(Page, TotalPages, TotalCount, FirstItem, LastItem);

    public PagedResult<TOut> Map<TOut>(Func<T, TOut> map) =>
        new(Items.Select(map).ToList(), Page, PageSize, TotalCount);
}

/// <summary>Data for the shared _Pagination partial.</summary>
public record PagerInfo(int Page, int TotalPages, int TotalCount, int FirstItem, int LastItem);

public static class QueryableExtensions
{
    /// <summary>
    /// Row-level security filter. visibleUserIds == null means unrestricted (Admin).
    /// </summary>
    public static IQueryable<T> WhereVisible<T>(this IQueryable<T> query, List<string>? visibleUserIds)
        where T : class, IAssignable
        => visibleUserIds is null ? query : query.Where(x => visibleUserIds.Contains(x.AssignedTo));

    public static async Task<PagedResult<T>> ToPagedAsync<T>(this IQueryable<T> query, int page, int pageSize)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 5, 100);
        var total = await query.CountAsync();
        var items = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return new PagedResult<T>(items, page, pageSize, total);
    }

    /// <summary>Builds a parameterised LIKE pattern (case-insensitive on SQLite and SQL Server).</summary>
    public static string ToLikePattern(this string term) => "%" + term.Trim() + "%";
}
