using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Common;

/// <summary>
/// Outcome of a service operation. Errors are keyed by field name ("" = whole form),
/// so the same result can be shown inline in MVC views or returned as a 400/404/409 by the API.
/// </summary>
public class ServiceResult<T>
{
    public T? Data { get; private set; }
    public bool NotFound { get; private set; }
    public bool Conflict { get; private set; }
    public Dictionary<string, string> Errors { get; } = new(StringComparer.OrdinalIgnoreCase);

    public bool Succeeded => !NotFound && Errors.Count == 0;

    public ServiceResult<T> AddError(string key, string message, bool conflict = false)
    {
        if (!Errors.ContainsKey(key)) Errors[key] = message;
        if (conflict) Conflict = true;
        return this;
    }

    public ServiceResult<T> WithData(T data)
    {
        Data = data;
        return this;
    }

    /// <summary>Copies errors into another result (used when one service calls another).</summary>
    public void CopyErrorsTo<TOther>(ServiceResult<TOther> target)
    {
        foreach (var (key, message) in Errors) target.AddError(key, message, Conflict);
    }

    public static ServiceResult<T> Success(T data) => new ServiceResult<T>().WithData(data);
    public static ServiceResult<T> Missing() => new() { NotFound = true };
    public static ServiceResult<T> Failure(string key, string message, bool conflict = false) =>
        new ServiceResult<T>().AddError(key, message, conflict);
}

/// <summary>
/// Re-runs DataAnnotations validation inside the service layer, so business rules hold
/// even when a caller skips controller validation (defence in depth).
/// </summary>
public static class ServerValidator
{
    public static bool Validate<T>(object model, ServiceResult<T> result)
    {
        var errors = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(model, new ValidationContext(model), errors, validateAllProperties: true);
        foreach (var error in errors)
            result.AddError(error.MemberNames.FirstOrDefault() ?? string.Empty, error.ErrorMessage ?? "Invalid value.");
        return valid;
    }
}
