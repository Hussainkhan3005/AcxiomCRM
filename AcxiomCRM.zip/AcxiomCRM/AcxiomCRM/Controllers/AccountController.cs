using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace AcxiomCRM.Controllers;

public class AccountController : CrmController
{
    private readonly IAccountService _accounts;

    public AccountController(IAccountService accounts) => _accounts = accounts;

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Dashboard");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    [EnableRateLimiting("login")]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var outcome = await _accounts.SignInAsync(model.UserNameOrEmail, model.Password, model.RememberMe);
        switch (outcome.Status)
        {
            case LoginStatus.Success:
                if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                    return LocalRedirect(model.ReturnUrl);
                return RedirectToAction("Index", "Dashboard");

            case LoginStatus.LockedOut:
                return View("Lockout");

            case LoginStatus.Inactive:
                ModelState.AddModelError(string.Empty, "Your account has been deactivated. Contact an administrator.");
                break;

            default:
                // Same message for unknown user and wrong password, so accounts can't be enumerated.
                ModelState.AddModelError(string.Empty, "Invalid username/email or password.");
                break;
        }

        model.Password = string.Empty;
        return View(model);
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register()
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Dashboard");
        return View(new RegisterViewModel());
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    [EnableRateLimiting("login")]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var (result, _) = await _accounts.RegisterAsync(model.FullName, model.Email, model.Password);
        if (result.Succeeded)
        {
            Notify("Welcome to AcxiomCRM. Your account has been created.");
            return RedirectToAction("Index", "Dashboard");
        }

        foreach (var error in result.Errors)
        {
            var key = error.Code.Contains("Password", StringComparison.OrdinalIgnoreCase) ? nameof(model.Password)
                : error.Code.Contains("Email", StringComparison.OrdinalIgnoreCase) || error.Code.Contains("UserName", StringComparison.OrdinalIgnoreCase) ? nameof(model.Email)
                : string.Empty;
            ModelState.AddModelError(key, error.Description);
        }
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await _accounts.SignOutAsync(User);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await _accounts.ChangePasswordAsync(User, model.CurrentPassword, model.NewPassword);
        if (result.Succeeded)
        {
            Notify("Your password has been changed.");
            return RedirectToAction("Index", "Dashboard");
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError(error.Code == "PasswordMismatch" ? nameof(model.CurrentPassword) : nameof(model.NewPassword), error.Description);
        return View(new ChangePasswordViewModel());
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult AccessDenied() => View();
}
