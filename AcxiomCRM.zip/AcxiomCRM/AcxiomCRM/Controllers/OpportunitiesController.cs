using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

[Authorize]
public class OpportunitiesController : CrmController
{
    private readonly IOpportunityService _opportunities;
    private readonly ILookupService _lookups;

    public OpportunitiesController(IOpportunityService opportunities, ILookupService lookups)
    {
        _opportunities = opportunities;
        _lookups = lookups;
    }

    public async Task<IActionResult> Index([FromQuery] OpportunityFilter filter)
    {
        return View(new OpportunityIndexViewModel
        {
            Filter = filter,
            Results = await _opportunities.SearchAsync(filter),
            Owners = CanAssign ? await _lookups.AssignableUsersAsync() : new(),
            CanDelete = CanDelete
        });
    }

    public async Task<IActionResult> Pipeline() => View(await _opportunities.GetBoardAsync());

    public async Task<IActionResult> Details(int id)
    {
        var details = await _opportunities.GetDetailsAsync(id);
        if (details is null) return NotFound();
        details.CanDelete = CanDelete;
        return View(details);
    }

    [HttpGet]
    public async Task<IActionResult> Create(int? customerId)
    {
        var model = new OpportunityFormViewModel
        {
            CustomerId = customerId,
            Stage = OpportunityStage.Qualification,
            Probability = OpportunityWorkflow.DefaultProbability(OpportunityStage.Qualification),
            ExpectedCloseDate = DateTime.Today.AddDays(30)
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(OpportunityFormViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _opportunities.CreateAsync(model);
            if (result.Succeeded)
            {
                Notify($"Opportunity {result.Data!.OpportunityName} was created.");
                return RedirectToAction(nameof(Details), new { id = result.Data.OpportunityId });
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var o = await _opportunities.GetAsync(id);
        if (o is null) return NotFound();

        var model = new OpportunityFormViewModel
        {
            OpportunityId = o.OpportunityId,
            CurrentStage = o.Stage,
            OpportunityName = o.OpportunityName,
            CustomerId = o.CustomerId,
            LeadId = o.LeadId,
            Amount = o.Amount,
            Stage = o.Stage,
            Probability = o.Probability,
            ExpectedCloseDate = o.ExpectedCloseDate,
            Source = o.Source,
            Notes = o.Notes,
            AssignedTo = o.AssignedTo
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, OpportunityFormViewModel model)
    {
        model.OpportunityId = id;
        if (ModelState.IsValid)
        {
            var result = await _opportunities.UpdateAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Opportunity was saved.");
                return RedirectToAction(nameof(Details), new { id });
            }
            ModelState.AddServiceErrors(result);
        }

        model.CurrentStage = (await _opportunities.GetAsync(id))?.Stage;
        await PopulateAsync(model);
        return View(model);
    }

    /// <summary>Quick stage change from the pipeline board (same validation as a full edit).</summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> MoveStage(int id, OpportunityStage stage, string? returnTo)
    {
        var result = await _opportunities.MoveStageAsync(id, stage);
        if (result.NotFound) return NotFound();
        if (result.Succeeded) Notify($"Moved to {stage}.");
        else NotifyError(FirstError(result));

        return returnTo == "details" ? RedirectToAction(nameof(Details), new { id }) : RedirectToAction(nameof(Pipeline));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _opportunities.DeleteAsync(id);
        if (result.NotFound) return NotFound();
        if (!result.Succeeded)
        {
            NotifyError(FirstError(result));
            return RedirectToAction(nameof(Details), new { id });
        }

        Notify("Opportunity was deleted.");
        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateAsync(OpportunityFormViewModel model)
    {
        model.CanAssign = CanAssign;
        model.AssignableUsers = CanAssign ? await _lookups.AssignableUsersAsync() : new();
        model.Customers = await _lookups.CustomersAsync();
        model.Leads = await _lookups.LeadsAsync();
        model.StageOptions = model.CurrentStage switch
        {
            null => EnumHelper.SelectList(OpportunityWorkflow.OpenStages),
            OpportunityStage current when OpportunityWorkflow.IsClosed(current) => EnumHelper.SelectList(new[] { current }),
            _ => EnumHelper.SelectList<OpportunityStage>()
        };
    }
}
