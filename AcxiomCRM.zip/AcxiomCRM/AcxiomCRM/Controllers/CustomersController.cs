using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

[Authorize]
public class CustomersController : CrmController
{
    private readonly ICustomerService _customers;
    private readonly ILookupService _lookups;

    public CustomersController(ICustomerService customers, ILookupService lookups)
    {
        _customers = customers;
        _lookups = lookups;
    }

    public async Task<IActionResult> Index([FromQuery] CustomerFilter filter)
    {
        return View(new CustomerIndexViewModel
        {
            Filter = filter,
            Results = await _customers.SearchAsync(filter),
            Owners = CanAssign ? await _lookups.AssignableUsersAsync() : new(),
            CanDelete = CanDelete
        });
    }

    public async Task<IActionResult> Details(int id)
    {
        var details = await _customers.GetDetailsAsync(id);
        if (details is null) return NotFound();
        details.CanDelete = CanDelete;
        return View(details);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var model = new CustomerFormViewModel();
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CustomerFormViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _customers.CreateAsync(model);
            if (result.Succeeded)
            {
                Notify($"Customer {result.Data!.CustomerName} was created.");
                return RedirectToAction(nameof(Details), new { id = result.Data.CustomerId });
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var customer = await _customers.GetAsync(id);
        if (customer is null) return NotFound();

        var model = new CustomerFormViewModel
        {
            CustomerId = customer.CustomerId,
            CustomerCode = customer.CustomerCode,
            CustomerName = customer.CustomerName,
            Email = customer.Email,
            Phone = customer.Phone,
            CompanyName = customer.CompanyName,
            Address = customer.Address,
            City = customer.City,
            State = customer.State,
            Status = customer.Status,
            Notes = customer.Notes,
            AssignedTo = customer.AssignedTo
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, CustomerFormViewModel model)
    {
        model.CustomerId = id;
        if (ModelState.IsValid)
        {
            var result = await _customers.UpdateAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Customer details were saved.");
                return RedirectToAction(nameof(Details), new { id });
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _customers.DeleteAsync(id);
        if (result.NotFound) return NotFound();
        if (!result.Succeeded)
        {
            NotifyError(FirstError(result));
            return RedirectToAction(nameof(Details), new { id });
        }

        Notify("Customer was deleted.");
        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateAsync(CustomerFormViewModel model)
    {
        model.CanAssign = CanAssign;
        model.AssignableUsers = CanAssign ? await _lookups.AssignableUsersAsync() : new();
    }
}
