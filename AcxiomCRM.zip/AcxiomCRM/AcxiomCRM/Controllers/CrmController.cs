using AcxiomCRM.Common;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

/// <summary>Shared helpers for MVC controllers (flash messages, role checks).</summary>
public abstract class CrmController : Controller
{
    protected bool IsAdmin => User.IsInRole(AppRoles.Admin);
    protected bool IsManager => User.IsInRole(AppRoles.Manager);

    /// <summary>Admins and Managers can assign records to other users.</summary>
    protected bool CanAssign => IsAdmin || IsManager;

    /// <summary>Hard deletes are limited to Admins and Managers; Sales Executives deactivate/cancel instead.</summary>
    protected bool CanDelete => IsAdmin || IsManager;

    protected void Notify(string message) => TempData["Success"] = message;
    protected void NotifyError(string message) => TempData["Error"] = message;

    protected string FirstError<T>(ServiceResult<T> result) =>
        result.Errors.Values.FirstOrDefault() ?? "The request could not be completed.";
}
