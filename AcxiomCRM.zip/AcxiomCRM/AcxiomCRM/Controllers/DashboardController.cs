using AcxiomCRM.Services;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

public class DashboardController : CrmController
{
    private readonly IDashboardService _dashboard;

    public DashboardController(IDashboardService dashboard) => _dashboard = dashboard;

    public async Task<IActionResult> Index(string? range, DateTime? from, DateTime? to)
        => View(await _dashboard.GetAsync(range, from, to));
}
