using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

[Authorize]
public class ActivitiesController : CrmController
{
    private readonly IActivityService _activities;
    private readonly ILookupService _lookups;

    public ActivitiesController(IActivityService activities, ILookupService lookups)
    {
        _activities = activities;
        _lookups = lookups;
    }

    public async Task<IActionResult> Index([FromQuery] ActivityFilter filter)
    {
        return View(new ActivityIndexViewModel
        {
            Filter = filter,
            Results = await _activities.SearchAsync(filter),
            Owners = CanAssign ? await _lookups.AssignableUsersAsync() : new(),
            CanDelete = CanDelete
        });
    }

    [HttpGet]
    public async Task<IActionResult> Create(int? customerId, int? leadId, ActivityType? type)
    {
        var model = new ActivityFormViewModel
        {
            CustomerId = customerId,
            LeadId = leadId,
            ActivityType = type ?? ActivityType.Call,
            ActivityDate = DateTime.Now.Date.AddHours(DateTime.Now.Hour),
            Status = ActivityStatus.Completed
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ActivityFormViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _activities.CreateAsync(model);
            if (result.Succeeded)
            {
                Notify("Activity was logged.");
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var a = await _activities.GetAsync(id);
        if (a is null) return NotFound();

        var model = new ActivityFormViewModel
        {
            ActivityId = a.ActivityId,
            ActivityType = a.ActivityType,
            Subject = a.Subject,
            Description = a.Description,
            ActivityDate = a.ActivityDate,
            CustomerId = a.CustomerId,
            LeadId = a.LeadId,
            Status = a.Status,
            AssignedTo = a.AssignedTo
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ActivityFormViewModel model)
    {
        model.ActivityId = id;
        if (ModelState.IsValid)
        {
            var result = await _activities.UpdateAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Activity was saved.");
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _activities.DeleteAsync(id);
        if (result.NotFound) return NotFound();
        if (result.Succeeded) Notify("Activity was deleted.");
        else NotifyError(FirstError(result));
        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateAsync(ActivityFormViewModel model)
    {
        model.CanAssign = CanAssign;
        model.AssignableUsers = CanAssign ? await _lookups.AssignableUsersAsync() : new();
        model.Customers = await _lookups.CustomersAsync();
        model.Leads = await _lookups.LeadsAsync();
    }
}
