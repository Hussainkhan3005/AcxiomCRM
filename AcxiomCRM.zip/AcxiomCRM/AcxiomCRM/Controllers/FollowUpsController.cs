using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

[Authorize]
public class FollowUpsController : CrmController
{
    private readonly IFollowUpService _followUps;
    private readonly ILookupService _lookups;

    public FollowUpsController(IFollowUpService followUps, ILookupService lookups)
    {
        _followUps = followUps;
        _lookups = lookups;
    }

    public async Task<IActionResult> Index([FromQuery] FollowUpFilter filter)
    {
        var (overdue, today) = await _followUps.GetPendingCountsAsync();
        return View(new FollowUpIndexViewModel
        {
            Filter = filter,
            Results = await _followUps.SearchAsync(filter),
            Owners = CanAssign ? await _lookups.AssignableUsersAsync() : new(),
            OverdueCount = overdue,
            TodayCount = today,
            CanDelete = CanDelete
        });
    }

    [HttpGet]
    public async Task<IActionResult> Create(int? customerId, int? leadId, int? opportunityId)
    {
        var model = new FollowUpFormViewModel
        {
            CustomerId = customerId,
            LeadId = leadId,
            OpportunityId = opportunityId,
            FollowUpType = FollowUpType.Call,
            FollowUpDate = DateTime.Today.AddDays(1).AddHours(10)
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(FollowUpFormViewModel model)
    {
        model.Status = FollowUpStatus.Planned;
        if (ModelState.IsValid)
        {
            var result = await _followUps.CreateAsync(model);
            if (result.Succeeded)
            {
                Notify("Follow-up scheduled.");
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var f = await _followUps.GetAsync(id);
        if (f is null) return NotFound();

        var model = new FollowUpFormViewModel
        {
            FollowUpId = f.FollowUpId,
            CurrentStatus = f.Status,
            CustomerId = f.CustomerId,
            LeadId = f.LeadId,
            OpportunityId = f.OpportunityId,
            FollowUpDate = f.FollowUpDate,
            Subject = f.Subject,
            FollowUpType = f.FollowUpType,
            Remarks = f.Remarks,
            Status = f.Status,
            AssignedTo = f.AssignedTo
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, FollowUpFormViewModel model)
    {
        model.FollowUpId = id;
        if (ModelState.IsValid)
        {
            var result = await _followUps.UpdateAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Follow-up was saved.");
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddServiceErrors(result);
        }

        model.CurrentStatus = (await _followUps.GetAsync(id))?.Status;
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Complete(int id, string? remarks, string? returnUrl)
    {
        var result = await _followUps.CompleteAsync(id, remarks);
        if (result.NotFound) return NotFound();
        if (result.Succeeded) Notify("Follow-up marked as completed and logged as an activity.");
        else NotifyError(FirstError(result));
        return RedirectBack(returnUrl);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Missed(int id, string? returnUrl)
    {
        var result = await _followUps.MarkMissedAsync(id);
        if (result.NotFound) return NotFound();
        if (result.Succeeded) Notify("Follow-up marked as missed. Edit it to reschedule.");
        else NotifyError(FirstError(result));
        return RedirectBack(returnUrl);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _followUps.DeleteAsync(id);
        if (result.NotFound) return NotFound();
        if (result.Succeeded) Notify("Follow-up was deleted.");
        else NotifyError(FirstError(result));
        return RedirectToAction(nameof(Index));
    }

    private IActionResult RedirectBack(string? returnUrl) =>
        !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl) ? LocalRedirect(returnUrl) : RedirectToAction(nameof(Index));

    private async Task PopulateAsync(FollowUpFormViewModel model)
    {
        model.CanAssign = CanAssign;
        model.AssignableUsers = CanAssign ? await _lookups.AssignableUsersAsync() : new();
        model.Customers = await _lookups.CustomersAsync();
        model.Leads = await _lookups.LeadsAsync();
        model.Opportunities = await _lookups.OpportunitiesAsync();
        model.StatusOptions = model.CurrentStatus is FollowUpStatus current
            ? EnumHelper.SelectList(FollowUpWorkflow.AvailableFrom(current))
            : EnumHelper.SelectList(new[] { FollowUpStatus.Planned });
    }
}
