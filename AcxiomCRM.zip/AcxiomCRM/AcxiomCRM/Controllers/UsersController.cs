using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Controllers;

/// <summary>
/// User administration. Admins manage users; Managers get a read-only view of their team.
/// Password hashes and security fields are never sent to the view.
/// </summary>
[Authorize(Roles = AppRoles.AdminOrManager)]
public class UsersController : CrmController
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly ApplicationDbContext _db;
    private readonly IAuditService _audit;
    private readonly ILookupService _lookups;
    private readonly ICurrentUserService _currentUser;

    public UsersController(UserManager<ApplicationUser> users, ApplicationDbContext db, IAuditService audit,
        ILookupService lookups, ICurrentUserService currentUser)
    {
        _users = users;
        _db = db;
        _audit = audit;
        _lookups = lookups;
        _currentUser = currentUser;
    }

    public async Task<IActionResult> Index(string? search, string? role, string? status, int page = 1)
    {
        var query = _db.Users.AsNoTracking().AsQueryable();

        if (!IsAdmin)
        {
            var visible = await _currentUser.GetVisibleUserIdsAsync() ?? new List<string>();
            query = query.Where(u => visible.Contains(u.Id));
        }
        if (!string.IsNullOrWhiteSpace(search))
        {
            var p = search.ToLikePattern();
            query = query.Where(u => EF.Functions.Like(u.FullName, p) || (u.Email != null && EF.Functions.Like(u.Email, p)));
        }
        if (status == "active") query = query.Where(u => u.IsActive);
        if (status == "inactive") query = query.Where(u => !u.IsActive);
        if (!string.IsNullOrEmpty(role))
        {
            var roleUserIds = from ur in _db.UserRoles
                              join r in _db.Roles on ur.RoleId equals r.Id
                              where r.Name == role
                              select ur.UserId;
            query = query.Where(u => roleUserIds.Contains(u.Id));
        }

        var paged = await query.OrderBy(u => u.FullName)
            .Select(u => new
            {
                u.Id, u.FullName, u.Email, u.IsActive, u.LockoutEnd, u.AccessFailedCount, u.CreatedDate,
                ManagerName = u.Manager != null ? u.Manager.FullName : null
            })
            .ToPagedAsync(page, 10);

        var ids = paged.Items.Select(u => u.Id).ToList();
        var roles = await (from ur in _db.UserRoles
                           join r in _db.Roles on ur.RoleId equals r.Id
                           where ids.Contains(ur.UserId)
                           select new { ur.UserId, r.Name }).ToListAsync();

        return View(new UserIndexViewModel
        {
            Search = search,
            Role = role,
            Status = status,
            CanManage = IsAdmin,
            CurrentUserId = _currentUser.UserId,
            Results = paged.Map(u => new UserListItem
            {
                Id = u.Id,
                FullName = u.FullName,
                Email = u.Email ?? string.Empty,
                Role = roles.FirstOrDefault(r => r.UserId == u.Id)?.Name,
                ManagerName = u.ManagerName,
                IsActive = u.IsActive,
                LockoutEnd = u.LockoutEnd,
                AccessFailedCount = u.AccessFailedCount,
                CreatedDate = u.CreatedDate
            })
        });
    }

    [HttpGet]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Create()
    {
        var model = new UserCreateViewModel();
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Create(UserCreateViewModel model)
    {
        await ValidateRoleAndManagerAsync(model);
        if (ModelState.IsValid)
        {
            var user = new ApplicationUser
            {
                UserName = model.Email.Trim().ToLowerInvariant(),
                Email = model.Email.Trim().ToLowerInvariant(),
                FullName = model.FullName.Trim(),
                IsActive = model.IsActive,
                ManagerId = model.Role == AppRoles.SalesExecutive ? model.ManagerId : null,
                CreatedDate = DateTime.Now
            };

            var result = await _users.CreateAsync(user, model.Password); // policy + hashing by Identity
            if (result.Succeeded)
            {
                await _users.AddToRoleAsync(user, model.Role);
                await _audit.LogAsync(AuditActions.Create, AuditEntities.User, user.Id,
                    newValue: new { user.Id, user.Email, user.FullName, user.IsActive, Role = model.Role, user.ManagerId });
                Notify($"User {user.FullName} was created.");
                return RedirectToAction(nameof(Index));
            }
            AddIdentityErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Edit(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();

        var model = new UserEditViewModel
        {
            Id = user.Id,
            FullName = user.FullName,
            Email = user.Email ?? string.Empty,
            Role = (await _users.GetRolesAsync(user)).FirstOrDefault() ?? AppRoles.SalesExecutive,
            ManagerId = user.ManagerId,
            IsActive = user.IsActive,
            IsLockedOut = await _users.IsLockedOutAsync(user),
            LockoutEnd = user.LockoutEnd,
            AccessFailedCount = user.AccessFailedCount,
            IsSelf = user.Id == _currentUser.UserId
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Edit(string id, UserEditViewModel model)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();

        model.Id = id;
        model.IsSelf = id == _currentUser.UserId;
        var currentRole = (await _users.GetRolesAsync(user)).FirstOrDefault();

        if (model.IsSelf && !model.IsActive)
            ModelState.AddModelError(nameof(model.IsActive), "You cannot deactivate your own account.");
        if (model.IsSelf && currentRole == AppRoles.Admin && model.Role != AppRoles.Admin)
            ModelState.AddModelError(nameof(model.Role), "You cannot remove your own Admin role.");
        await ValidateRoleAndManagerAsync(model, id);

        if (ModelState.IsValid)
        {
            var before = new { user.FullName, user.Email, user.IsActive, user.ManagerId, Role = currentRole };
            var email = model.Email.Trim().ToLowerInvariant();

            user.FullName = model.FullName.Trim();
            user.IsActive = model.IsActive;
            user.ManagerId = model.Role == AppRoles.SalesExecutive ? model.ManagerId : null;
            if (!string.Equals(user.Email, email, StringComparison.OrdinalIgnoreCase))
            {
                user.Email = email;
                user.UserName = email;
            }

            var result = await _users.UpdateAsync(user);
            if (result.Succeeded)
            {
                if (currentRole != model.Role)
                {
                    if (currentRole is not null) await _users.RemoveFromRoleAsync(user, currentRole);
                    await _users.AddToRoleAsync(user, model.Role);
                    await _audit.LogAsync(AuditActions.RoleChange, AuditEntities.User, user.Id, currentRole, model.Role,
                        details: $"Role of {user.UserName} changed");
                }
                if (before.IsActive != user.IsActive)
                    await _audit.LogAsync(user.IsActive ? AuditActions.Activate : AuditActions.Deactivate, AuditEntities.User, user.Id);

                // Invalidate the user's existing sessions so role/status changes apply immediately
                // (skipped when admins edit themselves, so they are not signed out mid-session).
                if (!model.IsSelf) await _users.UpdateSecurityStampAsync(user);
                await _audit.LogAsync(AuditActions.Update, AuditEntities.User, user.Id, before,
                    new { user.FullName, user.Email, user.IsActive, user.ManagerId, Role = model.Role });

                Notify($"User {user.FullName} was saved.");
                return RedirectToAction(nameof(Index));
            }
            AddIdentityErrors(result);
        }

        model.IsLockedOut = await _users.IsLockedOutAsync(user);
        model.LockoutEnd = user.LockoutEnd;
        model.AccessFailedCount = user.AccessFailedCount;
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> ToggleActive(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();
        if (user.Id == _currentUser.UserId)
        {
            NotifyError("You cannot deactivate your own account.");
            return RedirectToAction(nameof(Index));
        }

        user.IsActive = !user.IsActive;
        await _users.UpdateAsync(user);
        await _users.UpdateSecurityStampAsync(user);
        await _audit.LogAsync(user.IsActive ? AuditActions.Activate : AuditActions.Deactivate, AuditEntities.User, user.Id,
            details: $"{user.UserName} {(user.IsActive ? "activated" : "deactivated")}");

        Notify($"{user.FullName} is now {(user.IsActive ? "active" : "inactive")}.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> Unlock(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();

        await _users.SetLockoutEndDateAsync(user, null);
        await _users.ResetAccessFailedCountAsync(user);
        await _audit.LogAsync(AuditActions.Unlock, AuditEntities.User, user.Id, details: $"{user.UserName} unlocked by administrator");

        Notify($"{user.FullName} has been unlocked.");
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> ResetPassword(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();
        return View(new ResetPasswordViewModel { Id = user.Id, FullName = user.FullName });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.Admin)]
    public async Task<IActionResult> ResetPassword(string id, ResetPasswordViewModel model)
    {
        var user = await _users.FindByIdAsync(id);
        if (user is null) return NotFound();
        model.Id = id;
        model.FullName = user.FullName;
        if (!ModelState.IsValid) return View(model);

        // Token-based reset: Identity validates policy, re-hashes and rotates the security stamp.
        var token = await _users.GeneratePasswordResetTokenAsync(user);
        var result = await _users.ResetPasswordAsync(user, token, model.NewPassword);
        await _audit.LogAsync(AuditActions.PasswordReset, AuditEntities.User, user.Id,
            result: result.Succeeded ? AuditResults.Success : AuditResults.Failure,
            details: $"Password reset for {user.UserName} by administrator");

        if (result.Succeeded)
        {
            await _users.SetLockoutEndDateAsync(user, null);
            await _users.ResetAccessFailedCountAsync(user);
            Notify($"Password for {user.FullName} was reset.");
            return RedirectToAction(nameof(Index));
        }

        AddIdentityErrors(result, nameof(model.NewPassword));
        return View(new ResetPasswordViewModel { Id = id, FullName = user.FullName });
    }

    private async Task ValidateRoleAndManagerAsync(UserFormBase model, string? userId = null)
    {
        if (!AppRoles.All.Contains(model.Role))
            ModelState.AddModelError(nameof(model.Role), "Select a valid role.");

        if (model.Role == AppRoles.SalesExecutive && !string.IsNullOrEmpty(model.ManagerId))
        {
            var managers = await _lookups.ManagersAsync();
            if (managers.All(m => m.Value != model.ManagerId) || model.ManagerId == userId)
                ModelState.AddModelError(nameof(model.ManagerId), "Select a valid manager.");
        }
    }

    private async Task PopulateAsync(UserFormBase model)
    {
        model.Roles = AppRoles.All.Select(r => new SelectListItem(AppRoles.DisplayName(r), r)).ToList();
        model.Managers = await _lookups.ManagersAsync();
    }

    private void AddIdentityErrors(IdentityResult result, string? key = null)
    {
        foreach (var error in result.Errors)
        {
            var field = key ?? (error.Code.Contains("Password", StringComparison.OrdinalIgnoreCase) ? "Password"
                : error.Code.Contains("Email", StringComparison.OrdinalIgnoreCase) || error.Code.Contains("UserName", StringComparison.OrdinalIgnoreCase) ? "Email"
                : string.Empty);
            ModelState.AddModelError(field, error.Description);
        }
    }
}
