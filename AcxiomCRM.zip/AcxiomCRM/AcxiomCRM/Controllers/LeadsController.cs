using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

[Authorize]
public class LeadsController : CrmController
{
    private readonly ILeadService _leads;
    private readonly ILookupService _lookups;

    public LeadsController(ILeadService leads, ILookupService lookups)
    {
        _leads = leads;
        _lookups = lookups;
    }

    public async Task<IActionResult> Index([FromQuery] LeadFilter filter)
    {
        return View(new LeadIndexViewModel
        {
            Filter = filter,
            Results = await _leads.SearchAsync(filter),
            Owners = CanAssign ? await _lookups.AssignableUsersAsync() : new(),
            CanDelete = CanDelete
        });
    }

    public async Task<IActionResult> Details(int id)
    {
        var details = await _leads.GetDetailsAsync(id);
        if (details is null) return NotFound();
        details.CanDelete = CanDelete;
        return View(details);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var model = new LeadFormViewModel { Source = LeadSource.Website };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(LeadFormViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _leads.CreateAsync(model);
            if (result.Succeeded)
            {
                Notify($"Lead {result.Data!.LeadName} was created.");
                return RedirectToAction(nameof(Details), new { id = result.Data.LeadId });
            }
            ModelState.AddServiceErrors(result);
        }

        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var lead = await _leads.GetAsync(id);
        if (lead is null) return NotFound();

        var model = new LeadFormViewModel
        {
            LeadId = lead.LeadId,
            LeadCode = lead.LeadCode,
            CurrentStatus = lead.Status,
            LeadName = lead.LeadName,
            Email = lead.Email,
            Phone = lead.Phone,
            CompanyName = lead.CompanyName,
            Source = lead.Source,
            Status = lead.Status,
            Priority = lead.Priority,
            ExpectedValue = lead.ExpectedValue,
            Notes = lead.Notes,
            AssignedTo = lead.AssignedTo
        };
        await PopulateAsync(model);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, LeadFormViewModel model)
    {
        model.LeadId = id;
        if (ModelState.IsValid)
        {
            var result = await _leads.UpdateAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Lead details were saved.");
                return RedirectToAction(nameof(Details), new { id });
            }
            ModelState.AddServiceErrors(result);
        }

        var current = await _leads.GetAsync(id);
        model.CurrentStatus = current?.Status;
        model.LeadCode = current?.LeadCode;
        await PopulateAsync(model);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Convert(int id)
    {
        var lead = await _leads.GetAsync(id);
        if (lead is null) return NotFound();
        if (lead.Status != LeadStatus.Qualified)
        {
            NotifyError("Only Qualified leads can be converted. Move the lead to Qualified first.");
            return RedirectToAction(nameof(Details), new { id });
        }

        var model = new LeadConvertViewModel
        {
            LeadId = lead.LeadId,
            LeadCode = lead.LeadCode,
            LeadName = lead.LeadName,
            CustomerName = lead.LeadName,
            Email = lead.Email,
            Phone = lead.Phone,
            CompanyName = lead.CompanyName,
            CreateOpportunity = true,
            OpportunityName = $"{lead.CompanyName ?? lead.LeadName} - new deal",
            Amount = lead.ExpectedValue > 0 ? lead.ExpectedValue : null,
            Probability = OpportunityWorkflow.DefaultProbability(OpportunityStage.Qualification),
            ExpectedCloseDate = DateTime.Today.AddDays(30),
            Customers = await _lookups.CustomersAsync()
        };
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Convert(int id, LeadConvertViewModel model)
    {
        model.LeadId = id;
        if (ModelState.IsValid)
        {
            var result = await _leads.ConvertAsync(id, model);
            if (result.NotFound) return NotFound();
            if (result.Succeeded)
            {
                Notify("Lead converted. The customer record is ready.");
                return result.Data!.ConvertedOpportunityId is int opportunityId
                    ? RedirectToAction("Details", "Opportunities", new { id = opportunityId })
                    : RedirectToAction("Details", "Customers", new { id = result.Data.ConvertedCustomerId });
            }
            ModelState.AddServiceErrors(result);
        }

        var lead = await _leads.GetAsync(id);
        model.LeadCode = lead?.LeadCode;
        model.LeadName = lead?.LeadName;
        model.Customers = await _lookups.CustomersAsync();
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _leads.DeleteAsync(id);
        if (result.NotFound) return NotFound();
        if (!result.Succeeded)
        {
            NotifyError(FirstError(result));
            return RedirectToAction(nameof(Details), new { id });
        }

        Notify("Lead was deleted.");
        return RedirectToAction(nameof(Index));
    }

    private async Task PopulateAsync(LeadFormViewModel model)
    {
        model.CanAssign = CanAssign;
        model.AssignableUsers = CanAssign ? await _lookups.AssignableUsersAsync() : new();
        model.StatusOptions = model.CurrentStatus is LeadStatus current
            ? EnumHelper.SelectList(LeadWorkflow.AvailableFrom(current))
            : EnumHelper.SelectList(LeadWorkflow.CreatableStatuses);
    }
}
