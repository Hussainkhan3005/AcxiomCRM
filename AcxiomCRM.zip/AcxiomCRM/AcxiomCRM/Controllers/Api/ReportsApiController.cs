using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

[Route("api/reports")]
public class ReportsApiController : CrmApiController
{
    private readonly IOpportunityService _opportunities;

    public ReportsApiController(IOpportunityService opportunities) => _opportunities = opportunities;

    /// <summary>Stage-wise and owner-wise pipeline (Admin: all, Manager: team).</summary>
    [HttpGet("pipeline")]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    [ProducesResponseType(typeof(PipelineSummaryDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<PipelineSummaryDto>> Pipeline() => Ok(await _opportunities.GetPipelineSummaryAsync());
}
