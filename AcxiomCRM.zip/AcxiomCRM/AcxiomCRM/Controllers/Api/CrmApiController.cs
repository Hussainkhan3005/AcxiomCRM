using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

/// <summary>
/// Base for REST endpoints. [ApiController] gives automatic 400 responses for invalid payloads;
/// the global fallback policy makes every endpoint require authentication.
/// </summary>
[ApiController]
[Produces("application/json")]
public abstract class CrmApiController : ControllerBase
{
    /// <summary>Maps a failed service result to 404, 409 or 400 with a consistent error body.</summary>
    protected ActionResult Failure<T>(ServiceResult<T> result)
    {
        if (result.NotFound)
            return NotFound(new ProblemDetails { Status = StatusCodes.Status404NotFound, Title = "The requested record was not found." });

        foreach (var (key, message) in result.Errors)
            ModelState.AddModelError(key, message);

        if (result.Conflict)
            return Conflict(new ValidationProblemDetails(ModelState)
            {
                Status = StatusCodes.Status409Conflict,
                Title = "The request conflicts with existing data."
            });

        return ValidationProblem(ModelState);
    }

    protected static PagedResponse<TOut> ToResponse<T, TOut>(PagedResult<T> page, Func<T, TOut> map) => new()
    {
        Items = page.Items.Select(map).ToList(),
        Page = page.Page,
        PageSize = page.PageSize,
        TotalCount = page.TotalCount,
        TotalPages = page.TotalPages
    };
}
