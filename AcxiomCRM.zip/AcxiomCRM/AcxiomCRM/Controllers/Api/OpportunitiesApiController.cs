using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

[Route("api/opportunities")]
public class OpportunitiesApiController : CrmApiController
{
    private readonly IOpportunityService _opportunities;

    public OpportunitiesApiController(IOpportunityService opportunities) => _opportunities = opportunities;

    /// <summary>List and search opportunities.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResponse<OpportunityResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PagedResponse<OpportunityResponseDto>>> GetAll([FromQuery] OpportunityFilter filter)
        => Ok(ToResponse(await _opportunities.SearchAsync(filter), OpportunityResponseDto.From));

    /// <summary>Get one opportunity.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<OpportunityResponseDto>> GetById(int id)
    {
        var opportunity = await _opportunities.GetAsync(id);
        if (opportunity is null) return NotFound();
        return Ok(OpportunityResponseDto.From(opportunity));
    }

    /// <summary>
    /// Create an opportunity. Amount must be greater than 0, probability 0-100,
    /// and the expected close date cannot be in the past.
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<OpportunityResponseDto>> Create([FromBody] OpportunityRequestDto dto)
    {
        var result = await _opportunities.CreateAsync(dto);
        if (!result.Succeeded) return Failure(result);
        var created = await _opportunities.GetAsync(result.Data!.OpportunityId);
        return CreatedAtAction(nameof(GetById), new { id = result.Data.OpportunityId }, OpportunityResponseDto.From(created ?? result.Data));
    }

    /// <summary>Update an opportunity (including stage changes).</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(OpportunityResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<OpportunityResponseDto>> Update(int id, [FromBody] OpportunityRequestDto dto)
    {
        var result = await _opportunities.UpdateAsync(id, dto);
        if (!result.Succeeded) return Failure(result);
        var updated = await _opportunities.GetAsync(id);
        return Ok(OpportunityResponseDto.From(updated ?? result.Data!));
    }

    /// <summary>Delete an opportunity (Admin/Manager).</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _opportunities.DeleteAsync(id);
        return result.Succeeded ? NoContent() : Failure(result);
    }
}
