using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

[Route("api/leads")]
public class LeadsApiController : CrmApiController
{
    private readonly ILeadService _leads;

    public LeadsApiController(ILeadService leads) => _leads = leads;

    /// <summary>List and search leads.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResponse<LeadResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PagedResponse<LeadResponseDto>>> GetAll([FromQuery] LeadFilter filter)
        => Ok(ToResponse(await _leads.SearchAsync(filter), LeadResponseDto.From));

    /// <summary>Get one lead.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(LeadResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<LeadResponseDto>> GetById(int id)
    {
        var lead = await _leads.GetAsync(id);
        if (lead is null) return NotFound();
        return Ok(LeadResponseDto.From(lead));
    }

    /// <summary>Create a lead. Status must be New, Contacted or Qualified.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(LeadResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<LeadResponseDto>> Create([FromBody] LeadRequestDto dto)
    {
        var result = await _leads.CreateAsync(dto);
        if (!result.Succeeded) return Failure(result);
        var created = await _leads.GetAsync(result.Data!.LeadId);
        return CreatedAtAction(nameof(GetById), new { id = result.Data.LeadId }, LeadResponseDto.From(created ?? result.Data));
    }

    /// <summary>Update a lead. Invalid status transitions return 400.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(LeadResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<LeadResponseDto>> Update(int id, [FromBody] LeadRequestDto dto)
    {
        var result = await _leads.UpdateAsync(id, dto);
        if (!result.Succeeded) return Failure(result);
        var updated = await _leads.GetAsync(id);
        return Ok(LeadResponseDto.From(updated ?? result.Data!));
    }

    /// <summary>Convert a Qualified lead into a customer and (optionally) an opportunity.</summary>
    [HttpPost("{id:int}/convert")]
    [ProducesResponseType(typeof(LeadResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<LeadResponseDto>> Convert(int id, [FromBody] LeadConvertDto dto)
    {
        var result = await _leads.ConvertAsync(id, dto);
        if (!result.Succeeded) return Failure(result);
        var converted = await _leads.GetAsync(id);
        return Ok(LeadResponseDto.From(converted ?? result.Data!));
    }

    /// <summary>Delete a lead (Admin/Manager). Converted leads cannot be deleted.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _leads.DeleteAsync(id);
        return result.Succeeded ? NoContent() : Failure(result);
    }
}
