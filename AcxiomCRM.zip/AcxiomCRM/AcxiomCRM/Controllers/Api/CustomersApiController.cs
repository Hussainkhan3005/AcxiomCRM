using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Customers. Results are limited to the caller's scope (own / team / all).</summary>
[Route("api/customers")]
public class CustomersApiController : CrmApiController
{
    private readonly ICustomerService _customers;

    public CustomersApiController(ICustomerService customers) => _customers = customers;

    /// <summary>List and search customers.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResponse<CustomerResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<PagedResponse<CustomerResponseDto>>> GetAll([FromQuery] CustomerFilter filter)
        => Ok(ToResponse(await _customers.SearchAsync(filter), CustomerResponseDto.From));

    /// <summary>Get one customer.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(CustomerResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<CustomerResponseDto>> GetById(int id)
    {
        var customer = await _customers.GetAsync(id);
        if (customer is null) return NotFound();
        return Ok(CustomerResponseDto.From(customer));
    }

    /// <summary>Create a customer. Email and phone must be unique.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(CustomerResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<CustomerResponseDto>> Create([FromBody] CustomerRequestDto dto)
    {
        var result = await _customers.CreateAsync(dto);
        if (!result.Succeeded) return Failure(result);
        var created = await _customers.GetAsync(result.Data!.CustomerId);
        return CreatedAtAction(nameof(GetById), new { id = result.Data.CustomerId }, CustomerResponseDto.From(created ?? result.Data));
    }

    /// <summary>Update a customer.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(CustomerResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<CustomerResponseDto>> Update(int id, [FromBody] CustomerRequestDto dto)
    {
        var result = await _customers.UpdateAsync(id, dto);
        if (!result.Succeeded) return Failure(result);
        var updated = await _customers.GetAsync(id);
        return Ok(CustomerResponseDto.From(updated ?? result.Data!));
    }

    /// <summary>Delete a customer (Admin/Manager). Customers with opportunities return 409.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = AppRoles.AdminOrManager)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _customers.DeleteAsync(id);
        return result.Succeeded ? NoContent() : Failure(result);
    }
}
