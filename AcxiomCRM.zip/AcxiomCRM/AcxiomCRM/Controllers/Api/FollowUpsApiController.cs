using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

[Route("api/followups")]
public class FollowUpsApiController : CrmApiController
{
    private readonly IFollowUpService _followUps;

    public FollowUpsApiController(IFollowUpService followUps) => _followUps = followUps;

    /// <summary>List follow-ups. Use view=upcoming|overdue|today for quick filters.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResponse<FollowUpResponseDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PagedResponse<FollowUpResponseDto>>> GetAll([FromQuery] FollowUpFilter filter)
        => Ok(ToResponse(await _followUps.SearchAsync(filter), FollowUpResponseDto.From));

    /// <summary>Get one follow-up.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(FollowUpResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<FollowUpResponseDto>> GetById(int id)
    {
        var followUp = await _followUps.GetAsync(id);
        if (followUp is null) return NotFound();
        return Ok(FollowUpResponseDto.From(followUp));
    }

    /// <summary>Schedule a follow-up. The date cannot be earlier than today.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(FollowUpResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<FollowUpResponseDto>> Create([FromBody] FollowUpRequestDto dto)
    {
        var result = await _followUps.CreateAsync(dto);
        if (!result.Succeeded) return Failure(result);
        var created = await _followUps.GetAsync(result.Data!.FollowUpId);
        return CreatedAtAction(nameof(GetById), new { id = result.Data.FollowUpId }, FollowUpResponseDto.From(created ?? result.Data));
    }

    /// <summary>Mark a follow-up as completed (also logs an activity).</summary>
    [HttpPost("{id:int}/complete")]
    [ProducesResponseType(typeof(FollowUpResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<FollowUpResponseDto>> Complete(int id, [FromQuery] string? remarks)
    {
        var result = await _followUps.CompleteAsync(id, remarks);
        if (!result.Succeeded) return Failure(result);
        var updated = await _followUps.GetAsync(id);
        return Ok(FollowUpResponseDto.From(updated ?? result.Data!));
    }
}
