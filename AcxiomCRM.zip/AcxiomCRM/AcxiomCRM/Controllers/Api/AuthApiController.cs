using System.Security.Claims;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace AcxiomCRM.Controllers.Api;

[Route("api/auth")]
public class AuthApiController : CrmApiController
{
    private readonly IAccountService _accounts;

    public AuthApiController(IAccountService accounts) => _accounts = accounts;

    /// <summary>Signs in and issues the authentication cookie. Rate limited per IP address.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting("login")]
    [ProducesResponseType(typeof(CurrentUserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
    public async Task<IActionResult> Login([FromBody] LoginRequestDto request)
    {
        var outcome = await _accounts.SignInAsync(request.UserNameOrEmail, request.Password, request.RememberMe);
        return outcome.Status switch
        {
            LoginStatus.Success => Ok(new CurrentUserDto
            {
                UserId = outcome.User!.Id,
                UserName = outcome.User.UserName ?? string.Empty,
                FullName = outcome.User.FullName,
                Role = outcome.Role
            }),
            LoginStatus.LockedOut => Problem(statusCode: StatusCodes.Status403Forbidden, title: "Account is temporarily locked. Try again later."),
            LoginStatus.Inactive => Problem(statusCode: StatusCodes.Status403Forbidden, title: "Account is deactivated."),
            _ => Problem(statusCode: StatusCodes.Status401Unauthorized, title: "Invalid username/email or password.")
        };
    }

    /// <summary>Ends the session.</summary>
    [HttpPost("logout")]
    [ProducesResponseType(typeof(ApiMessage), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Logout()
    {
        await _accounts.SignOutAsync(User);
        return Ok(new ApiMessage { Message = "Signed out." });
    }

    /// <summary>Returns the signed-in user.</summary>
    [HttpGet("me")]
    [ProducesResponseType(typeof(CurrentUserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult Me() => Ok(new CurrentUserDto
    {
        UserId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty,
        UserName = User.Identity?.Name ?? string.Empty,
        FullName = User.FindFirstValue(AppClaimsPrincipalFactory.FullNameClaim) ?? string.Empty,
        Role = User.FindFirstValue(ClaimTypes.Role)
    });
}
