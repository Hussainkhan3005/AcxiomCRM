using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => RedirectToAction("Index", "Dashboard");

    [AllowAnonymous]
    public IActionResult Error() => View();

    [AllowAnonymous]
    [Route("Home/Status/{code:int}")]
    public IActionResult Status(int code)
    {
        ViewData["Code"] = code;
        return View();
    }
}
