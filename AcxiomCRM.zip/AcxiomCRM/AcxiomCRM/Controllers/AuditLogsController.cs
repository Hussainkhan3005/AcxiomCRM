using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

/// <summary>Read-only audit trail. There are deliberately no edit or delete actions.</summary>
[Authorize(Roles = AppRoles.AdminOrManager)]
public class AuditLogsController : CrmController
{
    private readonly IAuditLogService _auditLogs;

    public AuditLogsController(IAuditLogService auditLogs) => _auditLogs = auditLogs;

    public async Task<IActionResult> Index([FromQuery] AuditFilter filter)
    {
        return View(new AuditIndexViewModel
        {
            Filter = filter,
            Results = await _auditLogs.SearchAsync(filter),
            IsLimitedView = _auditLogs.IsLimitedView
        });
    }

    public async Task<IActionResult> Details(long id)
    {
        var entry = await _auditLogs.GetAsync(id);
        if (entry is null) return NotFound();
        return View(entry);
    }
}
