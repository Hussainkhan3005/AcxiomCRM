using System.Text;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

public class ReportsController : CrmController
{
    private readonly IReportService _reports;

    public ReportsController(IReportService reports) => _reports = reports;

    public IActionResult Index() => View(ReportCatalog.All.Where(r => r.IsAllowed(User)).ToList());

    public async Task<IActionResult> Run(string id, [FromQuery] ReportRequest request)
    {
        var definition = ReportCatalog.Find(id);
        if (definition is null) return NotFound();
        if (!definition.IsAllowed(User)) return Forbid();

        var result = await _reports.RunAsync(definition.Key, request, forExport: false);
        if (result is null) return NotFound();
        return View(result);
    }

    public async Task<IActionResult> Export(string id, [FromQuery] ReportRequest request)
    {
        var definition = ReportCatalog.Find(id);
        if (definition is null) return NotFound();
        if (!definition.IsAllowed(User)) return Forbid();

        var result = await _reports.RunAsync(definition.Key, request, forExport: true);
        if (result is null) return NotFound();

        var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(_reports.ToCsv(result))).ToArray();
        return File(bytes, "text/csv", $"acxiomcrm-{definition.Key}-{DateTime.Now:yyyyMMdd-HHmm}.csv");
    }
}
