using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Controllers;

[Authorize(Roles = AppRoles.Admin)]
public class RolesController : CrmController
{
    private readonly ApplicationDbContext _db;

    public RolesController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var counts = await _db.Roles
            .Select(r => new { r.Name, Count = _db.UserRoles.Count(ur => ur.RoleId == r.Id) })
            .ToListAsync();

        var descriptions = new Dictionary<string, string>
        {
            [AppRoles.Admin] = "Full administration: users, roles, audit log, configuration, every CRM record and report.",
            [AppRoles.Manager] = "Manages their team's customers, leads, opportunities and follow-ups, with team reports. No security administration.",
            [AppRoles.SalesExecutive] = "Works on assigned customers, leads, opportunities, follow-ups and activities, with personal reports."
        };

        var model = AppRoles.All.Select(role => new RoleListItem
        {
            Name = role,
            UserCount = counts.FirstOrDefault(c => c.Name == role)?.Count ?? 0,
            Description = descriptions[role]
        }).ToList();

        return View(model);
    }
}
