using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Dtos;

public class LoginRequestDto
{
    [Required(ErrorMessage = "Username or email is required.")]
    [StringLength(256)]
    public string UserNameOrEmail { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100)]
    public string Password { get; set; } = string.Empty;

    public bool RememberMe { get; set; }
}

public class CurrentUserDto
{
    public string UserId { get; init; } = string.Empty;
    public string UserName { get; init; } = string.Empty;
    public string FullName { get; init; } = string.Empty;
    public string? Role { get; init; }
}

public class ApiMessage
{
    public string Message { get; init; } = string.Empty;
}
