using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Common;
using AcxiomCRM.Models;

namespace AcxiomCRM.Dtos;

/// <summary>Create/update payload for a customer (used by MVC forms and the REST API).</summary>
public class CustomerRequestDto
{
    [Required(ErrorMessage = "Customer Name is required.")]
    [StringLength(ValidationRules.NameMaxLength, ErrorMessage = "Customer Name cannot exceed {1} characters.")]
    [Display(Name = "Customer Name")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [StringLength(ValidationRules.EmailMaxLength, ErrorMessage = "Email cannot exceed {1} characters.")]
    [RegularExpression(ValidationRules.EmailPattern, ErrorMessage = ValidationRules.EmailMessage)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone is required.")]
    [RegularExpression(ValidationRules.PhonePattern, ErrorMessage = ValidationRules.PhoneMessage)]
    public string Phone { get; set; } = string.Empty;

    [StringLength(ValidationRules.CompanyMaxLength, ErrorMessage = "Company Name cannot exceed {1} characters.")]
    [Display(Name = "Company Name")]
    public string? CompanyName { get; set; }

    [StringLength(250, ErrorMessage = "Address cannot exceed {1} characters.")]
    public string? Address { get; set; }

    [StringLength(100, ErrorMessage = "City cannot exceed {1} characters.")]
    public string? City { get; set; }

    [StringLength(100, ErrorMessage = "State cannot exceed {1} characters.")]
    public string? State { get; set; }

    [Required(ErrorMessage = "Status is required.")]
    [EnumDataType(typeof(CustomerStatus), ErrorMessage = "Select a valid status.")]
    public CustomerStatus? Status { get; set; } = CustomerStatus.Active;

    [StringLength(ValidationRules.NotesMaxLength, ErrorMessage = "Notes cannot exceed {1} characters.")]
    public string? Notes { get; set; }

    /// <summary>Owner user id. Sales Executives can only assign to themselves.</summary>
    [Display(Name = "Assigned To")]
    public string? AssignedTo { get; set; }
}

public class CustomerResponseDto
{
    public int CustomerId { get; init; }
    public string CustomerCode { get; init; } = string.Empty;
    public string CustomerName { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string Phone { get; init; } = string.Empty;
    public string? CompanyName { get; init; }
    public string? Address { get; init; }
    public string? City { get; init; }
    public string? State { get; init; }
    public CustomerStatus Status { get; init; }
    public string? Notes { get; init; }
    public string AssignedTo { get; init; } = string.Empty;
    public string? AssignedToName { get; init; }
    public DateTime CreatedDate { get; init; }
    public string CreatedBy { get; init; } = string.Empty;
    public DateTime? ModifiedDate { get; init; }

    public static CustomerResponseDto From(Customer c) => new()
    {
        CustomerId = c.CustomerId,
        CustomerCode = c.CustomerCode,
        CustomerName = c.CustomerName,
        Email = c.Email,
        Phone = c.Phone,
        CompanyName = c.CompanyName,
        Address = c.Address,
        City = c.City,
        State = c.State,
        Status = c.Status,
        Notes = c.Notes,
        AssignedTo = c.AssignedTo,
        AssignedToName = c.AssignedUser?.FullName,
        CreatedDate = c.CreatedDate,
        CreatedBy = c.CreatedBy,
        ModifiedDate = c.ModifiedDate
    };
}
