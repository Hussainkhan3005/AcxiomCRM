using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Common;
using AcxiomCRM.Models;

namespace AcxiomCRM.Dtos;

public class FollowUpRequestDto
{
    [Display(Name = "Customer")]
    public int? CustomerId { get; set; }

    [Display(Name = "Lead")]
    public int? LeadId { get; set; }

    [Display(Name = "Opportunity")]
    public int? OpportunityId { get; set; }

    [Required(ErrorMessage = "Follow-up date is required.")]
    [DataType(DataType.DateTime)]
    [DateNotInPast(ErrorMessage = ValidationRules.FollowUpDateMessage, IgnoreWhenProperty = nameof(Status), IgnoreWhenValues = "Completed,Missed,Cancelled")]
    [Display(Name = "Follow-Up Date")]
    public DateTime? FollowUpDate { get; set; }

    [Required(ErrorMessage = "Subject is required.")]
    [StringLength(ValidationRules.SubjectMaxLength, ErrorMessage = "Subject cannot exceed {1} characters.")]
    public string Subject { get; set; } = string.Empty;

    [Required(ErrorMessage = "Follow-up type is required.")]
    [EnumDataType(typeof(Models.FollowUpType), ErrorMessage = "Select a valid type.")]
    [Display(Name = "Type")]
    public FollowUpType? FollowUpType { get; set; }

    [StringLength(ValidationRules.NotesMaxLength, ErrorMessage = "Remarks cannot exceed {1} characters.")]
    public string? Remarks { get; set; }

    [EnumDataType(typeof(FollowUpStatus), ErrorMessage = "Select a valid status.")]
    public FollowUpStatus Status { get; set; } = FollowUpStatus.Planned;

    [Display(Name = "Assigned To")]
    public string? AssignedTo { get; set; }
}

public class FollowUpResponseDto
{
    public int FollowUpId { get; init; }
    public int? CustomerId { get; init; }
    public int? LeadId { get; init; }
    public int? OpportunityId { get; init; }
    public string RelatedTo { get; init; } = string.Empty;
    public DateTime FollowUpDate { get; init; }
    public string Subject { get; init; } = string.Empty;
    public FollowUpType FollowUpType { get; init; }
    public string? Remarks { get; init; }
    public FollowUpStatus Status { get; init; }
    public bool IsOverdue { get; init; }
    public string AssignedTo { get; init; } = string.Empty;
    public string? AssignedToName { get; init; }
    public DateTime? CompletedDate { get; init; }

    public static FollowUpResponseDto From(FollowUp f) => new()
    {
        FollowUpId = f.FollowUpId,
        CustomerId = f.CustomerId,
        LeadId = f.LeadId,
        OpportunityId = f.OpportunityId,
        RelatedTo = f.RelatedTo,
        FollowUpDate = f.FollowUpDate,
        Subject = f.Subject,
        FollowUpType = f.FollowUpType,
        Remarks = f.Remarks,
        Status = f.Status,
        IsOverdue = f.IsOverdue,
        AssignedTo = f.AssignedTo,
        AssignedToName = f.AssignedUser?.FullName,
        CompletedDate = f.CompletedDate
    };
}

public class ActivityRequestDto
{
    [Required(ErrorMessage = "Activity Type is required.")]
    [EnumDataType(typeof(Models.ActivityType), ErrorMessage = "Select a valid activity type.")]
    [Display(Name = "Activity Type")]
    public ActivityType? ActivityType { get; set; }

    [Required(ErrorMessage = "Subject is required.")]
    [StringLength(ValidationRules.SubjectMaxLength, ErrorMessage = "Subject cannot exceed {1} characters.")]
    public string Subject { get; set; } = string.Empty;

    [StringLength(ValidationRules.NotesMaxLength, ErrorMessage = "Description cannot exceed {1} characters.")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Activity date is required.")]
    [DataType(DataType.DateTime)]
    [Display(Name = "Activity Date")]
    public DateTime? ActivityDate { get; set; }

    [Display(Name = "Customer")]
    public int? CustomerId { get; set; }

    [Display(Name = "Lead")]
    public int? LeadId { get; set; }

    [EnumDataType(typeof(ActivityStatus), ErrorMessage = "Select a valid status.")]
    public ActivityStatus Status { get; set; } = ActivityStatus.Planned;

    [Display(Name = "Assigned To")]
    public string? AssignedTo { get; set; }
}
