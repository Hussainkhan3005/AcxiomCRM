using AcxiomCRM.Models;

namespace AcxiomCRM.Dtos;

/// <summary>Common paging/sorting parameters for list pages and list endpoints.</summary>
public class ListQuery
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string? Sort { get; set; }
}

public class CustomerFilter : ListQuery
{
    public string? Name { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Company { get; set; }
    public CustomerStatus? Status { get; set; }
    public string? AssignedTo { get; set; }
}

public class LeadFilter : ListQuery
{
    public string? Name { get; set; }
    public string? Company { get; set; }
    public LeadStatus? Status { get; set; }
    public LeadSource? Source { get; set; }
    public string? AssignedTo { get; set; }
}

public class OpportunityFilter : ListQuery
{
    public string? Name { get; set; }
    public string? Customer { get; set; }
    public OpportunityStage? Stage { get; set; }
    public OpportunityStatus? Status { get; set; }
    public string? AssignedTo { get; set; }
}

public class FollowUpFilter : ListQuery
{
    /// <summary>upcoming | overdue | today (optional quick view)</summary>
    public string? View { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public FollowUpStatus? Status { get; set; }
    public string? AssignedTo { get; set; }
    /// <summary>Related customer or lead name.</summary>
    public string? Related { get; set; }
}

public class ActivityFilter : ListQuery
{
    public ActivityType? Type { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public ActivityStatus? Status { get; set; }
    public string? AssignedTo { get; set; }
    public string? Subject { get; set; }
}

public class AuditFilter : ListQuery
{
    public string? User { get; set; }
    public string? Entity { get; set; }
    public string? Action { get; set; }
    public string? Result { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
}

public class PagedResponse<T>
{
    public IReadOnlyList<T> Items { get; init; } = Array.Empty<T>();
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int TotalCount { get; init; }
    public int TotalPages { get; init; }
}
