using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Common;
using AcxiomCRM.Models;

namespace AcxiomCRM.Dtos;

public class OpportunityRequestDto
{
    [Required(ErrorMessage = "Opportunity Name is required.")]
    [StringLength(150, ErrorMessage = "Opportunity Name cannot exceed {1} characters.")]
    [Display(Name = "Opportunity Name")]
    public string OpportunityName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Customer is required.")]
    [Display(Name = "Customer")]
    public int? CustomerId { get; set; }

    [Display(Name = "Source Lead")]
    public int? LeadId { get; set; }

    [Required(ErrorMessage = "Amount is required.")]
    [Range(0.01, ValidationRules.MaxAmount, ErrorMessage = ValidationRules.AmountMessage)]
    [Display(Name = "Amount (₹)")]
    public decimal? Amount { get; set; }

    [Required(ErrorMessage = "Stage is required.")]
    [EnumDataType(typeof(OpportunityStage), ErrorMessage = "Select a valid stage.")]
    public OpportunityStage? Stage { get; set; } = OpportunityStage.Qualification;

    [Required(ErrorMessage = "Probability is required.")]
    [Range(0, 100, ErrorMessage = ValidationRules.ProbabilityMessage)]
    [Display(Name = "Probability (%)")]
    public int? Probability { get; set; } = 20;

    [Required(ErrorMessage = "Expected Close Date is required.")]
    [DataType(DataType.Date)]
    [DateNotInPast(ErrorMessage = ValidationRules.CloseDateMessage, IgnoreWhenProperty = nameof(Stage), IgnoreWhenValues = "Won,Lost")]
    [Display(Name = "Expected Close Date")]
    public DateTime? ExpectedCloseDate { get; set; }

    [StringLength(100, ErrorMessage = "Source cannot exceed {1} characters.")]
    public string? Source { get; set; }

    [StringLength(ValidationRules.NotesMaxLength, ErrorMessage = "Notes cannot exceed {1} characters.")]
    public string? Notes { get; set; }

    [Display(Name = "Assigned To")]
    public string? AssignedTo { get; set; }
}

public class OpportunityResponseDto
{
    public int OpportunityId { get; init; }
    public string OpportunityName { get; init; } = string.Empty;
    public int CustomerId { get; init; }
    public string? CustomerName { get; init; }
    public int? LeadId { get; init; }
    public decimal Amount { get; init; }
    public OpportunityStage Stage { get; init; }
    public int Probability { get; init; }
    public decimal WeightedAmount { get; init; }
    public DateTime ExpectedCloseDate { get; init; }
    public OpportunityStatus Status { get; init; }
    public string? Source { get; init; }
    public string? Notes { get; init; }
    public string AssignedTo { get; init; } = string.Empty;
    public string? AssignedToName { get; init; }
    public DateTime CreatedDate { get; init; }
    public DateTime? ClosedDate { get; init; }

    public static OpportunityResponseDto From(Opportunity o) => new()
    {
        OpportunityId = o.OpportunityId,
        OpportunityName = o.OpportunityName,
        CustomerId = o.CustomerId,
        CustomerName = o.Customer?.CustomerName,
        LeadId = o.LeadId,
        Amount = o.Amount,
        Stage = o.Stage,
        Probability = o.Probability,
        WeightedAmount = o.WeightedAmount,
        ExpectedCloseDate = o.ExpectedCloseDate,
        Status = o.Status,
        Source = o.Source,
        Notes = o.Notes,
        AssignedTo = o.AssignedTo,
        AssignedToName = o.AssignedUser?.FullName,
        CreatedDate = o.CreatedDate,
        ClosedDate = o.ClosedDate
    };
}

public class PipelineStageSummary
{
    public string Stage { get; init; } = string.Empty;
    public int Count { get; init; }
    public decimal Amount { get; init; }
    public decimal WeightedAmount { get; init; }
}

public class PipelineOwnerSummary
{
    public string OwnerId { get; init; } = string.Empty;
    public string OwnerName { get; init; } = string.Empty;
    public int OpenCount { get; init; }
    public decimal OpenAmount { get; init; }
    public decimal WeightedAmount { get; init; }
    public int WonCount { get; init; }
    public decimal WonAmount { get; init; }
}

public class PipelineSummaryDto
{
    public List<PipelineStageSummary> Stages { get; init; } = new();
    public List<PipelineOwnerSummary> Owners { get; init; } = new();
    public decimal TotalOpenAmount { get; init; }
    public decimal TotalWeightedAmount { get; init; }
}
