using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Common;
using AcxiomCRM.Models;

namespace AcxiomCRM.Dtos;

public class LeadRequestDto
{
    [Required(ErrorMessage = "Lead Name is required.")]
    [StringLength(ValidationRules.NameMaxLength, ErrorMessage = "Lead Name cannot exceed {1} characters.")]
    [Display(Name = "Lead Name")]
    public string LeadName { get; set; } = string.Empty;

    [StringLength(ValidationRules.EmailMaxLength, ErrorMessage = "Email cannot exceed {1} characters.")]
    [RegularExpression(ValidationRules.EmailPattern, ErrorMessage = ValidationRules.EmailMessage)]
    public string? Email { get; set; }

    [RegularExpression(ValidationRules.PhonePattern, ErrorMessage = ValidationRules.PhoneMessage)]
    public string? Phone { get; set; }

    [StringLength(ValidationRules.CompanyMaxLength, ErrorMessage = "Company Name cannot exceed {1} characters.")]
    [Display(Name = "Company Name")]
    public string? CompanyName { get; set; }

    [Required(ErrorMessage = "Lead Source is required.")]
    [EnumDataType(typeof(LeadSource), ErrorMessage = "Select a valid lead source.")]
    [Display(Name = "Lead Source")]
    public LeadSource? Source { get; set; }

    [Required(ErrorMessage = "Lead Status is required.")]
    [EnumDataType(typeof(LeadStatus), ErrorMessage = "Select a valid lead status.")]
    [Display(Name = "Lead Status")]
    public LeadStatus? Status { get; set; } = LeadStatus.New;

    [EnumDataType(typeof(LeadPriority), ErrorMessage = "Select a valid priority.")]
    public LeadPriority Priority { get; set; } = LeadPriority.Medium;

    [Range(0, ValidationRules.MaxLeadValue, ErrorMessage = ValidationRules.ExpectedValueMessage)]
    [Display(Name = "Expected Value (₹)")]
    public decimal ExpectedValue { get; set; }

    [StringLength(ValidationRules.NotesMaxLength, ErrorMessage = "Notes cannot exceed {1} characters.")]
    public string? Notes { get; set; }

    [Display(Name = "Assigned To")]
    public string? AssignedTo { get; set; }
}

/// <summary>Converts a Qualified lead into a customer (new or existing) and optionally an opportunity.</summary>
public class LeadConvertDto
{
    [Display(Name = "Existing customer")]
    public int? ExistingCustomerId { get; set; }

    [StringLength(ValidationRules.NameMaxLength, ErrorMessage = "Customer Name cannot exceed {1} characters.")]
    [Display(Name = "Customer Name")]
    public string? CustomerName { get; set; }

    [StringLength(ValidationRules.EmailMaxLength)]
    [RegularExpression(ValidationRules.EmailPattern, ErrorMessage = ValidationRules.EmailMessage)]
    public string? Email { get; set; }

    [RegularExpression(ValidationRules.PhonePattern, ErrorMessage = ValidationRules.PhoneMessage)]
    public string? Phone { get; set; }

    [StringLength(ValidationRules.CompanyMaxLength)]
    [Display(Name = "Company Name")]
    public string? CompanyName { get; set; }

    [Display(Name = "Also create an opportunity")]
    public bool CreateOpportunity { get; set; } = true;

    [StringLength(150, ErrorMessage = "Opportunity Name cannot exceed {1} characters.")]
    [Display(Name = "Opportunity Name")]
    public string? OpportunityName { get; set; }

    [Range(0.01, ValidationRules.MaxAmount, ErrorMessage = ValidationRules.AmountMessage)]
    [Display(Name = "Amount (₹)")]
    public decimal? Amount { get; set; }

    [Range(0, 100, ErrorMessage = ValidationRules.ProbabilityMessage)]
    [Display(Name = "Probability (%)")]
    public int? Probability { get; set; }

    [DataType(DataType.Date)]
    [DateNotInPast(ErrorMessage = ValidationRules.CloseDateMessage)]
    [Display(Name = "Expected Close Date")]
    public DateTime? ExpectedCloseDate { get; set; }
}

public class LeadResponseDto
{
    public int LeadId { get; init; }
    public string LeadCode { get; init; } = string.Empty;
    public string LeadName { get; init; } = string.Empty;
    public string? Email { get; init; }
    public string? Phone { get; init; }
    public string? CompanyName { get; init; }
    public LeadSource Source { get; init; }
    public LeadStatus Status { get; init; }
    public LeadPriority Priority { get; init; }
    public decimal ExpectedValue { get; init; }
    public string? Notes { get; init; }
    public string AssignedTo { get; init; } = string.Empty;
    public string? AssignedToName { get; init; }
    public DateTime CreatedDate { get; init; }
    public int? ConvertedCustomerId { get; init; }
    public int? ConvertedOpportunityId { get; init; }
    public DateTime? ConvertedDate { get; init; }

    public static LeadResponseDto From(Lead l) => new()
    {
        LeadId = l.LeadId,
        LeadCode = l.LeadCode,
        LeadName = l.LeadName,
        Email = l.Email,
        Phone = l.Phone,
        CompanyName = l.CompanyName,
        Source = l.Source,
        Status = l.Status,
        Priority = l.Priority,
        ExpectedValue = l.ExpectedValue,
        Notes = l.Notes,
        AssignedTo = l.AssignedTo,
        AssignedToName = l.AssignedUser?.FullName,
        CreatedDate = l.CreatedDate,
        ConvertedCustomerId = l.ConvertedCustomerId,
        ConvertedOpportunityId = l.ConvertedOpportunityId,
        ConvertedDate = l.ConvertedDate
    };
}
