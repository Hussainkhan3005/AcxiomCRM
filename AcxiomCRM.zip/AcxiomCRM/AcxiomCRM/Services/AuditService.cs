using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Models;

namespace AcxiomCRM.Services;

public interface IAuditService
{
    Task LogAsync(string action, string entityName, object? recordId = null, object? oldValue = null,
        object? newValue = null, string result = AuditResults.Success, string? details = null,
        string? userId = null, string? userName = null);
}

/// <summary>Writes append-only audit entries. Never receives passwords, hashes or tokens.</summary>
public class AuditService : IAuditService
{
    private readonly ApplicationDbContext _db;
    private readonly ICurrentUserService _user;
    private readonly ILogger<AuditService> _logger;

    public AuditService(ApplicationDbContext db, ICurrentUserService user, ILogger<AuditService> logger)
    {
        _db = db;
        _user = user;
        _logger = logger;
    }

    public async Task LogAsync(string action, string entityName, object? recordId = null, object? oldValue = null,
        object? newValue = null, string result = AuditResults.Success, string? details = null,
        string? userId = null, string? userName = null)
    {
        try
        {
            _db.AuditLogs.Add(new AuditLog
            {
                UserId = userId ?? (_user.IsAuthenticated ? _user.UserId : null),
                UserName = Truncate(userName ?? (_user.IsAuthenticated ? _user.UserName : null), 256),
                Action = action,
                EntityName = entityName,
                RecordId = Truncate(recordId?.ToString(), 100),
                OldValue = AuditSnapshot.ToJson(oldValue),
                NewValue = AuditSnapshot.ToJson(newValue),
                Result = result,
                Details = Truncate(details, 500),
                CreatedDate = DateTime.Now,
                IpAddress = Truncate(_user.IpAddress, 64)
            });
            await _db.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            // Auditing must never break the user's operation; failures go to the application log.
            _logger.LogError(ex, "Failed to write audit entry {Action} on {Entity}", action, entityName);
        }
    }

    private static string? Truncate(string? value, int max) =>
        value is null || value.Length <= max ? value : value[..max];
}
