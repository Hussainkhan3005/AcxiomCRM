using System.Globalization;
using System.Text;
using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IReportService
{
    /// <summary>Runs a report within the user's data scope. Returns null for an unknown report key.</summary>
    Task<ReportResult?> RunAsync(string key, ReportRequest request, bool forExport);
    string ToCsv(ReportResult result);
}

public class ReportService : IReportService
{
    private readonly ApplicationDbContext _db;
    private readonly ICurrentUserService _user;
    private readonly ILookupService _lookups;

    private record ReportData(List<ReportColumn> Columns, List<object?[]> Rows, List<string> StatusOptions);

    public ReportService(ApplicationDbContext db, ICurrentUserService user, ILookupService lookups)
    {
        _db = db;
        _user = user;
        _lookups = lookups;
    }

    public async Task<ReportResult?> RunAsync(string key, ReportRequest request, bool forExport)
    {
        var definition = ReportCatalog.Find(key);
        if (definition is null) return null;

        var visible = await _user.GetVisibleUserIdsAsync();
        var data = definition.Key switch
        {
            "customers" => await CustomersAsync(request, visible),
            "leads" => await LeadsAsync(request, visible),
            "followups" => await FollowUpsAsync(request, visible),
            "opportunities" => await OpportunitiesAsync(request, visible),
            "pipeline" => await PipelineAsync(request, visible),
            "conversion" => await ConversionAsync(request, visible),
            "useractivity" => await UserActivityAsync(request, visible),
            "audit" => await AuditAsync(request),
            _ => new ReportData(new(), new(), new())
        };

        var rows = data.Rows;
        if (request.SortColumn is int column && column >= 0 && column < data.Columns.Count)
            rows.Sort((x, y) => request.Desc ? Compare(y[column], x[column]) : Compare(x[column], y[column]));

        var result = new ReportResult
        {
            Definition = definition,
            Request = request,
            Columns = data.Columns,
            TotalCount = rows.Count,
            StatusOptions = data.StatusOptions.Select(s => new SelectListItem(s, s)).ToList(),
            OwnerOptions = definition.HasOwnerFilter && !_user.IsSalesExecutive ? await _lookups.AssignableUsersAsync() : new()
        };

        if (definition.ShowTotals && rows.Count > 0)
        {
            var totals = new object?[data.Columns.Count];
            totals[0] = "Total";
            for (var i = 1; i < data.Columns.Count; i++)
            {
                if (data.Columns[i].Format is ColumnFormat.Money or ColumnFormat.Number)
                    totals[i] = rows.Sum(r => r[i] is null ? 0m : Convert.ToDecimal(r[i], CultureInfo.InvariantCulture));
            }
            result.Totals = totals;
        }

        if (forExport)
        {
            result.Rows = rows;
        }
        else
        {
            result.PageSize = Math.Clamp(request.PageSize, 5, 100);
            result.Page = Math.Max(1, request.Page);
            result.Rows = rows.Skip((result.Page - 1) * result.PageSize).Take(result.PageSize).ToList();
        }

        return result;
    }

    // ---------------------------------------------------------------- reports

    private async Task<ReportData> CustomersAsync(ReportRequest r, List<string>? visible)
    {
        var q = _db.Customers.AsNoTracking().WhereVisible(visible);
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(c => c.CreatedDate >= f);
        if (to is DateTime t) q = q.Where(c => c.CreatedDate < t);
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var o = r.AssignedTo; q = q.Where(c => c.AssignedTo == o); }
        if (Enum.TryParse<CustomerStatus>(r.Status, out var status)) q = q.Where(c => c.Status == status);

        var data = await q.OrderBy(c => c.CustomerName)
            .Select(c => new { c.CustomerCode, c.CustomerName, c.CompanyName, c.Email, c.Phone, c.City, c.Status, Owner = c.AssignedUser!.FullName, c.CreatedDate })
            .ToListAsync();

        return new ReportData(
            new List<ReportColumn>
            {
                new("Code"), new("Customer"), new("Company"), new("Email"), new("Phone"), new("City"),
                new("Status"), new("Owner"), new("Created", ColumnFormat.Date)
            },
            data.Select(c => new object?[] { c.CustomerCode, c.CustomerName, c.CompanyName, c.Email, c.Phone, c.City, c.Status.ToString(), c.Owner, c.CreatedDate }).ToList(),
            Enum.GetNames<CustomerStatus>().ToList());
    }

    private async Task<ReportData> LeadsAsync(ReportRequest r, List<string>? visible)
    {
        var q = _db.Leads.AsNoTracking().WhereVisible(visible);
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(l => l.CreatedDate >= f);
        if (to is DateTime t) q = q.Where(l => l.CreatedDate < t);
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var o = r.AssignedTo; q = q.Where(l => l.AssignedTo == o); }
        if (Enum.TryParse<LeadStatus>(r.Status, out var status)) q = q.Where(l => l.Status == status);

        var data = await q.OrderByDescending(l => l.CreatedDate)
            .Select(l => new { l.LeadCode, l.LeadName, l.CompanyName, l.Source, l.Status, l.Priority, l.ExpectedValue, Owner = l.AssignedUser!.FullName, l.CreatedDate, l.ConvertedDate })
            .ToListAsync();

        return new ReportData(
            new List<ReportColumn>
            {
                new("Code"), new("Lead"), new("Company"), new("Source"), new("Status"), new("Priority"),
                new("Expected value", ColumnFormat.Money), new("Owner"), new("Created", ColumnFormat.Date), new("Converted on", ColumnFormat.Date)
            },
            data.Select(l => new object?[]
            {
                l.LeadCode, l.LeadName, l.CompanyName, l.Source.DisplayName(), l.Status.ToString(), l.Priority.ToString(),
                l.ExpectedValue, l.Owner, l.CreatedDate, l.ConvertedDate
            }).ToList(),
            Enum.GetNames<LeadStatus>().ToList());
    }

    private async Task<ReportData> FollowUpsAsync(ReportRequest r, List<string>? visible)
    {
        var q = _db.FollowUps.AsNoTracking().WhereVisible(visible);
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(x => x.FollowUpDate >= f);
        if (to is DateTime t) q = q.Where(x => x.FollowUpDate < t);
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var o = r.AssignedTo; q = q.Where(x => x.AssignedTo == o); }

        var now = DateTime.Now;
        if (r.Status == "Overdue") q = q.Where(x => x.Status == FollowUpStatus.Planned && x.FollowUpDate < now);
        else if (Enum.TryParse<FollowUpStatus>(r.Status, out var status)) q = q.Where(x => x.Status == status);

        var data = await q.OrderBy(x => x.FollowUpDate)
            .Select(x => new
            {
                x.FollowUpDate,
                x.Subject,
                x.FollowUpType,
                Related = x.Opportunity != null ? x.Opportunity.OpportunityName
                    : x.Customer != null ? x.Customer.CustomerName
                    : x.Lead != null ? x.Lead.LeadName : "-",
                x.Status,
                Owner = x.AssignedUser!.FullName,
                x.CompletedDate
            })
            .ToListAsync();

        return new ReportData(
            new List<ReportColumn>
            {
                new("Date", ColumnFormat.DateTime), new("Subject"), new("Type"), new("Related to"),
                new("Status"), new("Owner"), new("Completed on", ColumnFormat.DateTime)
            },
            data.Select(x => new object?[]
            {
                x.FollowUpDate, x.Subject, x.FollowUpType.ToString(), x.Related,
                x.Status == FollowUpStatus.Planned && x.FollowUpDate < now ? "Overdue" : x.Status.ToString(),
                x.Owner, x.CompletedDate
            }).ToList(),
            Enum.GetNames<FollowUpStatus>().Append("Overdue").ToList());
    }

    private async Task<ReportData> OpportunitiesAsync(ReportRequest r, List<string>? visible)
    {
        var q = _db.Opportunities.AsNoTracking().WhereVisible(visible);
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(o => o.CreatedDate >= f);
        if (to is DateTime t) q = q.Where(o => o.CreatedDate < t);
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var ow = r.AssignedTo; q = q.Where(o => o.AssignedTo == ow); }
        if (Enum.TryParse<OpportunityStage>(r.Status, out var stage)) q = q.Where(o => o.Stage == stage);

        var data = await q.OrderBy(o => o.ExpectedCloseDate)
            .Select(o => new { o.OpportunityName, Customer = o.Customer!.CustomerName, o.Stage, o.Amount, o.Probability, o.ExpectedCloseDate, Owner = o.AssignedUser!.FullName })
            .ToListAsync();

        return new ReportData(
            new List<ReportColumn>
            {
                new("Opportunity"), new("Customer"), new("Stage"), new("Amount", ColumnFormat.Money),
                new("Probability", ColumnFormat.Percent), new("Weighted", ColumnFormat.Money),
                new("Expected close", ColumnFormat.Date), new("Owner")
            },
            data.Select(o => new object?[]
            {
                o.OpportunityName, o.Customer, o.Stage.ToString(), o.Amount, o.Probability,
                Math.Round(o.Amount * o.Probability / 100m, 2), o.ExpectedCloseDate, o.Owner
            }).ToList(),
            Enum.GetNames<OpportunityStage>().ToList());
    }

    private async Task<ReportData> PipelineAsync(ReportRequest r, List<string>? visible)
    {
        var q = _db.Opportunities.AsNoTracking().WhereVisible(visible);
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(o => o.CreatedDate >= f);
        if (to is DateTime t) q = q.Where(o => o.CreatedDate < t);
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var ow = r.AssignedTo; q = q.Where(o => o.AssignedTo == ow); }

        var data = await q.Select(o => new { o.Stage, o.Status, o.Amount, o.Probability, Owner = o.AssignedUser!.FullName }).ToListAsync();

        var rows = new List<object?[]>();
        foreach (var stage in Enum.GetValues<OpportunityStage>())
        {
            var items = data.Where(o => o.Stage == stage).ToList();
            rows.Add(new object?[]
            {
                "By stage", stage.ToString(), items.Count, items.Sum(o => o.Amount),
                Math.Round(items.Sum(o => o.Amount * o.Probability / 100m), 2)
            });
        }
        foreach (var group in data.Where(o => o.Status == OpportunityStatus.Open).GroupBy(o => o.Owner).OrderBy(g => g.Key))
        {
            rows.Add(new object?[]
            {
                "By owner (open)", group.Key, group.Count(), group.Sum(o => o.Amount),
                Math.Round(group.Sum(o => o.Amount * o.Probability / 100m), 2)
            });
        }

        return new ReportData(
            new List<ReportColumn>
            {
                new("Group"), new("Stage / owner"), new("Opportunities", ColumnFormat.Number),
                new("Amount", ColumnFormat.Money), new("Weighted amount", ColumnFormat.Money)
            },
            rows, new List<string>());
    }

    private async Task<ReportData> ConversionAsync(ReportRequest r, List<string>? visible)
    {
        var leads = _db.Leads.AsNoTracking().WhereVisible(visible);
        var opportunities = _db.Opportunities.AsNoTracking().WhereVisible(visible).Where(o => o.Status != OpportunityStatus.Open);
        var (from, to) = Range(r);
        if (from is DateTime f)
        {
            leads = leads.Where(l => l.CreatedDate >= f);
            opportunities = opportunities.Where(o => o.ClosedDate >= f);
        }
        if (to is DateTime t)
        {
            leads = leads.Where(l => l.CreatedDate < t);
            opportunities = opportunities.Where(o => o.ClosedDate < t);
        }
        if (!string.IsNullOrEmpty(r.AssignedTo))
        {
            var ow = r.AssignedTo;
            leads = leads.Where(l => l.AssignedTo == ow);
            opportunities = opportunities.Where(o => o.AssignedTo == ow);
        }

        var leadData = await leads.Select(l => new { l.AssignedTo, Owner = l.AssignedUser!.FullName, l.Status }).ToListAsync();
        var oppData = await opportunities.Select(o => new { o.AssignedTo, Owner = o.AssignedUser!.FullName, o.Status, o.Amount }).ToListAsync();

        var owners = leadData.Select(l => (l.AssignedTo, l.Owner))
            .Concat(oppData.Select(o => (o.AssignedTo, o.Owner)))
            .Distinct()
            .OrderBy(o => o.Owner);

        var rows = new List<object?[]>();
        foreach (var (ownerId, ownerName) in owners)
        {
            var ownerLeads = leadData.Where(l => l.AssignedTo == ownerId).ToList();
            var ownerOpps = oppData.Where(o => o.AssignedTo == ownerId).ToList();
            var converted = ownerLeads.Count(l => l.Status == LeadStatus.Converted);
            var lostLeads = ownerLeads.Count(l => l.Status == LeadStatus.Lost);
            var won = ownerOpps.Count(o => o.Status == OpportunityStatus.Won);
            var lost = ownerOpps.Count(o => o.Status == OpportunityStatus.Lost);
            rows.Add(new object?[]
            {
                ownerName, ownerLeads.Count, converted, lostLeads,
                Percent(converted, ownerLeads.Count), won, lost, Percent(won, won + lost),
                ownerOpps.Where(o => o.Status == OpportunityStatus.Won).Sum(o => o.Amount)
            });
        }

        return new ReportData(
            new List<ReportColumn>
            {
                new("Owner"), new("Leads", ColumnFormat.Number), new("Converted", ColumnFormat.Number),
                new("Lost leads", ColumnFormat.Number), new("Conversion rate", ColumnFormat.Percent),
                new("Deals won", ColumnFormat.Number), new("Deals lost", ColumnFormat.Number),
                new("Win rate", ColumnFormat.Percent), new("Won amount", ColumnFormat.Money)
            },
            rows, new List<string>());
    }

    private async Task<ReportData> UserActivityAsync(ReportRequest r, List<string>? visible)
    {
        var users = _db.Users.AsNoTracking();
        if (visible is not null) users = users.Where(u => visible.Contains(u.Id));
        if (!string.IsNullOrEmpty(r.AssignedTo)) { var ow = r.AssignedTo; users = users.Where(u => u.Id == ow); }
        var userList = await users.Select(u => new { u.Id, u.FullName, u.Email }).ToListAsync();
        var ids = userList.Select(u => u.Id).ToList();

        var roles = await (from ur in _db.UserRoles
                           join role in _db.Roles on ur.RoleId equals role.Id
                           where ids.Contains(ur.UserId)
                           select new { ur.UserId, role.Name }).ToListAsync();

        var logs = _db.AuditLogs.AsNoTracking().Where(a => a.UserId != null && ids.Contains(a.UserId));
        var (from, to) = Range(r);
        if (from is DateTime f) logs = logs.Where(a => a.CreatedDate >= f);
        if (to is DateTime t) logs = logs.Where(a => a.CreatedDate < t);

        var counts = await logs.GroupBy(a => new { a.UserId, a.Action })
            .Select(g => new { g.Key.UserId, g.Key.Action, Count = g.Count(), Last = g.Max(x => x.CreatedDate) })
            .ToListAsync();

        var rows = userList.OrderBy(u => u.FullName).Select(u =>
        {
            var mine = counts.Where(c => c.UserId == u.Id).ToList();
            int Count(params string[] actions) => mine.Where(c => actions.Contains(c.Action)).Sum(c => c.Count);
            return new object?[]
            {
                u.FullName, AppRoles.DisplayName(roles.FirstOrDefault(x => x.UserId == u.Id)?.Name),
                Count(AuditActions.Login), Count(AuditActions.FailedLogin, AuditActions.Lockout, AuditActions.LockedOutAttempt),
                Count(AuditActions.Create), Count(AuditActions.Update, AuditActions.StatusChange, AuditActions.StageChange, AuditActions.Complete, AuditActions.Convert),
                Count(AuditActions.Delete), mine.Sum(c => c.Count),
                mine.Count == 0 ? null : (object?)mine.Max(c => c.Last)
            };
        }).ToList();

        return new ReportData(
            new List<ReportColumn>
            {
                new("User"), new("Role"), new("Logins", ColumnFormat.Number), new("Failed logins", ColumnFormat.Number),
                new("Creates", ColumnFormat.Number), new("Updates", ColumnFormat.Number), new("Deletes", ColumnFormat.Number),
                new("Total actions", ColumnFormat.Number), new("Last activity", ColumnFormat.DateTime)
            },
            rows, new List<string>());
    }

    private async Task<ReportData> AuditAsync(ReportRequest r)
    {
        var q = _db.AuditLogs.AsNoTracking();
        var (from, to) = Range(r);
        if (from is DateTime f) q = q.Where(a => a.CreatedDate >= f);
        if (to is DateTime t) q = q.Where(a => a.CreatedDate < t);
        if (!string.IsNullOrEmpty(r.Status)) { var action = r.Status; q = q.Where(a => a.Action == action); }

        var data = await q.OrderByDescending(a => a.CreatedDate).Take(5000)
            .Select(a => new { a.CreatedDate, a.UserName, a.Action, a.EntityName, a.RecordId, a.Result, a.IpAddress })
            .ToListAsync();

        return new ReportData(
            new List<ReportColumn>
            {
                new("Timestamp", ColumnFormat.DateTime), new("User"), new("Action"), new("Module"),
                new("Record"), new("Result"), new("IP address")
            },
            data.Select(a => new object?[] { a.CreatedDate, a.UserName, a.Action, a.EntityName, a.RecordId, a.Result, a.IpAddress }).ToList(),
            AuditActions.All.ToList());
    }

    // ---------------------------------------------------------------- export

    public string ToCsv(ReportResult result)
    {
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(",", result.Columns.Select(c => Escape(c.Header))));
        foreach (var row in result.Rows)
            sb.AppendLine(string.Join(",", row.Select((value, i) => Escape(CsvValue(value, result.Columns[i])))));
        if (result.Totals is not null)
            sb.AppendLine(string.Join(",", result.Totals.Select((value, i) => Escape(CsvValue(value, result.Columns[i])))));
        return sb.ToString();
    }

    private static string CsvValue(object? value, ReportColumn column) => value switch
    {
        null => string.Empty,
        DateTime d when column.Format == ColumnFormat.Date => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        DateTime d => d.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
        decimal m => m.ToString(CultureInfo.InvariantCulture),
        // Neutralise spreadsheet formula injection in text cells.
        string s when s.Length > 0 && "=+-@".Contains(s[0]) => "'" + s,
        _ => Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty
    };

    private static string Escape(string value) =>
        value.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0 ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;

    // ---------------------------------------------------------------- helpers

    private static (DateTime? From, DateTime? To) Range(ReportRequest r) => (r.From?.Date, r.To?.Date.AddDays(1));

    private static decimal Percent(int part, int whole) => whole == 0 ? 0 : Math.Round(part * 100m / whole, 1);

    private static int Compare(object? a, object? b)
    {
        if (a is null && b is null) return 0;
        if (a is null) return -1;
        if (b is null) return 1;
        if (a.GetType() == b.GetType() && a is IComparable comparable) return comparable.CompareTo(b);
        return string.Compare(a.ToString(), b.ToString(), StringComparison.OrdinalIgnoreCase);
    }
}
