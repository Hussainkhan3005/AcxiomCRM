using AcxiomCRM.Common;
using AcxiomCRM.Data;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public abstract class ServiceBase
{
    protected ServiceBase(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger logger)
    {
        Db = db;
        CurrentUser = currentUser;
        Audit = audit;
        Logger = logger;
    }

    protected ApplicationDbContext Db { get; }
    protected ICurrentUserService CurrentUser { get; }
    protected IAuditService Audit { get; }
    protected ILogger Logger { get; }

    /// <summary>Saves changes; unique-index violations become a friendly 409-style error instead of an exception.</summary>
    protected async Task<bool> TrySaveAsync<T>(ServiceResult<T> result, string conflictMessage)
    {
        try
        {
            await Db.SaveChangesAsync();
            return true;
        }
        catch (DbUpdateException ex)
        {
            Logger.LogWarning(ex, "Database update failed");
            Db.ChangeTracker.Clear();
            result.AddError(string.Empty, conflictMessage, conflict: true);
            return false;
        }
    }

    protected static string? Clean(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
