using System.Security.Claims;
using AcxiomCRM.Common;
using AcxiomCRM.Data;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

/// <summary>
/// Information about the signed-in user plus the row-level "scope" rules:
/// Admin = everything, Manager = self + direct reports, Sales Executive = self.
/// </summary>
public interface ICurrentUserService
{
    string UserId { get; }
    string UserName { get; }
    bool IsAuthenticated { get; }
    bool IsAdmin { get; }
    bool IsManager { get; }
    bool IsSalesExecutive { get; }
    string? IpAddress { get; }

    /// <summary>User ids whose records are visible; null means unrestricted.</summary>
    Task<List<string>?> GetVisibleUserIdsAsync();

    Task<bool> CanAssignToAsync(string userId);

    /// <summary>
    /// Decides the owner of a record being saved. Returns null when the requested owner is not allowed
    /// (e.g. a Sales Executive tampering with the form to assign a record to someone else).
    /// </summary>
    Task<string?> ResolveAssigneeAsync(string? requested, string? current = null);
}

public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _http;
    private readonly ApplicationDbContext _db;
    private List<string>? _visible;
    private bool _visibleLoaded;

    public CurrentUserService(IHttpContextAccessor http, ApplicationDbContext db)
    {
        _http = http;
        _db = db;
    }

    private ClaimsPrincipal? Principal => _http.HttpContext?.User;

    public string UserId => Principal?.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;
    public string UserName => Principal?.Identity?.Name ?? "anonymous";
    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;
    public bool IsAdmin => Principal?.IsInRole(AppRoles.Admin) == true;
    public bool IsManager => Principal?.IsInRole(AppRoles.Manager) == true;
    public bool IsSalesExecutive => Principal?.IsInRole(AppRoles.SalesExecutive) == true;
    public string? IpAddress => _http.HttpContext?.Connection.RemoteIpAddress?.ToString();

    public async Task<List<string>?> GetVisibleUserIdsAsync()
    {
        if (_visibleLoaded) return _visible;
        _visibleLoaded = true;

        if (IsAdmin)
        {
            _visible = null;
        }
        else if (IsManager)
        {
            var me = UserId;
            _visible = await _db.Users.Where(u => u.ManagerId == me).Select(u => u.Id).ToListAsync();
            _visible.Add(me);
        }
        else
        {
            _visible = new List<string> { UserId };
        }

        return _visible;
    }

    public async Task<bool> CanAssignToAsync(string userId)
    {
        var target = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == userId);
        if (target is null || !target.IsActive) return false;
        var visible = await GetVisibleUserIdsAsync();
        return visible is null || visible.Contains(userId);
    }

    public async Task<string?> ResolveAssigneeAsync(string? requested, string? current = null)
    {
        if (string.IsNullOrWhiteSpace(requested)) return current ?? UserId;
        if (requested == current || requested == UserId) return requested;
        if (!IsAdmin && !IsManager) return null;
        return await CanAssignToAsync(requested) ? requested : null;
    }
}
