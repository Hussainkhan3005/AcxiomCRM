using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IFollowUpService
{
    Task<PagedResult<FollowUp>> SearchAsync(FollowUpFilter filter);
    Task<FollowUp?> GetAsync(int id);
    Task<ServiceResult<FollowUp>> CreateAsync(FollowUpRequestDto dto);
    Task<ServiceResult<FollowUp>> UpdateAsync(int id, FollowUpRequestDto dto);
    Task<ServiceResult<FollowUp>> CompleteAsync(int id, string? remarks);
    Task<ServiceResult<FollowUp>> MarkMissedAsync(int id);
    Task<ServiceResult<bool>> DeleteAsync(int id);
    Task<(int Overdue, int Today)> GetPendingCountsAsync();
    Task<List<FollowUp>> GetUpcomingAsync(int take);
}

public class FollowUpService : ServiceBase, IFollowUpService
{
    public FollowUpService(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger<FollowUpService> logger)
        : base(db, currentUser, audit, logger) { }

    private IQueryable<FollowUp> WithRelations(IQueryable<FollowUp> q) =>
        q.Include(f => f.Customer).Include(f => f.Lead).Include(f => f.Opportunity).Include(f => f.AssignedUser);

    public async Task<PagedResult<FollowUp>> SearchAsync(FollowUpFilter f)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var q = WithRelations(Db.FollowUps.AsNoTracking()).WhereVisible(visible);
        var now = DateTime.Now;
        var today = DateTime.Today;

        switch (f.View)
        {
            case "upcoming":
                q = q.Where(x => x.Status == FollowUpStatus.Planned && x.FollowUpDate >= now);
                break;
            case "overdue":
                q = q.Where(x => x.Status == FollowUpStatus.Planned && x.FollowUpDate < now);
                break;
            case "today":
                var tomorrow = today.AddDays(1);
                q = q.Where(x => x.Status == FollowUpStatus.Planned && x.FollowUpDate >= today && x.FollowUpDate < tomorrow);
                break;
        }

        if (f.From.HasValue)
        {
            var from = f.From.Value.Date;
            q = q.Where(x => x.FollowUpDate >= from);
        }
        if (f.To.HasValue)
        {
            var to = f.To.Value.Date.AddDays(1);
            q = q.Where(x => x.FollowUpDate < to);
        }
        if (f.Status.HasValue)
        {
            var status = f.Status.Value;
            q = q.Where(x => x.Status == status);
        }
        if (!string.IsNullOrWhiteSpace(f.AssignedTo))
        {
            var owner = f.AssignedTo;
            q = q.Where(x => x.AssignedTo == owner);
        }
        if (!string.IsNullOrWhiteSpace(f.Related))
        {
            var p = f.Related.ToLikePattern();
            q = q.Where(x => (x.Customer != null && EF.Functions.Like(x.Customer.CustomerName, p))
                             || (x.Lead != null && EF.Functions.Like(x.Lead.LeadName, p))
                             || (x.Opportunity != null && EF.Functions.Like(x.Opportunity.OpportunityName, p)));
        }

        q = f.Sort switch
        {
            "date_desc" => q.OrderByDescending(x => x.FollowUpDate),
            "subject" => q.OrderBy(x => x.Subject),
            "subject_desc" => q.OrderByDescending(x => x.Subject),
            "status" => q.OrderBy(x => x.Status),
            "status_desc" => q.OrderByDescending(x => x.Status),
            _ => q.OrderBy(x => x.FollowUpDate)
        };

        return await q.ToPagedAsync(f.Page, f.PageSize);
    }

    public async Task<FollowUp?> GetAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await WithRelations(Db.FollowUps.AsNoTracking()).WhereVisible(visible)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
    }

    public async Task<ServiceResult<FollowUp>> CreateAsync(FollowUpRequestDto dto)
    {
        Normalize(dto);
        dto.Status = FollowUpStatus.Planned; // new follow-ups are always planned
        var result = new ServiceResult<FollowUp>();
        ServerValidator.Validate(dto, result);
        await ValidateBusinessRulesAsync(dto, result, isNew: true, dateChanged: true);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var followUp = new FollowUp
        {
            CustomerId = dto.CustomerId,
            LeadId = dto.LeadId,
            OpportunityId = dto.OpportunityId,
            FollowUpDate = dto.FollowUpDate!.Value,
            Subject = dto.Subject,
            FollowUpType = dto.FollowUpType!.Value,
            Remarks = dto.Remarks,
            Status = FollowUpStatus.Planned,
            AssignedTo = owner!,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        };

        Db.FollowUps.Add(followUp);
        if (!await TrySaveAsync(result, "The follow-up could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Create, AuditEntities.FollowUp, followUp.FollowUpId, newValue: followUp);
        return result.WithData(followUp);
    }

    public async Task<ServiceResult<FollowUp>> UpdateAsync(int id, FollowUpRequestDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var followUp = await Db.FollowUps.WhereVisible(visible).FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (followUp is null) return ServiceResult<FollowUp>.Missing();

        Normalize(dto);
        var result = new ServiceResult<FollowUp>();
        ServerValidator.Validate(dto, result);

        if (!FollowUpWorkflow.CanTransition(followUp.Status, dto.Status))
            result.AddError(nameof(dto.Status), $"A {followUp.Status} follow-up cannot be changed to {dto.Status}.");

        var dateChanged = dto.FollowUpDate.HasValue && dto.FollowUpDate.Value != followUp.FollowUpDate;
        await ValidateBusinessRulesAsync(dto, result, isNew: false, dateChanged: dateChanged);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo, followUp.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var before = AuditSnapshot.ToJson(followUp);
        var oldDate = followUp.FollowUpDate;
        var oldStatus = followUp.Status;

        followUp.CustomerId = dto.CustomerId;
        followUp.LeadId = dto.LeadId;
        followUp.OpportunityId = dto.OpportunityId;
        followUp.FollowUpDate = dto.FollowUpDate!.Value;
        followUp.Subject = dto.Subject;
        followUp.FollowUpType = dto.FollowUpType!.Value;
        followUp.Remarks = dto.Remarks;
        followUp.Status = dto.Status;
        followUp.AssignedTo = owner!;
        if (dto.Status == FollowUpStatus.Completed && oldStatus != FollowUpStatus.Completed)
            followUp.CompletedDate = DateTime.Now;

        if (!await TrySaveAsync(result, "The follow-up could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Update, AuditEntities.FollowUp, id, before, followUp);
        if (dateChanged)
            await Audit.LogAsync(AuditActions.Reschedule, AuditEntities.FollowUp, id,
                UiHelpers.DateAndTime(oldDate), UiHelpers.DateAndTime(followUp.FollowUpDate));
        if (oldStatus != followUp.Status)
            await Audit.LogAsync(AuditActions.StatusChange, AuditEntities.FollowUp, id, oldStatus.ToString(), followUp.Status.ToString());

        return result.WithData(followUp);
    }

    /// <summary>
    /// Completes a follow-up and updates the related CRM record: an Activity is logged,
    /// and a New lead moves to Contacted.
    /// </summary>
    public async Task<ServiceResult<FollowUp>> CompleteAsync(int id, string? remarks)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var followUp = await Db.FollowUps.Include(f => f.Lead).WhereVisible(visible).FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (followUp is null) return ServiceResult<FollowUp>.Missing();
        if (!FollowUpWorkflow.CanTransition(followUp.Status, FollowUpStatus.Completed))
            return ServiceResult<FollowUp>.Failure(string.Empty, $"A {followUp.Status} follow-up cannot be completed.");

        var cleanRemarks = Clean(remarks);
        if (cleanRemarks is { Length: > ValidationRules.NotesMaxLength })
            return ServiceResult<FollowUp>.Failure("remarks", $"Remarks cannot exceed {ValidationRules.NotesMaxLength} characters.");

        var before = AuditSnapshot.ToJson(followUp);
        followUp.Status = FollowUpStatus.Completed;
        followUp.CompletedDate = DateTime.Now;
        if (cleanRemarks is not null) followUp.Remarks = cleanRemarks;

        Db.Activities.Add(new Activity
        {
            ActivityType = followUp.FollowUpType switch
            {
                FollowUpType.Call => ActivityType.Call,
                FollowUpType.Email => ActivityType.Email,
                _ => ActivityType.Meeting
            },
            Subject = followUp.Subject,
            Description = followUp.Remarks,
            ActivityDate = DateTime.Now,
            CustomerId = followUp.CustomerId,
            LeadId = followUp.LeadId,
            Status = ActivityStatus.Completed,
            AssignedTo = followUp.AssignedTo,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        });

        var leadPromoted = false;
        if (followUp.Lead is { Status: LeadStatus.New })
        {
            followUp.Lead.Status = LeadStatus.Contacted;
            followUp.Lead.ModifiedDate = DateTime.Now;
            leadPromoted = true;
        }

        var result = new ServiceResult<FollowUp>();
        if (!await TrySaveAsync(result, "The follow-up could not be completed.")) return result;

        await Audit.LogAsync(AuditActions.Complete, AuditEntities.FollowUp, id, before, followUp);
        if (leadPromoted)
            await Audit.LogAsync(AuditActions.StatusChange, AuditEntities.Lead, followUp.LeadId, nameof(LeadStatus.New), nameof(LeadStatus.Contacted),
                details: $"Updated by completing follow-up #{id}");

        return result.WithData(followUp);
    }

    public async Task<ServiceResult<FollowUp>> MarkMissedAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var followUp = await Db.FollowUps.WhereVisible(visible).FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (followUp is null) return ServiceResult<FollowUp>.Missing();
        if (followUp.Status != FollowUpStatus.Planned)
            return ServiceResult<FollowUp>.Failure(string.Empty, "Only planned follow-ups can be marked as missed.");

        followUp.Status = FollowUpStatus.Missed;
        var result = new ServiceResult<FollowUp>();
        if (!await TrySaveAsync(result, "The follow-up could not be updated.")) return result;

        await Audit.LogAsync(AuditActions.Missed, AuditEntities.FollowUp, id, nameof(FollowUpStatus.Planned), nameof(FollowUpStatus.Missed));
        return result.WithData(followUp);
    }

    public async Task<ServiceResult<bool>> DeleteAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var followUp = await Db.FollowUps.WhereVisible(visible).FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (followUp is null) return ServiceResult<bool>.Missing();

        var before = AuditSnapshot.ToJson(followUp);
        Db.FollowUps.Remove(followUp);
        var result = new ServiceResult<bool>();
        if (!await TrySaveAsync(result, "The follow-up could not be deleted.")) return result;

        await Audit.LogAsync(AuditActions.Delete, AuditEntities.FollowUp, id, before);
        return result.WithData(true);
    }

    public async Task<(int Overdue, int Today)> GetPendingCountsAsync()
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var now = DateTime.Now;
        var tomorrow = DateTime.Today.AddDays(1);
        var planned = Db.FollowUps.AsNoTracking().WhereVisible(visible).Where(f => f.Status == FollowUpStatus.Planned);
        var overdue = await planned.CountAsync(f => f.FollowUpDate < now);
        var today = await planned.CountAsync(f => f.FollowUpDate >= now && f.FollowUpDate < tomorrow);
        return (overdue, today);
    }

    public async Task<List<FollowUp>> GetUpcomingAsync(int take)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await WithRelations(Db.FollowUps.AsNoTracking()).WhereVisible(visible)
            .Where(f => f.Status == FollowUpStatus.Planned)
            .OrderBy(f => f.FollowUpDate)
            .Take(take)
            .ToListAsync();
    }

    private async Task ValidateBusinessRulesAsync(FollowUpRequestDto dto, ServiceResult<FollowUp> result, bool isNew, bool dateChanged)
    {
        // Follow-up date cannot be earlier than today for a new or planned follow-up.
        var planned = isNew || dto.Status == FollowUpStatus.Planned;
        if (planned && (isNew || dateChanged || dto.Status == FollowUpStatus.Planned)
            && dto.FollowUpDate.HasValue && dto.FollowUpDate.Value.Date < DateTime.Today)
            result.AddError(nameof(dto.FollowUpDate), ValidationRules.FollowUpDateMessage);

        if (dto.CustomerId is null && dto.LeadId is null && dto.OpportunityId is null)
            result.AddError(nameof(dto.CustomerId), "Link the follow-up to a customer, lead or opportunity.");

        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        if (dto.CustomerId.HasValue)
        {
            var customerId = dto.CustomerId.Value;
            if (!await Db.Customers.WhereVisible(visible).AnyAsync(c => c.CustomerId == customerId))
                result.AddError(nameof(dto.CustomerId), "Select a valid customer.");
        }
        if (dto.LeadId.HasValue)
        {
            var leadId = dto.LeadId.Value;
            if (!await Db.Leads.WhereVisible(visible).AnyAsync(l => l.LeadId == leadId))
                result.AddError(nameof(dto.LeadId), "Select a valid lead.");
        }
        if (dto.OpportunityId.HasValue)
        {
            var opportunityId = dto.OpportunityId.Value;
            if (!await Db.Opportunities.WhereVisible(visible).AnyAsync(o => o.OpportunityId == opportunityId))
                result.AddError(nameof(dto.OpportunityId), "Select a valid opportunity.");
        }
    }

    private static void Normalize(FollowUpRequestDto dto)
    {
        dto.Subject = dto.Subject?.Trim() ?? string.Empty;
        dto.Remarks = Clean(dto.Remarks);
    }
}
