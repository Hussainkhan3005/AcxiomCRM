using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface ICustomerService
{
    Task<PagedResult<Customer>> SearchAsync(CustomerFilter filter);
    Task<Customer?> GetAsync(int id);
    Task<CustomerDetailsViewModel?> GetDetailsAsync(int id);
    Task<ServiceResult<Customer>> CreateAsync(CustomerRequestDto dto);
    Task<ServiceResult<Customer>> UpdateAsync(int id, CustomerRequestDto dto);
    Task<ServiceResult<bool>> DeleteAsync(int id);
}

public class CustomerService : ServiceBase, ICustomerService
{
    public CustomerService(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger<CustomerService> logger)
        : base(db, currentUser, audit, logger) { }

    public async Task<PagedResult<Customer>> SearchAsync(CustomerFilter f)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        IQueryable<Customer> q = Db.Customers.AsNoTracking().Include(c => c.AssignedUser).WhereVisible(visible);

        if (!string.IsNullOrWhiteSpace(f.Name))
        {
            var p = f.Name.ToLikePattern();
            q = q.Where(c => EF.Functions.Like(c.CustomerName, p) || EF.Functions.Like(c.CustomerCode, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Email))
        {
            var p = f.Email.ToLikePattern();
            q = q.Where(c => EF.Functions.Like(c.Email, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Phone))
        {
            var p = f.Phone.ToLikePattern();
            q = q.Where(c => EF.Functions.Like(c.Phone, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Company))
        {
            var p = f.Company.ToLikePattern();
            q = q.Where(c => c.CompanyName != null && EF.Functions.Like(c.CompanyName, p));
        }
        if (f.Status.HasValue)
        {
            var status = f.Status.Value;
            q = q.Where(c => c.Status == status);
        }
        if (!string.IsNullOrWhiteSpace(f.AssignedTo))
        {
            var owner = f.AssignedTo;
            q = q.Where(c => c.AssignedTo == owner);
        }

        q = f.Sort switch
        {
            "name" => q.OrderBy(c => c.CustomerName),
            "name_desc" => q.OrderByDescending(c => c.CustomerName),
            "company" => q.OrderBy(c => c.CompanyName),
            "company_desc" => q.OrderByDescending(c => c.CompanyName),
            "status" => q.OrderBy(c => c.Status),
            "status_desc" => q.OrderByDescending(c => c.Status),
            "created" => q.OrderBy(c => c.CreatedDate),
            _ => q.OrderByDescending(c => c.CreatedDate)
        };

        return await q.ToPagedAsync(f.Page, f.PageSize);
    }

    public async Task<Customer?> GetAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await Db.Customers.AsNoTracking().Include(c => c.AssignedUser)
            .WhereVisible(visible)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
    }

    public async Task<CustomerDetailsViewModel?> GetDetailsAsync(int id)
    {
        var customer = await GetAsync(id);
        if (customer is null) return null;

        var key = id.ToString();
        return new CustomerDetailsViewModel
        {
            Customer = customer,
            Opportunities = await Db.Opportunities.AsNoTracking().Include(o => o.AssignedUser)
                .Where(o => o.CustomerId == id).OrderByDescending(o => o.CreatedDate).ToListAsync(),
            FollowUps = await Db.FollowUps.AsNoTracking().Include(f => f.AssignedUser)
                .Where(f => f.CustomerId == id).OrderByDescending(f => f.FollowUpDate).Take(20).ToListAsync(),
            Activities = await Db.Activities.AsNoTracking().Include(a => a.AssignedUser)
                .Where(a => a.CustomerId == id).OrderByDescending(a => a.ActivityDate).Take(20).ToListAsync(),
            SourceLeads = await Db.Leads.AsNoTracking().Where(l => l.ConvertedCustomerId == id).ToListAsync(),
            History = await Db.AuditLogs.AsNoTracking()
                .Where(a => a.EntityName == AuditEntities.Customer && a.RecordId == key)
                .OrderByDescending(a => a.CreatedDate).Take(20).ToListAsync()
        };
    }

    public async Task<ServiceResult<Customer>> CreateAsync(CustomerRequestDto dto)
    {
        Normalize(dto);
        var result = new ServiceResult<Customer>();
        ServerValidator.Validate(dto, result);
        await ValidateBusinessRulesAsync(dto, 0, result);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var nextNumber = (await Db.Customers.MaxAsync(c => (int?)c.CustomerId) ?? 0) + 1;
        var customer = new Customer
        {
            CustomerCode = $"CUS-{nextNumber:D5}",
            CustomerName = dto.CustomerName,
            Email = dto.Email,
            Phone = dto.Phone,
            CompanyName = dto.CompanyName,
            Address = dto.Address,
            City = dto.City,
            State = dto.State,
            Status = dto.Status!.Value,
            Notes = dto.Notes,
            AssignedTo = owner!,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        };

        Db.Customers.Add(customer);
        if (!await TrySaveAsync(result, "A customer with the same email or phone already exists.")) return result;

        await Audit.LogAsync(AuditActions.Create, AuditEntities.Customer, customer.CustomerId, newValue: customer);
        return result.WithData(customer);
    }

    public async Task<ServiceResult<Customer>> UpdateAsync(int id, CustomerRequestDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var customer = await Db.Customers.WhereVisible(visible).FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null) return ServiceResult<Customer>.Missing();

        Normalize(dto);
        var result = new ServiceResult<Customer>();
        ServerValidator.Validate(dto, result);
        await ValidateBusinessRulesAsync(dto, id, result);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo, customer.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var before = AuditSnapshot.ToJson(customer);
        var oldStatus = customer.Status;

        customer.CustomerName = dto.CustomerName;
        customer.Email = dto.Email;
        customer.Phone = dto.Phone;
        customer.CompanyName = dto.CompanyName;
        customer.Address = dto.Address;
        customer.City = dto.City;
        customer.State = dto.State;
        customer.Status = dto.Status!.Value;
        customer.Notes = dto.Notes;
        customer.AssignedTo = owner!;
        customer.ModifiedDate = DateTime.Now;

        if (!await TrySaveAsync(result, "A customer with the same email or phone already exists.")) return result;

        await Audit.LogAsync(AuditActions.Update, AuditEntities.Customer, id, before, customer);
        if (oldStatus != customer.Status)
            await Audit.LogAsync(AuditActions.StatusChange, AuditEntities.Customer, id, oldStatus.ToString(), customer.Status.ToString());

        return result.WithData(customer);
    }

    public async Task<ServiceResult<bool>> DeleteAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var customer = await Db.Customers.WhereVisible(visible).FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null) return ServiceResult<bool>.Missing();

        var opportunityCount = await Db.Opportunities.CountAsync(o => o.CustomerId == id);
        if (opportunityCount > 0)
            return ServiceResult<bool>.Failure(string.Empty,
                $"This customer has {opportunityCount} opportunit{(opportunityCount == 1 ? "y" : "ies")}. Delete them first, or set the customer's status to Inactive.",
                conflict: true);

        var before = AuditSnapshot.ToJson(customer);

        // Remove dependent activity records; keep converted leads but unlink them.
        Db.FollowUps.RemoveRange(await Db.FollowUps.Where(f => f.CustomerId == id).ToListAsync());
        Db.Activities.RemoveRange(await Db.Activities.Where(a => a.CustomerId == id).ToListAsync());
        foreach (var lead in await Db.Leads.Where(l => l.ConvertedCustomerId == id).ToListAsync())
            lead.ConvertedCustomerId = null;

        Db.Customers.Remove(customer);

        var result = new ServiceResult<bool>();
        if (!await TrySaveAsync(result, "The customer could not be deleted because other records depend on it.")) return result;

        await Audit.LogAsync(AuditActions.Delete, AuditEntities.Customer, id, before);
        return result.WithData(true);
    }

    private async Task ValidateBusinessRulesAsync(CustomerRequestDto dto, int excludeId, ServiceResult<Customer> result)
    {
        if (!string.IsNullOrEmpty(dto.Email) &&
            await Db.Customers.AnyAsync(c => c.Email == dto.Email && c.CustomerId != excludeId))
            result.AddError(nameof(dto.Email), "A customer with this email already exists.", conflict: true);

        if (!string.IsNullOrEmpty(dto.Phone) &&
            await Db.Customers.AnyAsync(c => c.Phone == dto.Phone && c.CustomerId != excludeId))
            result.AddError(nameof(dto.Phone), "A customer with this phone number already exists.", conflict: true);

        if (!string.IsNullOrEmpty(dto.CustomerName))
        {
            var name = dto.CustomerName.ToLower();
            var company = (dto.CompanyName ?? string.Empty).ToLower();
            if (await Db.Customers.AnyAsync(c => c.CustomerId != excludeId
                                                 && c.CustomerName.ToLower() == name
                                                 && (c.CompanyName ?? string.Empty).ToLower() == company))
                result.AddError(string.Empty, "A customer with the same name and company already exists.", conflict: true);
        }
    }

    private static void Normalize(CustomerRequestDto dto)
    {
        dto.CustomerName = dto.CustomerName?.Trim() ?? string.Empty;
        dto.Email = dto.Email?.Trim().ToLowerInvariant() ?? string.Empty;
        dto.Phone = dto.Phone?.Trim() ?? string.Empty;
        dto.CompanyName = Clean(dto.CompanyName);
        dto.Address = Clean(dto.Address);
        dto.City = Clean(dto.City);
        dto.State = Clean(dto.State);
        dto.Notes = Clean(dto.Notes);
    }
}
