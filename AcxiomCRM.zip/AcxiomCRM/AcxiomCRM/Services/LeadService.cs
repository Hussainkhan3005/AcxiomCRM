using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface ILeadService
{
    Task<PagedResult<Lead>> SearchAsync(LeadFilter filter);
    Task<Lead?> GetAsync(int id);
    Task<LeadDetailsViewModel?> GetDetailsAsync(int id);
    Task<ServiceResult<Lead>> CreateAsync(LeadRequestDto dto);
    Task<ServiceResult<Lead>> UpdateAsync(int id, LeadRequestDto dto);
    Task<ServiceResult<Lead>> ConvertAsync(int id, LeadConvertDto dto);
    Task<ServiceResult<bool>> DeleteAsync(int id);
}

public class LeadService : ServiceBase, ILeadService
{
    private readonly ICustomerService _customers;
    private readonly IOpportunityService _opportunities;

    public LeadService(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger<LeadService> logger,
        ICustomerService customers, IOpportunityService opportunities)
        : base(db, currentUser, audit, logger)
    {
        _customers = customers;
        _opportunities = opportunities;
    }

    public async Task<PagedResult<Lead>> SearchAsync(LeadFilter f)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        IQueryable<Lead> q = Db.Leads.AsNoTracking().Include(l => l.AssignedUser).WhereVisible(visible);

        if (!string.IsNullOrWhiteSpace(f.Name))
        {
            var p = f.Name.ToLikePattern();
            q = q.Where(l => EF.Functions.Like(l.LeadName, p) || EF.Functions.Like(l.LeadCode, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Company))
        {
            var p = f.Company.ToLikePattern();
            q = q.Where(l => l.CompanyName != null && EF.Functions.Like(l.CompanyName, p));
        }
        if (f.Status.HasValue)
        {
            var status = f.Status.Value;
            q = q.Where(l => l.Status == status);
        }
        if (f.Source.HasValue)
        {
            var source = f.Source.Value;
            q = q.Where(l => l.Source == source);
        }
        if (!string.IsNullOrWhiteSpace(f.AssignedTo))
        {
            var owner = f.AssignedTo;
            q = q.Where(l => l.AssignedTo == owner);
        }

        q = f.Sort switch
        {
            "name" => q.OrderBy(l => l.LeadName),
            "name_desc" => q.OrderByDescending(l => l.LeadName),
            "company" => q.OrderBy(l => l.CompanyName),
            "company_desc" => q.OrderByDescending(l => l.CompanyName),
            "status" => q.OrderBy(l => l.Status),
            "status_desc" => q.OrderByDescending(l => l.Status),
            "value" => q.OrderBy(l => l.ExpectedValue),
            "value_desc" => q.OrderByDescending(l => l.ExpectedValue),
            "created" => q.OrderBy(l => l.CreatedDate),
            _ => q.OrderByDescending(l => l.CreatedDate)
        };

        return await q.ToPagedAsync(f.Page, f.PageSize);
    }

    public async Task<Lead?> GetAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await Db.Leads.AsNoTracking()
            .Include(l => l.AssignedUser).Include(l => l.ConvertedCustomer)
            .WhereVisible(visible)
            .FirstOrDefaultAsync(l => l.LeadId == id);
    }

    public async Task<LeadDetailsViewModel?> GetDetailsAsync(int id)
    {
        var lead = await GetAsync(id);
        if (lead is null) return null;
        var key = id.ToString();
        return new LeadDetailsViewModel
        {
            Lead = lead,
            FollowUps = await Db.FollowUps.AsNoTracking().Include(f => f.AssignedUser)
                .Where(f => f.LeadId == id).OrderByDescending(f => f.FollowUpDate).ToListAsync(),
            Activities = await Db.Activities.AsNoTracking().Include(a => a.AssignedUser)
                .Where(a => a.LeadId == id).OrderByDescending(a => a.ActivityDate).ToListAsync(),
            Opportunities = await Db.Opportunities.AsNoTracking()
                .Where(o => o.LeadId == id).ToListAsync(),
            History = await Db.AuditLogs.AsNoTracking()
                .Where(a => a.EntityName == AuditEntities.Lead && a.RecordId == key)
                .OrderByDescending(a => a.CreatedDate).Take(20).ToListAsync()
        };
    }

    public async Task<ServiceResult<Lead>> CreateAsync(LeadRequestDto dto)
    {
        Normalize(dto);
        var result = new ServiceResult<Lead>();
        ServerValidator.Validate(dto, result);
        ValidateEnums(dto, result);

        if (dto.Status.HasValue && !LeadWorkflow.CreatableStatuses.Contains(dto.Status.Value))
            result.AddError(nameof(dto.Status), "A new lead can only be New, Contacted or Qualified.");

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var nextNumber = (await Db.Leads.MaxAsync(l => (int?)l.LeadId) ?? 0) + 1;
        var lead = new Lead
        {
            LeadCode = $"LEAD-{nextNumber:D5}",
            LeadName = dto.LeadName,
            Email = dto.Email,
            Phone = dto.Phone,
            CompanyName = dto.CompanyName,
            Source = dto.Source!.Value,
            Status = dto.Status!.Value,
            Priority = dto.Priority,
            ExpectedValue = dto.ExpectedValue,
            Notes = dto.Notes,
            AssignedTo = owner!,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        };

        Db.Leads.Add(lead);
        if (!await TrySaveAsync(result, "The lead could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Create, AuditEntities.Lead, lead.LeadId, newValue: lead);
        return result.WithData(lead);
    }

    public async Task<ServiceResult<Lead>> UpdateAsync(int id, LeadRequestDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var lead = await Db.Leads.WhereVisible(visible).FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return ServiceResult<Lead>.Missing();

        Normalize(dto);
        var result = new ServiceResult<Lead>();
        ServerValidator.Validate(dto, result);
        ValidateEnums(dto, result);

        if (dto.Status.HasValue && dto.Status.Value != lead.Status)
        {
            if (dto.Status.Value == LeadStatus.Converted)
                result.AddError(nameof(dto.Status), "Use the Convert action to convert a qualified lead.");
            else if (!LeadWorkflow.CanTransition(lead.Status, dto.Status.Value))
                result.AddError(nameof(dto.Status), $"Lead status cannot change from {lead.Status} to {dto.Status.Value}.");
        }

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo, lead.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var before = AuditSnapshot.ToJson(lead);
        var oldStatus = lead.Status;

        lead.LeadName = dto.LeadName;
        lead.Email = dto.Email;
        lead.Phone = dto.Phone;
        lead.CompanyName = dto.CompanyName;
        lead.Source = dto.Source!.Value;
        lead.Status = dto.Status!.Value;
        lead.Priority = dto.Priority;
        lead.ExpectedValue = dto.ExpectedValue;
        lead.Notes = dto.Notes;
        lead.AssignedTo = owner!;
        lead.ModifiedDate = DateTime.Now;

        if (!await TrySaveAsync(result, "The lead could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Update, AuditEntities.Lead, id, before, lead);
        if (oldStatus != lead.Status)
            await Audit.LogAsync(AuditActions.StatusChange, AuditEntities.Lead, id, oldStatus.ToString(), lead.Status.ToString());

        return result.WithData(lead);
    }

    /// <summary>
    /// Lead-to-customer workflow: Qualified lead -> customer (new or existing) -> optional opportunity.
    /// Runs in one database transaction, so a validation failure leaves nothing half-created.
    /// </summary>
    public async Task<ServiceResult<Lead>> ConvertAsync(int id, LeadConvertDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var lead = await Db.Leads.WhereVisible(visible).FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return ServiceResult<Lead>.Missing();

        var result = new ServiceResult<Lead>();
        if (lead.Status != LeadStatus.Qualified)
            return result.AddError(string.Empty, "Only Qualified leads can be converted.");

        if (!ServerValidator.Validate(dto, result)) return result;

        await using var transaction = await Db.Database.BeginTransactionAsync();

        int customerId;
        if (dto.ExistingCustomerId.HasValue)
        {
            var existing = await _customers.GetAsync(dto.ExistingCustomerId.Value);
            if (existing is null) return result.AddError(nameof(dto.ExistingCustomerId), "Select a valid customer.");
            customerId = existing.CustomerId;
        }
        else
        {
            var created = await _customers.CreateAsync(new CustomerRequestDto
            {
                CustomerName = string.IsNullOrWhiteSpace(dto.CustomerName) ? lead.LeadName : dto.CustomerName,
                Email = dto.Email ?? lead.Email ?? string.Empty,
                Phone = dto.Phone ?? lead.Phone ?? string.Empty,
                CompanyName = dto.CompanyName ?? lead.CompanyName,
                Status = CustomerStatus.Active,
                Notes = $"Converted from lead {lead.LeadCode}.",
                AssignedTo = lead.AssignedTo
            });
            if (!created.Succeeded)
            {
                created.CopyErrorsTo(result);
                return result; // transaction is rolled back on dispose
            }
            customerId = created.Data!.CustomerId;
        }

        int? opportunityId = null;
        if (dto.CreateOpportunity)
        {
            var opportunity = await _opportunities.CreateAsync(new OpportunityRequestDto
            {
                OpportunityName = string.IsNullOrWhiteSpace(dto.OpportunityName)
                    ? $"{lead.CompanyName ?? lead.LeadName} - new deal"
                    : dto.OpportunityName,
                CustomerId = customerId,
                LeadId = lead.LeadId,
                Amount = dto.Amount ?? lead.ExpectedValue,
                Stage = OpportunityStage.Qualification,
                Probability = dto.Probability ?? OpportunityWorkflow.DefaultProbability(OpportunityStage.Qualification),
                ExpectedCloseDate = dto.ExpectedCloseDate ?? DateTime.Today.AddDays(30),
                Source = lead.Source.DisplayName(),
                AssignedTo = lead.AssignedTo
            });
            if (!opportunity.Succeeded)
            {
                opportunity.CopyErrorsTo(result);
                return result;
            }
            opportunityId = opportunity.Data!.OpportunityId;
        }

        var before = AuditSnapshot.ToJson(lead);
        lead.Status = LeadStatus.Converted;
        lead.ConvertedCustomerId = customerId;
        lead.ConvertedOpportunityId = opportunityId;
        lead.ConvertedDate = DateTime.Now;
        lead.ModifiedDate = DateTime.Now;

        if (!await TrySaveAsync(result, "The lead could not be converted.")) return result;

        var details = $"Converted to customer #{customerId}" + (opportunityId.HasValue ? $" and opportunity #{opportunityId}" : string.Empty);
        await Audit.LogAsync(AuditActions.Convert, AuditEntities.Lead, lead.LeadId, before, lead, details: details);
        await transaction.CommitAsync();

        return result.WithData(lead);
    }

    public async Task<ServiceResult<bool>> DeleteAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var lead = await Db.Leads.WhereVisible(visible).FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return ServiceResult<bool>.Missing();

        if (lead.Status == LeadStatus.Converted)
            return ServiceResult<bool>.Failure(string.Empty, "Converted leads are kept for conversion reporting and cannot be deleted.", conflict: true);

        var before = AuditSnapshot.ToJson(lead);

        foreach (var followUp in await Db.FollowUps.Where(f => f.LeadId == id).ToListAsync())
        {
            if (followUp.CustomerId is null && followUp.OpportunityId is null) Db.FollowUps.Remove(followUp);
            else followUp.LeadId = null;
        }
        foreach (var activity in await Db.Activities.Where(a => a.LeadId == id).ToListAsync())
        {
            if (activity.CustomerId is null) Db.Activities.Remove(activity);
            else activity.LeadId = null;
        }
        foreach (var opportunity in await Db.Opportunities.Where(o => o.LeadId == id).ToListAsync())
            opportunity.LeadId = null;

        Db.Leads.Remove(lead);

        var result = new ServiceResult<bool>();
        if (!await TrySaveAsync(result, "The lead could not be deleted.")) return result;

        await Audit.LogAsync(AuditActions.Delete, AuditEntities.Lead, id, before);
        return result.WithData(true);
    }

    /// <summary>Only configured enum values are accepted, even if a client sends something else.</summary>
    private static void ValidateEnums(LeadRequestDto dto, ServiceResult<Lead> result)
    {
        if (dto.Status.HasValue && !Enum.IsDefined(dto.Status.Value))
            result.AddError(nameof(dto.Status), "Select a valid lead status.");
        if (dto.Source.HasValue && !Enum.IsDefined(dto.Source.Value))
            result.AddError(nameof(dto.Source), "Select a valid lead source.");
        if (!Enum.IsDefined(dto.Priority))
            result.AddError(nameof(dto.Priority), "Select a valid priority.");
    }

    private static void Normalize(LeadRequestDto dto)
    {
        dto.LeadName = dto.LeadName?.Trim() ?? string.Empty;
        dto.Email = Clean(dto.Email)?.ToLowerInvariant();
        dto.Phone = Clean(dto.Phone);
        dto.CompanyName = Clean(dto.CompanyName);
        dto.Notes = Clean(dto.Notes);
    }
}
