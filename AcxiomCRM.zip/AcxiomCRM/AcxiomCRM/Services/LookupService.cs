using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

/// <summary>Drop-down data, always limited to what the current user is allowed to see.</summary>
public interface ILookupService
{
    Task<List<SelectListItem>> AssignableUsersAsync();
    Task<List<SelectListItem>> CustomersAsync();
    Task<List<SelectListItem>> LeadsAsync(bool openOnly = false);
    Task<List<SelectListItem>> OpportunitiesAsync(bool openOnly = false);
    Task<List<SelectListItem>> ManagersAsync();
}

public class LookupService : ILookupService
{
    private readonly ApplicationDbContext _db;
    private readonly ICurrentUserService _user;

    public LookupService(ApplicationDbContext db, ICurrentUserService user)
    {
        _db = db;
        _user = user;
    }

    public async Task<List<SelectListItem>> AssignableUsersAsync()
    {
        var visible = await _user.GetVisibleUserIdsAsync();
        var query = _db.Users.AsNoTracking().Where(u => u.IsActive);
        if (visible is not null) query = query.Where(u => visible.Contains(u.Id));
        return await query.OrderBy(u => u.FullName)
            .Select(u => new SelectListItem(u.FullName, u.Id))
            .ToListAsync();
    }

    public async Task<List<SelectListItem>> CustomersAsync()
    {
        var visible = await _user.GetVisibleUserIdsAsync();
        return await _db.Customers.AsNoTracking().WhereVisible(visible)
            .OrderBy(c => c.CustomerName)
            .Select(c => new SelectListItem(c.CustomerName + (c.CompanyName != null ? " (" + c.CompanyName + ")" : ""), c.CustomerId.ToString()))
            .ToListAsync();
    }

    public async Task<List<SelectListItem>> LeadsAsync(bool openOnly = false)
    {
        var visible = await _user.GetVisibleUserIdsAsync();
        var query = _db.Leads.AsNoTracking().WhereVisible(visible);
        if (openOnly)
            query = query.Where(l => l.Status == LeadStatus.New || l.Status == LeadStatus.Contacted || l.Status == LeadStatus.Qualified);
        return await query.OrderBy(l => l.LeadName)
            .Select(l => new SelectListItem(l.LeadName + " - " + l.LeadCode, l.LeadId.ToString()))
            .ToListAsync();
    }

    public async Task<List<SelectListItem>> OpportunitiesAsync(bool openOnly = false)
    {
        var visible = await _user.GetVisibleUserIdsAsync();
        var query = _db.Opportunities.AsNoTracking().WhereVisible(visible);
        if (openOnly) query = query.Where(o => o.Status == OpportunityStatus.Open);
        return await query.OrderBy(o => o.OpportunityName)
            .Select(o => new SelectListItem(o.OpportunityName, o.OpportunityId.ToString()))
            .ToListAsync();
    }

    public async Task<List<SelectListItem>> ManagersAsync()
    {
        var managers = from u in _db.Users
                       join ur in _db.UserRoles on u.Id equals ur.UserId
                       join r in _db.Roles on ur.RoleId equals r.Id
                       where r.Name == AppRoles.Manager && u.IsActive
                       orderby u.FullName
                       select new SelectListItem(u.FullName, u.Id);
        return await managers.AsNoTracking().ToListAsync();
    }
}
