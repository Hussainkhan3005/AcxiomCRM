using System.Security.Claims;
using AcxiomCRM.Common;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;

namespace AcxiomCRM.Services;

public enum LoginStatus
{
    Success,
    InvalidCredentials,
    LockedOut,
    Inactive
}

public record LoginOutcome(LoginStatus Status, ApplicationUser? User, string? Role);

public interface IAccountService
{
    Task<LoginOutcome> SignInAsync(string userNameOrEmail, string password, bool rememberMe);
    Task<(IdentityResult Result, ApplicationUser? User)> RegisterAsync(string fullName, string email, string password);
    Task SignOutAsync(ClaimsPrincipal principal);
    Task<IdentityResult> ChangePasswordAsync(ClaimsPrincipal principal, string currentPassword, string newPassword);
}

/// <summary>
/// Authentication built on ASP.NET Core Identity: hashed passwords, password policy and lockout
/// are all handled by the framework. Every outcome is written to the audit log (never the password).
/// </summary>
public class AccountService : IAccountService
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly IAuditService _audit;

    public AccountService(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn, IAuditService audit)
    {
        _users = users;
        _signIn = signIn;
        _audit = audit;
    }

    public async Task<LoginOutcome> SignInAsync(string userNameOrEmail, string password, bool rememberMe)
    {
        var login = userNameOrEmail.Trim();
        var user = login.Contains('@') ? await _users.FindByEmailAsync(login) : await _users.FindByNameAsync(login);

        if (user is null)
        {
            await _audit.LogAsync(AuditActions.FailedLogin, AuditEntities.Account, result: AuditResults.Failure,
                details: "Unknown username or email", userName: login.Length > 256 ? login[..256] : login);
            return new LoginOutcome(LoginStatus.InvalidCredentials, null, null);
        }

        var wasLockedOut = await _users.IsLockedOutAsync(user);
        var check = await _signIn.CheckPasswordSignInAsync(user, password, lockoutOnFailure: true);

        if (check.IsLockedOut)
        {
            await _audit.LogAsync(wasLockedOut ? AuditActions.LockedOutAttempt : AuditActions.Lockout, AuditEntities.Account, user.Id,
                result: AuditResults.Failure,
                details: wasLockedOut ? "Sign-in attempted while account is locked" : "Account locked after repeated failed sign-ins",
                userId: user.Id, userName: user.UserName);
            return new LoginOutcome(LoginStatus.LockedOut, user, null);
        }

        if (!check.Succeeded)
        {
            await _audit.LogAsync(AuditActions.FailedLogin, AuditEntities.Account, user.Id, result: AuditResults.Failure,
                details: $"Invalid password (failed attempts: {await _users.GetAccessFailedCountAsync(user)})",
                userId: user.Id, userName: user.UserName);
            return new LoginOutcome(LoginStatus.InvalidCredentials, user, null);
        }

        if (!user.IsActive)
        {
            await _audit.LogAsync(AuditActions.FailedLogin, AuditEntities.Account, user.Id, result: AuditResults.Failure,
                details: "Account is deactivated", userId: user.Id, userName: user.UserName);
            return new LoginOutcome(LoginStatus.Inactive, user, null);
        }

        await _signIn.SignInAsync(user, rememberMe);
        var role = (await _users.GetRolesAsync(user)).FirstOrDefault();
        await _audit.LogAsync(AuditActions.Login, AuditEntities.Account, user.Id, userId: user.Id, userName: user.UserName,
            details: $"Signed in as {AppRoles.DisplayName(role)}");
        return new LoginOutcome(LoginStatus.Success, user, role);
    }

    public async Task<(IdentityResult Result, ApplicationUser? User)> RegisterAsync(string fullName, string email, string password)
    {
        var user = new ApplicationUser
        {
            UserName = email.Trim().ToLowerInvariant(),
            Email = email.Trim().ToLowerInvariant(),
            FullName = fullName.Trim(),
            IsActive = true,
            CreatedDate = DateTime.Now
        };

        var result = await _users.CreateAsync(user, password); // password policy + hashing by Identity
        if (!result.Succeeded) return (result, null);

        // Self-registered users get the least-privileged role.
        await _users.AddToRoleAsync(user, AppRoles.SalesExecutive);
        await _audit.LogAsync(AuditActions.Register, AuditEntities.User, user.Id,
            newValue: new { user.Id, user.Email, user.FullName, Role = AppRoles.SalesExecutive },
            userId: user.Id, userName: user.UserName);

        await _signIn.SignInAsync(user, isPersistent: false);
        await _audit.LogAsync(AuditActions.Login, AuditEntities.Account, user.Id, userId: user.Id, userName: user.UserName,
            details: "Signed in after registration");
        return (result, user);
    }

    public async Task SignOutAsync(ClaimsPrincipal principal)
    {
        var userId = principal.FindFirstValue(ClaimTypes.NameIdentifier);
        await _audit.LogAsync(AuditActions.Logout, AuditEntities.Account, userId, userId: userId, userName: principal.Identity?.Name);
        await _signIn.SignOutAsync();
    }

    public async Task<IdentityResult> ChangePasswordAsync(ClaimsPrincipal principal, string currentPassword, string newPassword)
    {
        var user = await _users.GetUserAsync(principal);
        if (user is null) return IdentityResult.Failed(new IdentityError { Description = "User not found." });

        var result = await _users.ChangePasswordAsync(user, currentPassword, newPassword);
        await _audit.LogAsync(AuditActions.PasswordChange, AuditEntities.Account, user.Id,
            result: result.Succeeded ? AuditResults.Success : AuditResults.Failure,
            details: result.Succeeded ? "Password changed by user" : "Password change rejected",
            userId: user.Id, userName: user.UserName);

        if (result.Succeeded) await _signIn.RefreshSignInAsync(user);
        return result;
    }
}

/// <summary>Adds the user's full name to the auth cookie so the layout can greet them.</summary>
public class AppClaimsPrincipalFactory : UserClaimsPrincipalFactory<ApplicationUser, IdentityRole>
{
    public const string FullNameClaim = "full_name";

    public AppClaimsPrincipalFactory(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager,
        Microsoft.Extensions.Options.IOptions<IdentityOptions> options)
        : base(userManager, roleManager, options) { }

    protected override async Task<ClaimsIdentity> GenerateClaimsAsync(ApplicationUser user)
    {
        var identity = await base.GenerateClaimsAsync(user);
        identity.AddClaim(new Claim(FullNameClaim, user.FullName));
        return identity;
    }
}
