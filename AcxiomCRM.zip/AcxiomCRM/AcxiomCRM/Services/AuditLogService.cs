using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IAuditLogService
{
    Task<PagedResult<AuditLog>> SearchAsync(AuditFilter filter);
    Task<AuditLog?> GetAsync(long id);
    bool IsLimitedView { get; }
}

/// <summary>
/// Read-only access to the audit trail. Admins see everything; Managers get a limited view
/// (their team's business events only, no security events).
/// </summary>
public class AuditLogService : IAuditLogService
{
    private readonly ApplicationDbContext _db;
    private readonly ICurrentUserService _user;

    public AuditLogService(ApplicationDbContext db, ICurrentUserService user)
    {
        _db = db;
        _user = user;
    }

    public bool IsLimitedView => !_user.IsAdmin;

    private async Task<IQueryable<AuditLog>> ScopedAsync()
    {
        var q = _db.AuditLogs.AsNoTracking();
        if (_user.IsAdmin) return q;

        var visible = await _user.GetVisibleUserIdsAsync() ?? new List<string>();
        var security = AuditEntities.Security;
        return q.Where(a => a.UserId != null && visible.Contains(a.UserId) && !security.Contains(a.EntityName));
    }

    public async Task<PagedResult<AuditLog>> SearchAsync(AuditFilter f)
    {
        var q = await ScopedAsync();

        if (!string.IsNullOrWhiteSpace(f.User))
        {
            var p = f.User.ToLikePattern();
            q = q.Where(a => a.UserName != null && EF.Functions.Like(a.UserName, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Entity))
        {
            var entity = f.Entity;
            q = q.Where(a => a.EntityName == entity);
        }
        if (!string.IsNullOrWhiteSpace(f.Action))
        {
            var action = f.Action;
            q = q.Where(a => a.Action == action);
        }
        if (!string.IsNullOrWhiteSpace(f.Result))
        {
            var r = f.Result;
            q = q.Where(a => a.Result == r);
        }
        if (f.From.HasValue)
        {
            var from = f.From.Value.Date;
            q = q.Where(a => a.CreatedDate >= from);
        }
        if (f.To.HasValue)
        {
            var to = f.To.Value.Date.AddDays(1);
            q = q.Where(a => a.CreatedDate < to);
        }

        q = f.Sort == "date" ? q.OrderBy(a => a.CreatedDate) : q.OrderByDescending(a => a.CreatedDate);
        return await q.ToPagedAsync(f.Page, f.PageSize < 10 ? 20 : f.PageSize);
    }

    public async Task<AuditLog?> GetAsync(long id)
    {
        var q = await ScopedAsync();
        return await q.FirstOrDefaultAsync(a => a.AuditLogId == id);
    }
}
