using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IActivityService
{
    Task<PagedResult<Activity>> SearchAsync(ActivityFilter filter);
    Task<Activity?> GetAsync(int id);
    Task<ServiceResult<Activity>> CreateAsync(ActivityRequestDto dto);
    Task<ServiceResult<Activity>> UpdateAsync(int id, ActivityRequestDto dto);
    Task<ServiceResult<bool>> DeleteAsync(int id);
    Task<List<Activity>> GetRecentAsync(int take);
}

public class ActivityService : ServiceBase, IActivityService
{
    public ActivityService(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger<ActivityService> logger)
        : base(db, currentUser, audit, logger) { }

    public async Task<PagedResult<Activity>> SearchAsync(ActivityFilter f)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        IQueryable<Activity> q = Db.Activities.AsNoTracking()
            .Include(a => a.Customer).Include(a => a.Lead).Include(a => a.AssignedUser)
            .WhereVisible(visible);

        if (f.Type.HasValue)
        {
            var type = f.Type.Value;
            q = q.Where(a => a.ActivityType == type);
        }
        if (f.Status.HasValue)
        {
            var status = f.Status.Value;
            q = q.Where(a => a.Status == status);
        }
        if (f.From.HasValue)
        {
            var from = f.From.Value.Date;
            q = q.Where(a => a.ActivityDate >= from);
        }
        if (f.To.HasValue)
        {
            var to = f.To.Value.Date.AddDays(1);
            q = q.Where(a => a.ActivityDate < to);
        }
        if (!string.IsNullOrWhiteSpace(f.AssignedTo))
        {
            var owner = f.AssignedTo;
            q = q.Where(a => a.AssignedTo == owner);
        }
        if (!string.IsNullOrWhiteSpace(f.Subject))
        {
            var p = f.Subject.ToLikePattern();
            q = q.Where(a => EF.Functions.Like(a.Subject, p));
        }

        q = f.Sort switch
        {
            "date" => q.OrderBy(a => a.ActivityDate),
            "type" => q.OrderBy(a => a.ActivityType),
            "type_desc" => q.OrderByDescending(a => a.ActivityType),
            "subject" => q.OrderBy(a => a.Subject),
            "subject_desc" => q.OrderByDescending(a => a.Subject),
            _ => q.OrderByDescending(a => a.ActivityDate)
        };

        return await q.ToPagedAsync(f.Page, f.PageSize);
    }

    public async Task<Activity?> GetAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await Db.Activities.AsNoTracking()
            .Include(a => a.Customer).Include(a => a.Lead).Include(a => a.AssignedUser)
            .WhereVisible(visible)
            .FirstOrDefaultAsync(a => a.ActivityId == id);
    }

    public async Task<ServiceResult<Activity>> CreateAsync(ActivityRequestDto dto)
    {
        Normalize(dto);
        var result = new ServiceResult<Activity>();
        ServerValidator.Validate(dto, result);
        await ValidateReferencesAsync(dto, result);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var activity = new Activity
        {
            ActivityType = dto.ActivityType!.Value,
            Subject = dto.Subject,
            Description = dto.Description,
            ActivityDate = dto.ActivityDate!.Value,
            CustomerId = dto.CustomerId,
            LeadId = dto.LeadId,
            Status = dto.Status,
            AssignedTo = owner!,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        };

        Db.Activities.Add(activity);
        if (!await TrySaveAsync(result, "The activity could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Create, AuditEntities.Activity, activity.ActivityId, newValue: activity);
        return result.WithData(activity);
    }

    public async Task<ServiceResult<Activity>> UpdateAsync(int id, ActivityRequestDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var activity = await Db.Activities.WhereVisible(visible).FirstOrDefaultAsync(a => a.ActivityId == id);
        if (activity is null) return ServiceResult<Activity>.Missing();

        Normalize(dto);
        var result = new ServiceResult<Activity>();
        ServerValidator.Validate(dto, result);
        await ValidateReferencesAsync(dto, result);

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo, activity.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var before = AuditSnapshot.ToJson(activity);
        activity.ActivityType = dto.ActivityType!.Value;
        activity.Subject = dto.Subject;
        activity.Description = dto.Description;
        activity.ActivityDate = dto.ActivityDate!.Value;
        activity.CustomerId = dto.CustomerId;
        activity.LeadId = dto.LeadId;
        activity.Status = dto.Status;
        activity.AssignedTo = owner!;

        if (!await TrySaveAsync(result, "The activity could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Update, AuditEntities.Activity, id, before, activity);
        return result.WithData(activity);
    }

    public async Task<ServiceResult<bool>> DeleteAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var activity = await Db.Activities.WhereVisible(visible).FirstOrDefaultAsync(a => a.ActivityId == id);
        if (activity is null) return ServiceResult<bool>.Missing();

        var before = AuditSnapshot.ToJson(activity);
        Db.Activities.Remove(activity);
        var result = new ServiceResult<bool>();
        if (!await TrySaveAsync(result, "The activity could not be deleted.")) return result;

        await Audit.LogAsync(AuditActions.Delete, AuditEntities.Activity, id, before);
        return result.WithData(true);
    }

    public async Task<List<Activity>> GetRecentAsync(int take)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await Db.Activities.AsNoTracking()
            .Include(a => a.Customer).Include(a => a.Lead).Include(a => a.AssignedUser)
            .WhereVisible(visible)
            .OrderByDescending(a => a.ActivityDate)
            .Take(take)
            .ToListAsync();
    }

    private async Task ValidateReferencesAsync(ActivityRequestDto dto, ServiceResult<Activity> result)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        if (dto.CustomerId.HasValue)
        {
            var customerId = dto.CustomerId.Value;
            if (!await Db.Customers.WhereVisible(visible).AnyAsync(c => c.CustomerId == customerId))
                result.AddError(nameof(dto.CustomerId), "Select a valid customer.");
        }
        if (dto.LeadId.HasValue)
        {
            var leadId = dto.LeadId.Value;
            if (!await Db.Leads.WhereVisible(visible).AnyAsync(l => l.LeadId == leadId))
                result.AddError(nameof(dto.LeadId), "Select a valid lead.");
        }
    }

    private static void Normalize(ActivityRequestDto dto)
    {
        dto.Subject = dto.Subject?.Trim() ?? string.Empty;
        dto.Description = Clean(dto.Description);
    }
}
