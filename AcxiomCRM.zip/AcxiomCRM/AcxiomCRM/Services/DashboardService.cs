using System.Globalization;
using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IDashboardService
{
    Task<DashboardViewModel> GetAsync(string? range, DateTime? from, DateTime? to);
}

/// <summary>Builds KPI cards and Chart.js data from records the current user is authorized to see.</summary>
public class DashboardService : IDashboardService
{
    private readonly ApplicationDbContext _db;
    private readonly ICurrentUserService _user;
    private readonly IFollowUpService _followUps;
    private readonly IActivityService _activities;

    public DashboardService(ApplicationDbContext db, ICurrentUserService user, IFollowUpService followUps, IActivityService activities)
    {
        _db = db;
        _user = user;
        _followUps = followUps;
        _activities = activities;
    }

    public async Task<DashboardViewModel> GetAsync(string? range, DateTime? from, DateTime? to)
    {
        var (start, end, label, key) = ResolveRange(range, from, to);
        var visible = await _user.GetVisibleUserIdsAsync();

        var customers = _db.Customers.AsNoTracking().WhereVisible(visible);
        var leads = _db.Leads.AsNoTracking().WhereVisible(visible);
        var opportunities = _db.Opportunities.AsNoTracking().WhereVisible(visible);

        if (start.HasValue)
        {
            var s = start.Value;
            customers = customers.Where(c => c.CreatedDate >= s);
            leads = leads.Where(l => l.CreatedDate >= s);
            opportunities = opportunities.Where(o => o.CreatedDate >= s);
        }
        if (end.HasValue)
        {
            var e = end.Value;
            customers = customers.Where(c => c.CreatedDate < e);
            leads = leads.Where(l => l.CreatedDate < e);
            opportunities = opportunities.Where(o => o.CreatedDate < e);
        }

        var leadStatuses = await leads.Select(l => l.Status).ToListAsync();
        var opportunityRows = await opportunities
            .Select(o => new { o.Stage, o.Status, o.Amount, o.Probability })
            .ToListAsync();

        var open = opportunityRows.Where(o => o.Status == OpportunityStatus.Open).ToList();
        var (overdue, dueToday) = await _followUps.GetPendingCountsAsync();
        var pendingFollowUps = await _db.FollowUps.AsNoTracking().WhereVisible(visible)
            .CountAsync(f => f.Status == FollowUpStatus.Planned);

        var model = new DashboardViewModel
        {
            Range = key,
            RangeLabel = label,
            From = from,
            To = to,
            ScopeLabel = _user.IsAdmin ? "All teams" : _user.IsManager ? "Your team" : "Your accounts",

            TotalCustomers = await customers.CountAsync(),
            TotalLeads = leadStatuses.Count,
            OpenLeads = leadStatuses.Count(s => LeadWorkflow.OpenStatuses.Contains(s)),
            TotalOpportunities = opportunityRows.Count,
            OpenOpportunities = open.Count,
            WonOpportunities = opportunityRows.Count(o => o.Status == OpportunityStatus.Won),
            LostOpportunities = opportunityRows.Count(o => o.Status == OpportunityStatus.Lost),
            TotalPipelineValue = open.Sum(o => o.Amount),
            WeightedPipelineValue = Math.Round(open.Sum(o => o.Amount * o.Probability / 100m), 2),
            WonValue = opportunityRows.Where(o => o.Status == OpportunityStatus.Won).Sum(o => o.Amount),
            PendingFollowUps = pendingFollowUps,
            OverdueFollowUps = overdue,
            FollowUpsDueToday = dueToday,

            UpcomingFollowUps = await _followUps.GetUpcomingAsync(6),
            RecentActivities = await _activities.GetRecentAsync(6)
        };

        // Lead status chart (required: New, Contacted, Qualified, Lost, Converted)
        var leadChartStatuses = new[] { LeadStatus.New, LeadStatus.Contacted, LeadStatus.Qualified, LeadStatus.Lost, LeadStatus.Converted };
        model.LeadStatusChart = new ChartData
        {
            Labels = leadChartStatuses.Select(s => s.ToString()).ToList(),
            Values = leadChartStatuses.Select(s => (decimal)leadStatuses.Count(x => x == s)).ToList()
        };

        // Opportunity pipeline chart (Qualification, Proposal, Negotiation, Won, Lost)
        var stages = Enum.GetValues<OpportunityStage>();
        model.PipelineChart = new ChartData
        {
            Labels = stages.Select(s => s.ToString()).ToList(),
            Values = stages.Select(s => opportunityRows.Where(o => o.Stage == s).Sum(o => o.Amount)).ToList(),
            Counts = stages.Select(s => opportunityRows.Count(o => o.Stage == s)).ToList()
        };

        // Monthly sales: won amount per month for the last 12 months (independent of the date filter)
        var firstMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-11);
        var won = await _db.Opportunities.AsNoTracking().WhereVisible(visible)
            .Where(o => o.Status == OpportunityStatus.Won && o.ClosedDate >= firstMonth)
            .Select(o => new { o.ClosedDate, o.Amount })
            .ToListAsync();
        var months = Enumerable.Range(0, 12).Select(i => firstMonth.AddMonths(i)).ToList();
        model.MonthlySalesChart = new ChartData
        {
            Labels = months.Select(m => m.ToString("MMM yy", CultureInfo.InvariantCulture)).ToList(),
            Values = months.Select(m => won.Where(w => w.ClosedDate!.Value.Year == m.Year && w.ClosedDate.Value.Month == m.Month).Sum(w => w.Amount)).ToList(),
            Counts = months.Select(m => won.Count(w => w.ClosedDate!.Value.Year == m.Year && w.ClosedDate.Value.Month == m.Month)).ToList()
        };

        if (_user.IsAdmin)
        {
            var lockoutEnds = await _db.Users.AsNoTracking().Select(u => u.LockoutEnd).ToListAsync();
            var weekAgo = DateTime.Now.AddDays(-7);
            model.Admin = new AdminStats
            {
                TotalUsers = await _db.Users.CountAsync(),
                ActiveUsers = await _db.Users.CountAsync(u => u.IsActive),
                LockedUsers = lockoutEnds.Count(end => end.HasValue && end.Value > DateTimeOffset.UtcNow),
                FailedLoginsLast7Days = await _db.AuditLogs.CountAsync(a =>
                    (a.Action == AuditActions.FailedLogin || a.Action == AuditActions.Lockout) && a.CreatedDate >= weekAgo),
                AuditEventsLast7Days = await _db.AuditLogs.CountAsync(a => a.CreatedDate >= weekAgo)
            };
        }

        return model;
    }

    private static (DateTime? Start, DateTime? End, string Label, string Key) ResolveRange(string? range, DateTime? from, DateTime? to)
    {
        var today = DateTime.Today;
        switch (range)
        {
            case "today":
                return (today, today.AddDays(1), "Today", "today");
            case "week":
                var diff = ((int)today.DayOfWeek + 6) % 7; // Monday as first day
                var monday = today.AddDays(-diff);
                return (monday, monday.AddDays(7), "This week", "week");
            case "month":
                var first = new DateTime(today.Year, today.Month, 1);
                return (first, first.AddMonths(1), "This month", "month");
            case "custom" when from.HasValue || to.HasValue:
                var start = from?.Date;
                var end = to?.Date.AddDays(1);
                return (start, end, $"{UiHelpers.Date(from)} to {UiHelpers.Date(to)}", "custom");
            default:
                return (null, null, "All time", "all");
        }
    }
}
