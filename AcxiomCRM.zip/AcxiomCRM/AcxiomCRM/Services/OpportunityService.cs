using AcxiomCRM.Common;
using AcxiomCRM.Data;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using AcxiomCRM.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Services;

public interface IOpportunityService
{
    Task<PagedResult<Opportunity>> SearchAsync(OpportunityFilter filter);
    Task<Opportunity?> GetAsync(int id);
    Task<OpportunityDetailsViewModel?> GetDetailsAsync(int id);
    Task<ServiceResult<Opportunity>> CreateAsync(OpportunityRequestDto dto);
    Task<ServiceResult<Opportunity>> UpdateAsync(int id, OpportunityRequestDto dto);
    Task<ServiceResult<Opportunity>> MoveStageAsync(int id, OpportunityStage stage);
    Task<ServiceResult<bool>> DeleteAsync(int id);
    Task<PipelineSummaryDto> GetPipelineSummaryAsync();
    Task<PipelineBoardViewModel> GetBoardAsync();
}

public class OpportunityService : ServiceBase, IOpportunityService
{
    public OpportunityService(ApplicationDbContext db, ICurrentUserService currentUser, IAuditService audit, ILogger<OpportunityService> logger)
        : base(db, currentUser, audit, logger) { }

    public async Task<PagedResult<Opportunity>> SearchAsync(OpportunityFilter f)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        IQueryable<Opportunity> q = Db.Opportunities.AsNoTracking()
            .Include(o => o.Customer).Include(o => o.AssignedUser)
            .WhereVisible(visible);

        if (!string.IsNullOrWhiteSpace(f.Name))
        {
            var p = f.Name.ToLikePattern();
            q = q.Where(o => EF.Functions.Like(o.OpportunityName, p));
        }
        if (!string.IsNullOrWhiteSpace(f.Customer))
        {
            var p = f.Customer.ToLikePattern();
            q = q.Where(o => EF.Functions.Like(o.Customer!.CustomerName, p)
                             || (o.Customer.CompanyName != null && EF.Functions.Like(o.Customer.CompanyName, p)));
        }
        if (f.Stage.HasValue)
        {
            var stage = f.Stage.Value;
            q = q.Where(o => o.Stage == stage);
        }
        if (f.Status.HasValue)
        {
            var status = f.Status.Value;
            q = q.Where(o => o.Status == status);
        }
        if (!string.IsNullOrWhiteSpace(f.AssignedTo))
        {
            var owner = f.AssignedTo;
            q = q.Where(o => o.AssignedTo == owner);
        }

        q = f.Sort switch
        {
            "name" => q.OrderBy(o => o.OpportunityName),
            "name_desc" => q.OrderByDescending(o => o.OpportunityName),
            "amount" => q.OrderBy(o => o.Amount),
            "amount_desc" => q.OrderByDescending(o => o.Amount),
            "close" => q.OrderBy(o => o.ExpectedCloseDate),
            "close_desc" => q.OrderByDescending(o => o.ExpectedCloseDate),
            "stage" => q.OrderBy(o => o.Stage),
            "stage_desc" => q.OrderByDescending(o => o.Stage),
            "created" => q.OrderBy(o => o.CreatedDate),
            _ => q.OrderByDescending(o => o.CreatedDate)
        };

        return await q.ToPagedAsync(f.Page, f.PageSize);
    }

    public async Task<Opportunity?> GetAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        return await Db.Opportunities.AsNoTracking()
            .Include(o => o.Customer).Include(o => o.Lead).Include(o => o.AssignedUser)
            .WhereVisible(visible)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
    }

    public async Task<OpportunityDetailsViewModel?> GetDetailsAsync(int id)
    {
        var opportunity = await GetAsync(id);
        if (opportunity is null) return null;
        var key = id.ToString();
        return new OpportunityDetailsViewModel
        {
            Opportunity = opportunity,
            FollowUps = await Db.FollowUps.AsNoTracking().Include(f => f.AssignedUser)
                .Where(f => f.OpportunityId == id).OrderByDescending(f => f.FollowUpDate).ToListAsync(),
            History = await Db.AuditLogs.AsNoTracking()
                .Where(a => a.EntityName == AuditEntities.Opportunity && a.RecordId == key)
                .OrderByDescending(a => a.CreatedDate).Take(20).ToListAsync()
        };
    }

    public async Task<ServiceResult<Opportunity>> CreateAsync(OpportunityRequestDto dto)
    {
        Normalize(dto);
        var result = new ServiceResult<Opportunity>();
        ServerValidator.Validate(dto, result);
        await ValidateBusinessRulesAsync(dto, result);

        if (dto.Stage.HasValue && OpportunityWorkflow.IsClosed(dto.Stage.Value))
            result.AddError(nameof(dto.Stage), "A new opportunity must start in Qualification, Proposal or Negotiation.");

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var stage = dto.Stage!.Value;
        var opportunity = new Opportunity
        {
            OpportunityName = dto.OpportunityName,
            CustomerId = dto.CustomerId!.Value,
            LeadId = dto.LeadId,
            Amount = dto.Amount!.Value,
            Stage = stage,
            Status = OpportunityWorkflow.StatusFor(stage),
            Probability = dto.Probability!.Value,
            ExpectedCloseDate = dto.ExpectedCloseDate!.Value.Date,
            Source = dto.Source,
            Notes = dto.Notes,
            AssignedTo = owner!,
            CreatedBy = CurrentUser.UserName,
            CreatedDate = DateTime.Now
        };

        Db.Opportunities.Add(opportunity);
        if (!await TrySaveAsync(result, "The opportunity could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Create, AuditEntities.Opportunity, opportunity.OpportunityId, newValue: opportunity);
        return result.WithData(opportunity);
    }

    public async Task<ServiceResult<Opportunity>> UpdateAsync(int id, OpportunityRequestDto dto)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var opportunity = await Db.Opportunities.WhereVisible(visible).FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opportunity is null) return ServiceResult<Opportunity>.Missing();

        Normalize(dto);
        var result = new ServiceResult<Opportunity>();
        ServerValidator.Validate(dto, result);
        await ValidateBusinessRulesAsync(dto, result);

        if (dto.Stage.HasValue && !OpportunityWorkflow.CanTransition(opportunity.Stage, dto.Stage.Value))
            result.AddError(nameof(dto.Stage), $"This opportunity is already {opportunity.Stage}; closed opportunities cannot move to another stage.");

        var owner = await CurrentUser.ResolveAssigneeAsync(dto.AssignedTo, opportunity.AssignedTo);
        if (owner is null) result.AddError(nameof(dto.AssignedTo), "You cannot assign records to the selected user.");
        if (!result.Succeeded) return result;

        var before = AuditSnapshot.ToJson(opportunity);
        var oldStage = opportunity.Stage;
        var newStage = dto.Stage!.Value;

        opportunity.OpportunityName = dto.OpportunityName;
        opportunity.CustomerId = dto.CustomerId!.Value;
        opportunity.LeadId = dto.LeadId;
        opportunity.Amount = dto.Amount!.Value;
        opportunity.Stage = newStage;
        opportunity.Status = OpportunityWorkflow.StatusFor(newStage);
        opportunity.Probability = OpportunityWorkflow.IsClosed(newStage)
            ? OpportunityWorkflow.DefaultProbability(newStage)
            : dto.Probability!.Value;
        opportunity.ExpectedCloseDate = dto.ExpectedCloseDate!.Value.Date;
        opportunity.Source = dto.Source;
        opportunity.Notes = dto.Notes;
        opportunity.AssignedTo = owner!;
        opportunity.ModifiedDate = DateTime.Now;
        if (oldStage != newStage && OpportunityWorkflow.IsClosed(newStage))
            opportunity.ClosedDate = DateTime.Now;

        if (!await TrySaveAsync(result, "The opportunity could not be saved.")) return result;

        await Audit.LogAsync(AuditActions.Update, AuditEntities.Opportunity, id, before, opportunity);
        if (oldStage != newStage)
            await Audit.LogAsync(AuditActions.StageChange, AuditEntities.Opportunity, id, oldStage.ToString(), newStage.ToString());

        return result.WithData(opportunity);
    }

    public async Task<ServiceResult<Opportunity>> MoveStageAsync(int id, OpportunityStage stage)
    {
        var current = await GetAsync(id);
        if (current is null) return ServiceResult<Opportunity>.Missing();

        var probability = OpportunityWorkflow.IsClosed(stage) || current.Probability == OpportunityWorkflow.DefaultProbability(current.Stage)
            ? OpportunityWorkflow.DefaultProbability(stage)
            : current.Probability;

        return await UpdateAsync(id, new OpportunityRequestDto
        {
            OpportunityName = current.OpportunityName,
            CustomerId = current.CustomerId,
            LeadId = current.LeadId,
            Amount = current.Amount,
            Stage = stage,
            Probability = probability,
            ExpectedCloseDate = current.ExpectedCloseDate,
            Source = current.Source,
            Notes = current.Notes,
            AssignedTo = current.AssignedTo
        });
    }

    public async Task<ServiceResult<bool>> DeleteAsync(int id)
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var opportunity = await Db.Opportunities.WhereVisible(visible).FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opportunity is null) return ServiceResult<bool>.Missing();

        var before = AuditSnapshot.ToJson(opportunity);

        foreach (var followUp in await Db.FollowUps.Where(f => f.OpportunityId == id).ToListAsync())
        {
            if (followUp.CustomerId is null && followUp.LeadId is null) Db.FollowUps.Remove(followUp);
            else followUp.OpportunityId = null;
        }
        foreach (var lead in await Db.Leads.Where(l => l.ConvertedOpportunityId == id).ToListAsync())
            lead.ConvertedOpportunityId = null;

        Db.Opportunities.Remove(opportunity);

        var result = new ServiceResult<bool>();
        if (!await TrySaveAsync(result, "The opportunity could not be deleted.")) return result;

        await Audit.LogAsync(AuditActions.Delete, AuditEntities.Opportunity, id, before);
        return result.WithData(true);
    }

    public async Task<PipelineSummaryDto> GetPipelineSummaryAsync()
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var rows = await Db.Opportunities.AsNoTracking().WhereVisible(visible)
            .Select(o => new { o.Stage, o.Status, o.Amount, o.Probability, o.AssignedTo, OwnerName = o.AssignedUser!.FullName })
            .ToListAsync();

        var stages = Enum.GetValues<OpportunityStage>().Select(stage =>
        {
            var inStage = rows.Where(r => r.Stage == stage).ToList();
            return new PipelineStageSummary
            {
                Stage = stage.ToString(),
                Count = inStage.Count,
                Amount = inStage.Sum(r => r.Amount),
                WeightedAmount = Math.Round(inStage.Sum(r => r.Amount * r.Probability / 100m), 2)
            };
        }).ToList();

        var owners = rows.GroupBy(r => new { r.AssignedTo, r.OwnerName })
            .Select(g => new PipelineOwnerSummary
            {
                OwnerId = g.Key.AssignedTo,
                OwnerName = g.Key.OwnerName,
                OpenCount = g.Count(r => r.Status == OpportunityStatus.Open),
                OpenAmount = g.Where(r => r.Status == OpportunityStatus.Open).Sum(r => r.Amount),
                WeightedAmount = Math.Round(g.Where(r => r.Status == OpportunityStatus.Open).Sum(r => r.Amount * r.Probability / 100m), 2),
                WonCount = g.Count(r => r.Status == OpportunityStatus.Won),
                WonAmount = g.Where(r => r.Status == OpportunityStatus.Won).Sum(r => r.Amount)
            })
            .OrderByDescending(o => o.OpenAmount)
            .ToList();

        var open = rows.Where(r => r.Status == OpportunityStatus.Open).ToList();
        return new PipelineSummaryDto
        {
            Stages = stages,
            Owners = owners,
            TotalOpenAmount = open.Sum(r => r.Amount),
            TotalWeightedAmount = Math.Round(open.Sum(r => r.Amount * r.Probability / 100m), 2)
        };
    }

    public async Task<PipelineBoardViewModel> GetBoardAsync()
    {
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        var recentCutoff = DateTime.Today.AddDays(-90);
        var items = await Db.Opportunities.AsNoTracking()
            .Include(o => o.Customer).Include(o => o.AssignedUser)
            .WhereVisible(visible)
            .Where(o => o.Status == OpportunityStatus.Open || o.ClosedDate >= recentCutoff)
            .OrderBy(o => o.ExpectedCloseDate)
            .ToListAsync();

        return new PipelineBoardViewModel
        {
            Columns = Enum.GetValues<OpportunityStage>()
                .ToDictionary(stage => stage, stage => items.Where(o => o.Stage == stage).ToList()),
            Summary = await GetPipelineSummaryAsync()
        };
    }

    private async Task ValidateBusinessRulesAsync(OpportunityRequestDto dto, ServiceResult<Opportunity> result)
    {
        // Explicit business rules (also enforced by attributes; repeated here on purpose).
        if (dto.Amount is <= 0m)
            result.AddError(nameof(dto.Amount), ValidationRules.AmountMessage);
        if (dto.Probability is < 0 or > 100)
            result.AddError(nameof(dto.Probability), ValidationRules.ProbabilityMessage);
        if (dto.Stage.HasValue && !OpportunityWorkflow.IsClosed(dto.Stage.Value)
            && dto.ExpectedCloseDate.HasValue && dto.ExpectedCloseDate.Value.Date < DateTime.Today)
            result.AddError(nameof(dto.ExpectedCloseDate), ValidationRules.CloseDateMessage);

        // Referenced records must exist AND be inside the user's scope.
        var visible = await CurrentUser.GetVisibleUserIdsAsync();
        if (dto.CustomerId.HasValue)
        {
            var customerId = dto.CustomerId.Value;
            if (!await Db.Customers.WhereVisible(visible).AnyAsync(c => c.CustomerId == customerId))
                result.AddError(nameof(dto.CustomerId), "Select a valid customer.");
        }
        if (dto.LeadId.HasValue)
        {
            var leadId = dto.LeadId.Value;
            if (!await Db.Leads.WhereVisible(visible).AnyAsync(l => l.LeadId == leadId))
                result.AddError(nameof(dto.LeadId), "Select a valid lead.");
        }
    }

    private static void Normalize(OpportunityRequestDto dto)
    {
        dto.OpportunityName = dto.OpportunityName?.Trim() ?? string.Empty;
        dto.Source = Clean(dto.Source);
        dto.Notes = Clean(dto.Notes);
    }
}
