using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AcxiomCRM.ViewModels;

// ------------------------------------------------------------------ Customers

public class CustomerFormViewModel : CustomerRequestDto
{
    public int? CustomerId { get; set; }
    public string? CustomerCode { get; set; }

    [ValidateNever] public List<SelectListItem> AssignableUsers { get; set; } = new();
    public bool CanAssign { get; set; }
}

public class CustomerIndexViewModel
{
    public CustomerFilter Filter { get; init; } = new();
    public PagedResult<Customer> Results { get; init; } = new(Array.Empty<Customer>(), 1, 10, 0);
    public List<SelectListItem> Owners { get; init; } = new();
    public bool CanDelete { get; init; }
}

public class CustomerDetailsViewModel
{
    public Customer Customer { get; init; } = new();
    public List<Opportunity> Opportunities { get; init; } = new();
    public List<FollowUp> FollowUps { get; init; } = new();
    public List<Activity> Activities { get; init; } = new();
    public List<Lead> SourceLeads { get; init; } = new();
    public List<AuditLog> History { get; init; } = new();
    public bool CanDelete { get; set; }
}

// ------------------------------------------------------------------ Leads

public class LeadFormViewModel : LeadRequestDto
{
    public int? LeadId { get; set; }
    public string? LeadCode { get; set; }
    public LeadStatus? CurrentStatus { get; set; }

    [ValidateNever] public List<SelectListItem> AssignableUsers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> StatusOptions { get; set; } = new();
    public bool CanAssign { get; set; }
}

public class LeadIndexViewModel
{
    public LeadFilter Filter { get; init; } = new();
    public PagedResult<Lead> Results { get; init; } = new(Array.Empty<Lead>(), 1, 10, 0);
    public List<SelectListItem> Owners { get; init; } = new();
    public bool CanDelete { get; init; }
}

public class LeadDetailsViewModel
{
    public Lead Lead { get; init; } = new();
    public List<FollowUp> FollowUps { get; init; } = new();
    public List<Activity> Activities { get; init; } = new();
    public List<Opportunity> Opportunities { get; init; } = new();
    public List<AuditLog> History { get; init; } = new();
    public bool CanDelete { get; set; }
}

public class LeadConvertViewModel : LeadConvertDto
{
    public int LeadId { get; set; }
    public string? LeadCode { get; set; }
    public string? LeadName { get; set; }

    [ValidateNever] public List<SelectListItem> Customers { get; set; } = new();
}

// ------------------------------------------------------------------ Opportunities

public class OpportunityFormViewModel : OpportunityRequestDto
{
    public int? OpportunityId { get; set; }
    public OpportunityStage? CurrentStage { get; set; }

    [ValidateNever] public List<SelectListItem> Customers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Leads { get; set; } = new();
    [ValidateNever] public List<SelectListItem> AssignableUsers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> StageOptions { get; set; } = new();
    public bool CanAssign { get; set; }
}

public class OpportunityIndexViewModel
{
    public OpportunityFilter Filter { get; init; } = new();
    public PagedResult<Opportunity> Results { get; init; } = new(Array.Empty<Opportunity>(), 1, 10, 0);
    public List<SelectListItem> Owners { get; init; } = new();
    public bool CanDelete { get; init; }
}

public class OpportunityDetailsViewModel
{
    public Opportunity Opportunity { get; init; } = new();
    public List<FollowUp> FollowUps { get; init; } = new();
    public List<AuditLog> History { get; init; } = new();
    public bool CanDelete { get; set; }
}

public class PipelineBoardViewModel
{
    public Dictionary<OpportunityStage, List<Opportunity>> Columns { get; init; } = new();
    public PipelineSummaryDto Summary { get; init; } = new();
}

// ------------------------------------------------------------------ Follow-ups & activities

public class FollowUpFormViewModel : FollowUpRequestDto
{
    public int? FollowUpId { get; set; }
    public FollowUpStatus? CurrentStatus { get; set; }

    [ValidateNever] public List<SelectListItem> Customers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Leads { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Opportunities { get; set; } = new();
    [ValidateNever] public List<SelectListItem> AssignableUsers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> StatusOptions { get; set; } = new();
    public bool CanAssign { get; set; }
}

public class FollowUpIndexViewModel
{
    public FollowUpFilter Filter { get; init; } = new();
    public PagedResult<FollowUp> Results { get; init; } = new(Array.Empty<FollowUp>(), 1, 10, 0);
    public List<SelectListItem> Owners { get; init; } = new();
    public int OverdueCount { get; init; }
    public int TodayCount { get; init; }
    public bool CanDelete { get; init; }
}

public class ActivityFormViewModel : ActivityRequestDto
{
    public int? ActivityId { get; set; }

    [ValidateNever] public List<SelectListItem> Customers { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Leads { get; set; } = new();
    [ValidateNever] public List<SelectListItem> AssignableUsers { get; set; } = new();
    public bool CanAssign { get; set; }
}

public class ActivityIndexViewModel
{
    public ActivityFilter Filter { get; init; } = new();
    public PagedResult<Activity> Results { get; init; } = new(Array.Empty<Activity>(), 1, 10, 0);
    public List<SelectListItem> Owners { get; init; } = new();
    public bool CanDelete { get; init; }
}

// ------------------------------------------------------------------ Dashboard

public class ChartData
{
    public List<string> Labels { get; init; } = new();
    public List<decimal> Values { get; init; } = new();
    public List<int> Counts { get; init; } = new();
}

public class AdminStats
{
    public int TotalUsers { get; init; }
    public int ActiveUsers { get; init; }
    public int LockedUsers { get; init; }
    public int FailedLoginsLast7Days { get; init; }
    public int AuditEventsLast7Days { get; init; }
}

public class DashboardViewModel
{
    public string Range { get; init; } = "all";
    public string RangeLabel { get; init; } = "All time";
    public DateTime? From { get; init; }
    public DateTime? To { get; init; }
    public string ScopeLabel { get; init; } = string.Empty;

    public int TotalCustomers { get; init; }
    public int TotalLeads { get; init; }
    public int OpenLeads { get; init; }
    public int TotalOpportunities { get; init; }
    public int OpenOpportunities { get; init; }
    public int WonOpportunities { get; init; }
    public int LostOpportunities { get; init; }
    public decimal TotalPipelineValue { get; init; }
    public decimal WeightedPipelineValue { get; init; }
    public decimal WonValue { get; init; }
    public int PendingFollowUps { get; init; }
    public int OverdueFollowUps { get; init; }
    public int FollowUpsDueToday { get; init; }

    public ChartData LeadStatusChart { get; set; } = new();
    public ChartData PipelineChart { get; set; } = new();
    public ChartData MonthlySalesChart { get; set; } = new();

    public List<FollowUp> UpcomingFollowUps { get; init; } = new();
    public List<Activity> RecentActivities { get; init; } = new();
    public AdminStats? Admin { get; set; }

    public decimal WinRate => WonOpportunities + LostOpportunities == 0
        ? 0
        : Math.Round(WonOpportunities * 100m / (WonOpportunities + LostOpportunities), 1);
}
