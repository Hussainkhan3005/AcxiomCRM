using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Common;
using AcxiomCRM.Dtos;
using AcxiomCRM.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AcxiomCRM.ViewModels;

public class UserListItem
{
    public string Id { get; init; } = string.Empty;
    public string FullName { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string? Role { get; init; }
    public string? ManagerName { get; init; }
    public bool IsActive { get; init; }
    public DateTimeOffset? LockoutEnd { get; init; }
    public int AccessFailedCount { get; init; }
    public DateTime CreatedDate { get; init; }
    public bool IsLockedOut => LockoutEnd.HasValue && LockoutEnd.Value > DateTimeOffset.UtcNow;
}

public class UserIndexViewModel
{
    public string? Search { get; init; }
    public string? Role { get; init; }
    public string? Status { get; init; }
    public PagedResult<UserListItem> Results { get; init; } = new(Array.Empty<UserListItem>(), 1, 10, 0);
    public bool CanManage { get; init; }
    public string CurrentUserId { get; init; } = string.Empty;
}

public abstract class UserFormBase
{
    [Required(ErrorMessage = "Full name is required.")]
    [StringLength(ValidationRules.NameMaxLength, ErrorMessage = "Full name cannot exceed {1} characters.")]
    [Display(Name = "Full name")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [StringLength(ValidationRules.EmailMaxLength)]
    [RegularExpression(ValidationRules.EmailPattern, ErrorMessage = ValidationRules.EmailMessage)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Select a role.")]
    public string Role { get; set; } = AppRoles.SalesExecutive;

    [Display(Name = "Reports to (manager)")]
    public string? ManagerId { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [ValidateNever] public List<SelectListItem> Roles { get; set; } = new();
    [ValidateNever] public List<SelectListItem> Managers { get; set; } = new();
}

public class UserCreateViewModel : UserFormBase
{
    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100, MinimumLength = 8, ErrorMessage = "Password must be at least {2} characters.")]
    [RegularExpression(ValidationRules.PasswordPattern, ErrorMessage = ValidationRules.PasswordMessage)]
    [DataType(DataType.Password)]
    [Display(Name = "Initial password")]
    public string Password { get; set; } = string.Empty;

    [Required(ErrorMessage = "Confirm the password.")]
    [DataType(DataType.Password)]
    [Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = string.Empty;
}

public class UserEditViewModel : UserFormBase
{
    public string Id { get; set; } = string.Empty;
    public bool IsLockedOut { get; set; }
    public DateTimeOffset? LockoutEnd { get; set; }
    public int AccessFailedCount { get; set; }
    public bool IsSelf { get; set; }
}

public class ResetPasswordViewModel
{
    public string Id { get; set; } = string.Empty;
    public string? FullName { get; set; }

    [Required(ErrorMessage = "Enter a new password.")]
    [StringLength(100, MinimumLength = 8, ErrorMessage = "Password must be at least {2} characters.")]
    [RegularExpression(ValidationRules.PasswordPattern, ErrorMessage = ValidationRules.PasswordMessage)]
    [DataType(DataType.Password)]
    [Display(Name = "New password")]
    public string NewPassword { get; set; } = string.Empty;

    [Required(ErrorMessage = "Confirm the new password.")]
    [DataType(DataType.Password)]
    [Compare(nameof(NewPassword), ErrorMessage = "Passwords do not match.")]
    [Display(Name = "Confirm new password")]
    public string ConfirmPassword { get; set; } = string.Empty;
}

public class RoleListItem
{
    public string Name { get; init; } = string.Empty;
    public int UserCount { get; init; }
    public string Description { get; init; } = string.Empty;
}

public class AuditIndexViewModel
{
    public AuditFilter Filter { get; init; } = new();
    public PagedResult<AuditLog> Results { get; init; } = new(Array.Empty<AuditLog>(), 1, 20, 0);
    public bool IsLimitedView { get; init; }
}
