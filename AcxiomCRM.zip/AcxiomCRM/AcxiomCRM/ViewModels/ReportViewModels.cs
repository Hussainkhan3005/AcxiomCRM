using System.Security.Claims;
using AcxiomCRM.Common;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AcxiomCRM.ViewModels;

public enum ColumnFormat
{
    Text,
    Money,
    Number,
    Percent,
    Date,
    DateTime
}

public record ReportColumn(string Header, ColumnFormat Format = ColumnFormat.Text)
{
    public bool IsNumeric => Format is ColumnFormat.Money or ColumnFormat.Number or ColumnFormat.Percent;
}

public class ReportDefinition
{
    public string Key { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public string Icon { get; init; } = "bi-table";
    public string[] Roles { get; init; } = AppRoles.All;
    public bool ShowTotals { get; init; }
    public bool HasOwnerFilter { get; init; } = true;
    public string DateLabel { get; init; } = "Created";
    public string StatusLabel { get; init; } = "Status";

    public bool IsAllowed(ClaimsPrincipal user) => Roles.Any(user.IsInRole);
}

public static class ReportCatalog
{
    private static readonly string[] SalesAndUp = AppRoles.All;
    private static readonly string[] ManagersAndUp = { AppRoles.Admin, AppRoles.Manager };
    private static readonly string[] AdminOnly = { AppRoles.Admin };

    public static readonly IReadOnlyList<ReportDefinition> All = new List<ReportDefinition>
    {
        new() { Key = "customers", Title = "Customer report", Icon = "bi-building", Roles = SalesAndUp,
            Description = "Customer list with status, owner and creation date." },
        new() { Key = "leads", Title = "Lead report", Icon = "bi-person-lines-fill", Roles = SalesAndUp, ShowTotals = true,
            Description = "Lead source, status, owner and conversion details." },
        new() { Key = "followups", Title = "Follow-up report", Icon = "bi-calendar-check", Roles = SalesAndUp, DateLabel = "Follow-up date",
            Description = "Planned, completed, missed and overdue follow-ups." },
        new() { Key = "opportunities", Title = "Opportunity report", Icon = "bi-briefcase", Roles = SalesAndUp, ShowTotals = true, StatusLabel = "Stage",
            Description = "Stage, amount, probability and expected close date." },
        new() { Key = "pipeline", Title = "Pipeline report", Icon = "bi-funnel", Roles = SalesAndUp,
            Description = "Stage-wise and owner-wise pipeline, including weighted value." },
        new() { Key = "conversion", Title = "Sales & conversion report", Icon = "bi-graph-up-arrow", Roles = SalesAndUp, ShowTotals = true,
            Description = "Lead conversion and opportunity win/loss by owner." },
        new() { Key = "useractivity", Title = "User activity report", Icon = "bi-activity", Roles = ManagersAndUp, ShowTotals = true, DateLabel = "Activity date",
            Description = "Actions and activity counts per user, from the audit trail." },
        new() { Key = "audit", Title = "Audit report", Icon = "bi-shield-check", Roles = AdminOnly, HasOwnerFilter = false, DateLabel = "Event date", StatusLabel = "Action",
            Description = "Security and business audit events." }
    };

    public static ReportDefinition? Find(string? key) =>
        All.FirstOrDefault(r => string.Equals(r.Key, key, StringComparison.OrdinalIgnoreCase));
}

public class ReportRequest
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public string? AssignedTo { get; set; }
    public string? Status { get; set; }
    public int? SortColumn { get; set; }
    public bool Desc { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 15;
}

public class ReportResult
{
    public ReportDefinition Definition { get; init; } = new();
    public ReportRequest Request { get; init; } = new();
    public List<ReportColumn> Columns { get; init; } = new();
    public List<object?[]> Rows { get; set; } = new();
    public object?[]? Totals { get; set; }
    public int TotalCount { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 15;
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);
    public List<SelectListItem> StatusOptions { get; set; } = new();
    public List<SelectListItem> OwnerOptions { get; set; } = new();

    public PagerInfo Pager => new(Page, TotalPages, TotalCount,
        TotalCount == 0 ? 0 : (Page - 1) * PageSize + 1,
        Math.Min(Page * PageSize, TotalCount));

    public static string Display(object? value, ReportColumn column) => value switch
    {
        null => "-",
        DateTime d when column.Format == ColumnFormat.Date => UiHelpers.Date(d),
        DateTime d => UiHelpers.DateAndTime(d),
        decimal m when column.Format == ColumnFormat.Money => UiHelpers.Money(m),
        decimal m when column.Format == ColumnFormat.Percent => $"{m:0.#}%",
        int i when column.Format == ColumnFormat.Percent => $"{i}%",
        decimal m => UiHelpers.Number(m),
        _ => value.ToString() ?? "-"
    };
}
