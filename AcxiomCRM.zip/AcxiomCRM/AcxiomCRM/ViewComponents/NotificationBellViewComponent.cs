using AcxiomCRM.Services;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.ViewComponents;

/// <summary>Header notifications: overdue follow-ups and follow-ups due today (scoped to the user).</summary>
public class NotificationBellViewComponent : ViewComponent
{
    private readonly IFollowUpService _followUps;

    public NotificationBellViewComponent(IFollowUpService followUps) => _followUps = followUps;

    public async Task<IViewComponentResult> InvokeAsync()
    {
        var (overdue, today) = await _followUps.GetPendingCountsAsync();
        return View((Overdue: overdue, Today: today));
    }
}
