/*
 * Client-side validation extensions for jquery.validate.unobtrusive.
 * Server-side validation repeats every rule, because browser checks can be bypassed.
 */
(function ($) {
    'use strict';
    if (!$ || !$.validator) { return; }

    function startOfToday() {
        var now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }

    function parseDate(value) {
        // Accepts yyyy-MM-dd and yyyy-MM-ddTHH:mm (inputs of type date / datetime-local).
        var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || '');
        return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
    }

    // Date cannot be earlier than today, unless another field (e.g. Stage = Won) switches the rule off.
    $.validator.addMethod('datenotinpast', function (value, element, params) {
        if (!value) { return true; }

        if (params && params.ignoreprop) {
            var other = $(element).closest('form').find('[name$="' + params.ignoreprop + '"]').first().val();
            var ignored = (params.ignorevalues || '').split(',').map(function (v) { return v.trim().toLowerCase(); });
            if (other && ignored.indexOf(String(other).toLowerCase()) >= 0) { return true; }
        }

        var date = parseDate(value);
        return !date || date >= startOfToday();
    });

    $.validator.unobtrusive.adapters.add('datenotinpast', ['ignoreprop', 'ignorevalues'], function (options) {
        options.rules.datenotinpast = {
            ignoreprop: options.params.ignoreprop,
            ignorevalues: options.params.ignorevalues
        };
        options.messages.datenotinpast = options.message;
    });

    // Re-check the date when the field it depends on (stage / status) changes.
    $(document).on('change', 'select', function () {
        var form = $(this).closest('form');
        form.find('[data-val-datenotinpast]').each(function () {
            if ($(this).val()) { $(this).valid(); }
        });
    });

    // Don't mark untouched fields invalid while the user is typing in another one.
    $.validator.setDefaults({ onkeyup: false });
})(window.jQuery);
