/* Site-wide behaviour: confirmation dialogs, auto-submit selects, conditional form sections. */
(function () {
    'use strict';

    // ---- Confirmation dialog for destructive actions: <form data-confirm="Are you sure?"> ----
    var modalEl = document.getElementById('confirmModal');
    var modal = modalEl ? new bootstrap.Modal(modalEl) : null;
    var pendingForm = null;

    function ask(message, form) {
        if (!modal) { return window.confirm(message); }
        pendingForm = form;
        document.getElementById('confirmModalBody').textContent = message;
        modal.show();
        return false;
    }

    document.addEventListener('submit', function (e) {
        var form = e.target;
        var message = form.getAttribute && form.getAttribute('data-confirm');
        if (!message || form.dataset.confirmed === 'true') { return; }
        e.preventDefault();
        ask(message, form);
    });

    var okButton = document.getElementById('confirmModalOk');
    if (okButton) {
        okButton.addEventListener('click', function () {
            if (!pendingForm) { return; }
            pendingForm.dataset.confirmed = 'true';
            modal.hide();
            pendingForm.submit();
        });
    }

    // ---- <select data-autosubmit>: submit its form on change (pipeline board) ----
    document.querySelectorAll('select[data-autosubmit]').forEach(function (select) {
        var original = select.value;
        select.addEventListener('change', function () {
            var risky = (select.getAttribute('data-confirm-values') || '').split(',');
            var text = select.getAttribute('data-confirm-text');
            if (text && risky.indexOf(select.value) >= 0) {
                if (!window.confirm(text)) { select.value = original; return; }
            }
            select.form.submit();
        });
    });

    // ---- Checkbox that shows/hides a section: <input data-toggle-checkbox="#target"> ----
    document.querySelectorAll('[data-toggle-checkbox]').forEach(function (box) {
        var target = document.querySelector(box.getAttribute('data-toggle-checkbox'));
        if (!target) { return; }
        var sync = function () { target.hidden = !box.checked; };
        box.addEventListener('change', sync);
        sync();
    });

    // ---- Select whose empty option reveals a section: <select data-toggle-select-empty="#target"> ----
    document.querySelectorAll('[data-toggle-select-empty]').forEach(function (select) {
        var target = document.querySelector(select.getAttribute('data-toggle-select-empty'));
        if (!target) { return; }
        var sync = function () { target.hidden = select.value !== ''; };
        select.addEventListener('change', sync);
        sync();
    });

    // ---- User form: manager picker only applies to Sales Executives ----
    var roleSelect = document.querySelector('[data-role-select]');
    var managerField = document.querySelector('[data-manager-field]');
    if (roleSelect && managerField) {
        var syncRole = function () { managerField.hidden = roleSelect.value !== 'SalesExecutive'; };
        roleSelect.addEventListener('change', syncRole);
        syncRole();
    }

    // ---- Opportunity form: suggest a probability when the stage changes ----
    var stageSelect = document.querySelector('[data-stage-select]');
    var probability = document.querySelector('[data-probability-input]');
    if (stageSelect && probability) {
        var defaults = { Qualification: 20, Proposal: 50, Negotiation: 75, Won: 100, Lost: 0 };
        var lastDefault = defaults[stageSelect.value];
        stageSelect.addEventListener('change', function () {
            var next = defaults[stageSelect.value];
            var closed = stageSelect.value === 'Won' || stageSelect.value === 'Lost';
            var untouched = probability.value === '' || Number(probability.value) === lastDefault;
            if (next !== undefined && (closed || untouched)) {
                probability.value = next;
                if (window.jQuery) { window.jQuery(probability).valid && window.jQuery(probability).valid(); }
            }
            lastDefault = next;
        });
    }
})();
