/* Dashboard charts (Chart.js). Data is rendered by the server from records the user is allowed to see. */
(function () {
    'use strict';
    if (!window.Chart || !window.dashboardData) { return; }

    var data = window.dashboardData;
    var ink = '#1d2b28', muted = '#66736f', grid = '#e4e8e3';
    var inr = function (v) { return '\u20B9' + Number(v).toLocaleString('en-IN'); };
    var compact = function (v) {
        if (v >= 10000000) { return '\u20B9' + (v / 10000000).toFixed(1).replace(/\.0$/, '') + ' Cr'; }
        if (v >= 100000) { return '\u20B9' + (v / 100000).toFixed(1).replace(/\.0$/, '') + ' L'; }
        if (v >= 1000) { return '\u20B9' + (v / 1000).toFixed(0) + 'K'; }
        return '\u20B9' + v;
    };

    Chart.defaults.font.family = '"IBM Plex Sans", system-ui, sans-serif';
    Chart.defaults.color = muted;

    var leadColors = { New: '#4f8fc0', Contacted: '#e0a24a', Qualified: '#3e8e8a', Lost: '#b3382c', Converted: '#2f7d4f' };
    var stageColors = { Qualification: '#8cc2b0', Proposal: '#3e8e8a', Negotiation: '#e0a24a', Won: '#2f7d4f', Lost: '#b3382c' };

    // Leads by status
    new Chart(document.getElementById('leadStatusChart'), {
        type: 'bar',
        data: {
            labels: data.leadStatus.labels,
            datasets: [{
                label: 'Leads',
                data: data.leadStatus.values,
                backgroundColor: data.leadStatus.labels.map(function (l) { return leadColors[l] || '#999'; }),
                borderRadius: 4
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: grid } },
                x: { grid: { display: false }, ticks: { color: ink } }
            }
        }
    });

    // Opportunity pipeline (amount per stage, count in the tooltip)
    new Chart(document.getElementById('pipelineChart'), {
        type: 'bar',
        data: {
            labels: data.pipeline.labels,
            datasets: [{
                label: 'Amount',
                data: data.pipeline.values,
                backgroundColor: data.pipeline.labels.map(function (l) { return stageColors[l] || '#999'; }),
                borderRadius: 4
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function (ctx) {
                            var count = data.pipeline.counts[ctx.dataIndex];
                            return inr(ctx.parsed.x) + ' (' + count + ' ' + (count === 1 ? 'deal' : 'deals') + ')';
                        }
                    }
                }
            },
            scales: {
                x: { beginAtZero: true, grid: { color: grid }, ticks: { callback: compact } },
                y: { grid: { display: false }, ticks: { color: ink } }
            }
        }
    });

    // Monthly sales (won amount per month)
    new Chart(document.getElementById('monthlySalesChart'), {
        type: 'bar',
        data: {
            labels: data.monthly.labels,
            datasets: [{
                label: 'Won amount',
                data: data.monthly.values,
                backgroundColor: '#3e8e8a',
                borderRadius: 4
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function (ctx) {
                            var count = data.monthly.counts[ctx.dataIndex];
                            return inr(ctx.parsed.y) + ' (' + count + ' won)';
                        }
                    }
                }
            },
            scales: {
                y: { beginAtZero: true, grid: { color: grid }, ticks: { callback: compact } },
                x: { grid: { display: false } }
            }
        }
    });
})();
