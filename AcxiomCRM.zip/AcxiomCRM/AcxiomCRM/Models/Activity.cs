using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class Activity : IAssignable
{
    public int ActivityId { get; set; }

    public ActivityType ActivityType { get; set; }

    [Required, StringLength(150)]
    public string Subject { get; set; } = string.Empty;

    [StringLength(1000)]
    public string? Description { get; set; }

    public DateTime ActivityDate { get; set; }

    public int? CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public int? LeadId { get; set; }
    public Lead? Lead { get; set; }

    public ActivityStatus Status { get; set; } = ActivityStatus.Planned;

    [Required]
    public string AssignedTo { get; set; } = string.Empty;
    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; }

    [Required, StringLength(256)]
    public string CreatedBy { get; set; } = string.Empty;
}
