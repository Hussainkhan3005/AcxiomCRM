using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class Customer : IAssignable
{
    public int CustomerId { get; set; }

    [Required, StringLength(20)]
    public string CustomerCode { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string CustomerName { get; set; } = string.Empty;

    [Required, StringLength(150)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(15)]
    public string Phone { get; set; } = string.Empty;

    [StringLength(150)]
    public string? CompanyName { get; set; }

    [StringLength(250)]
    public string? Address { get; set; }

    [StringLength(100)]
    public string? City { get; set; }

    [StringLength(100)]
    public string? State { get; set; }

    public CustomerStatus Status { get; set; } = CustomerStatus.Active;

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required]
    public string AssignedTo { get; set; } = string.Empty;
    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; }

    [Required, StringLength(256)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime? ModifiedDate { get; set; }

    public ICollection<Opportunity> Opportunities { get; set; } = new List<Opportunity>();
    public ICollection<FollowUp> FollowUps { get; set; } = new List<FollowUp>();
    public ICollection<Activity> Activities { get; set; } = new List<Activity>();
}
