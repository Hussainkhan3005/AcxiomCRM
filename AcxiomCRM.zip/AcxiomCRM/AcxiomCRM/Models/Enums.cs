using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public enum CustomerStatus
{
    Active,
    Inactive,
    Prospect
}

public enum LeadSource
{
    Website,
    Referral,
    [Display(Name = "Cold Call")] ColdCall,
    Email,
    [Display(Name = "Social Media")] SocialMedia,
    Event,
    Advertisement,
    Other
}

public enum LeadStatus
{
    New,
    Contacted,
    Qualified,
    Unqualified,
    Converted,
    Lost
}

public enum LeadPriority
{
    Low,
    Medium,
    High
}

public enum OpportunityStage
{
    Qualification,
    Proposal,
    Negotiation,
    Won,
    Lost
}

public enum OpportunityStatus
{
    Open,
    Won,
    Lost
}

public enum FollowUpType
{
    Call,
    Meeting,
    Email,
    Visit
}

public enum FollowUpStatus
{
    Planned,
    Completed,
    Missed,
    Cancelled
}

public enum ActivityType
{
    Call,
    Meeting,
    Email,
    Task
}

public enum ActivityStatus
{
    Planned,
    Completed,
    Cancelled
}
