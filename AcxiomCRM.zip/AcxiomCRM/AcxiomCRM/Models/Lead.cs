using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcxiomCRM.Models;

public class Lead : IAssignable
{
    public int LeadId { get; set; }

    [Required, StringLength(20)]
    public string LeadCode { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string LeadName { get; set; } = string.Empty;

    [StringLength(150)]
    public string? Email { get; set; }

    [StringLength(15)]
    public string? Phone { get; set; }

    [StringLength(150)]
    public string? CompanyName { get; set; }

    public LeadSource Source { get; set; }

    public LeadStatus Status { get; set; } = LeadStatus.New;

    public LeadPriority Priority { get; set; } = LeadPriority.Medium;

    public decimal ExpectedValue { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required]
    public string AssignedTo { get; set; } = string.Empty;
    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; }

    [Required, StringLength(256)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime? ModifiedDate { get; set; }

    // Conversion tracking
    public int? ConvertedCustomerId { get; set; }
    public Customer? ConvertedCustomer { get; set; }
    public int? ConvertedOpportunityId { get; set; }
    public DateTime? ConvertedDate { get; set; }

    public ICollection<FollowUp> FollowUps { get; set; } = new List<FollowUp>();
    public ICollection<Activity> Activities { get; set; } = new List<Activity>();

    [NotMapped]
    public bool IsOpen => Status is LeadStatus.New or LeadStatus.Contacted or LeadStatus.Qualified;
}
