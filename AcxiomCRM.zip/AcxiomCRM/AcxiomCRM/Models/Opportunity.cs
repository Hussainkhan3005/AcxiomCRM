using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcxiomCRM.Models;

public class Opportunity : IAssignable
{
    public int OpportunityId { get; set; }

    [Required, StringLength(150)]
    public string OpportunityName { get; set; } = string.Empty;

    public int CustomerId { get; set; }
    public Customer? Customer { get; set; }

    /// <summary>The lead this opportunity originated from (optional).</summary>
    public int? LeadId { get; set; }
    public Lead? Lead { get; set; }

    public decimal Amount { get; set; }

    public OpportunityStage Stage { get; set; } = OpportunityStage.Qualification;

    /// <summary>Win probability, 0 - 100.</summary>
    public int Probability { get; set; }

    public DateTime ExpectedCloseDate { get; set; }

    /// <summary>Derived from Stage: Open / Won / Lost.</summary>
    public OpportunityStatus Status { get; set; } = OpportunityStatus.Open;

    [StringLength(100)]
    public string? Source { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }

    [Required]
    public string AssignedTo { get; set; } = string.Empty;
    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; }

    [Required, StringLength(256)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime? ModifiedDate { get; set; }

    public DateTime? ClosedDate { get; set; }

    public ICollection<FollowUp> FollowUps { get; set; } = new List<FollowUp>();

    /// <summary>Weighted pipeline value = Amount x Probability / 100.</summary>
    [NotMapped]
    public decimal WeightedAmount => Math.Round(Amount * Probability / 100m, 2);
}
