using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

/// <summary>
/// Append-only audit record. The DbContext refuses to update or delete these rows.
/// Never stores passwords, hashes, tokens or other secrets.
/// </summary>
public class AuditLog
{
    public long AuditLogId { get; set; }

    [StringLength(450)]
    public string? UserId { get; set; }

    [StringLength(256)]
    public string? UserName { get; set; }

    [Required, StringLength(50)]
    public string Action { get; set; } = string.Empty;

    /// <summary>Module / entity, e.g. Customer, Lead, Account, User.</summary>
    [Required, StringLength(100)]
    public string EntityName { get; set; } = string.Empty;

    [StringLength(100)]
    public string? RecordId { get; set; }

    public string? OldValue { get; set; }

    public string? NewValue { get; set; }

    [Required, StringLength(20)]
    public string Result { get; set; } = "Success";

    [StringLength(500)]
    public string? Details { get; set; }

    public DateTime CreatedDate { get; set; }

    [StringLength(64)]
    public string? IpAddress { get; set; }
}
