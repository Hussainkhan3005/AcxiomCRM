using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcxiomCRM.Models;

public class FollowUp : IAssignable
{
    public int FollowUpId { get; set; }

    public int? CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public int? LeadId { get; set; }
    public Lead? Lead { get; set; }

    public int? OpportunityId { get; set; }
    public Opportunity? Opportunity { get; set; }

    public DateTime FollowUpDate { get; set; }

    [Required, StringLength(150)]
    public string Subject { get; set; } = string.Empty;

    public FollowUpType FollowUpType { get; set; }

    [StringLength(1000)]
    public string? Remarks { get; set; }

    public FollowUpStatus Status { get; set; } = FollowUpStatus.Planned;

    [Required]
    public string AssignedTo { get; set; } = string.Empty;
    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; }

    [Required, StringLength(256)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime? CompletedDate { get; set; }

    [NotMapped]
    public bool IsOverdue => Status == FollowUpStatus.Planned && FollowUpDate < DateTime.Now;

    [NotMapped]
    public string RelatedTo =>
        Opportunity?.OpportunityName
        ?? Customer?.CustomerName
        ?? Lead?.LeadName
        ?? "-";
}
