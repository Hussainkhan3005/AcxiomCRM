namespace AcxiomCRM.Models;

/// <summary>
/// A CRM record that is owned by (assigned to) a user.
/// Used to apply row-level authorization: Sales Executives see their own records,
/// Managers see their team's records, Admins see everything.
/// </summary>
public interface IAssignable
{
    string AssignedTo { get; }
}
