using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace AcxiomCRM.Models;

/// <summary>
/// Application user. Extends ASP.NET Core Identity's user, so password hashing,
/// lockout counters, security stamps and roles are all framework-managed.
/// </summary>
public class ApplicationUser : IdentityUser
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    /// <summary>The manager a Sales Executive reports to (defines a Manager's "team").</summary>
    public string? ManagerId { get; set; }

    public ApplicationUser? Manager { get; set; }
}
