# Requirements map

Where each requirement from the *AcxiomCRM Complete Project Assignment* document is implemented. Use this when you explain the project.

## Architecture (document section 3 and 17.17)

| Layer | Location |
|---|---|
| Presentation | `Views/`, `wwwroot/`, `Controllers/` (MVC) |
| Application | `Services/`, `Dtos/`, `ViewModels/` |
| Domain / business rules | `Services/*Service.cs`, `Common/Workflows.cs`, `Common/ValidationRules.cs` |
| Data access | `Data/ApplicationDbContext.cs` (EF Core, parameterized queries only) |
| Security | `Program.cs`, `Services/AccountService.cs`, `Services/CurrentUserService.cs` |
| Cross-cutting | `Services/AuditService.cs`, `Common/ServiceResult.cs` |

Request flow: Controller -> Service (validates, checks scope, applies business rules, audits) -> DbContext. Controllers contain no business logic.

## Modules (document sections 2, 4 and 17.2)

| Module | Files |
|---|---|
| Authentication (login, register, logout, access control) | `Controllers/AccountController.cs`, `Services/AccountService.cs`, `Views/Account/` |
| Dashboard | `Controllers/DashboardController.cs`, `Services/DashboardService.cs`, `Views/Dashboard/Index.cshtml`, `wwwroot/js/dashboard.js` |
| Customer management | `Controllers/CustomersController.cs`, `Services/CustomerService.cs`, `Views/Customers/` |
| Lead management and conversion | `Controllers/LeadsController.cs`, `Services/LeadService.cs` (`ConvertAsync`), `Views/Leads/` |
| Opportunity and pipeline | `Controllers/OpportunitiesController.cs`, `Services/OpportunityService.cs`, `Views/Opportunities/` (incl. `Pipeline.cshtml`) |
| Follow-up | `Controllers/FollowUpsController.cs`, `Services/FollowUpService.cs`, `Views/FollowUps/` |
| Activity (call, meeting, email, task) | `Controllers/ActivitiesController.cs`, `Services/ActivityService.cs`, `Views/Activities/` |
| User and role management | `Controllers/UsersController.cs`, `Controllers/RolesController.cs`, `Views/Users/`, `Views/Roles/` |
| Audit log | `Services/AuditService.cs` (write), `Services/AuditLogService.cs` (read), `Controllers/AuditLogsController.cs` |
| REST API | `Controllers/Api/` |
| Reports | `Services/ReportService.cs`, `ViewModels/ReportViewModels.cs`, `Controllers/ReportsController.cs`, `Views/Reports/` |

## Database (17.3, 17.4)

| Requirement | Implementation |
|---|---|
| Customer, Lead, Opportunity, FollowUp, Activity, AuditLog tables with the listed fields | `Models/*.cs`, configured in `Data/ApplicationDbContext.cs` |
| No custom password table; use ASP.NET Core Identity | `ApplicationUser : IdentityUser` (`Models/ApplicationUser.cs`), `AddIdentity` in `Program.cs` |
| Hashes never exposed | UI and API only use DTOs/view models; `AuditSnapshot` skips sensitive properties |
| Email and phone uniqueness | unique indexes in `ApplicationDbContext` plus explicit checks in `CustomerService.ValidateBusinessRulesAsync` |

## Validation (sections 5, 17.5 to 17.8)

| Rule | Client side | Server side |
|---|---|---|
| Required, length | `[Required]`, `[StringLength]` -> unobtrusive validation, `maxlength` attributes | same attributes re-run by `ServerValidator` in every service, plus `ModelState` in controllers |
| Email format | `ValidationRules.EmailPattern` | same attribute |
| Phone format (10-digit Indian mobile) | `ValidationRules.PhonePattern` | same attribute |
| Amount > 0, probability 0-100 | `[Range]` | `OpportunityService.ValidateBusinessRulesAsync` |
| Close date not in the past (active only) | `[DateNotInPast]` + `wwwroot/js/validation.js` adapter | attribute plus explicit check, skipped for Won/Lost |
| Follow-up date not before today (new/planned) | same attribute | `FollowUpService.ValidateBusinessRulesAsync` |
| Lead status from a valid set | select lists built from enums | `LeadService.ValidateEnums` and `LeadWorkflow` transitions |
| Duplicate customer | n/a | `CustomerService` (email, phone, and name + company) |
| Foreign keys / tampering | n/a | referenced customers, leads and opportunities must exist **and** be in the user's scope |

Shared rules and messages: `Common/ValidationRules.cs`.

## Security (sections 6, 14, 17.9)

| Requirement | Implementation |
|---|---|
| Password hashing | Identity's PBKDF2 hasher (`AddIdentity`) |
| Password policy | `Program.cs` (length 8, upper, lower, digit, symbol); mirrored in view-model regex for instant feedback |
| Account lockout | `Program.cs` (5 failures, 15 minutes); `AccountService.SignInAsync`; Admin unlock in `UsersController.Unlock` |
| Role-based, server-side authorization | fallback policy requiring login (`Program.cs`), `[Authorize(Roles=...)]` on controllers/actions, row-level filter `WhereVisible` |
| Anti-forgery | `[ValidateAntiForgeryToken]` on every state-changing MVC action; antiforgery cookie `SameSite=Strict` |
| SQL injection | EF Core LINQ and `EF.Functions.Like` with parameters; no string-built SQL anywhere |
| Secure cookies | `HttpOnly`, `SameSite=Lax`, sliding expiry (`Program.cs`) |
| Login throttling | rate limiter policy `login` on web and API login |
| No stack traces to users | exception handler and status-code pages in `Program.cs`; API returns generic JSON |
| Security headers | `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` in `Program.cs` |
| Open-redirect protection | `Url.IsLocalUrl` checks on `returnUrl` |
| Account enumeration | one generic login error message |
| Deactivated / role-changed users | security stamp rotation and 1-minute stamp validation |
| CSV formula injection | `ReportService.CsvValue` |

## Audit logging (4.9, 17.16)

`Services/AuditService.cs` writes `UserId`, user name, action, entity, record id, old and new values (JSON snapshots), result, details, timestamp and IP address. Logged events: login, failed login, lockout, logout, register, create, update, delete, status and stage changes, lead conversion, follow-up complete / missed / reschedule, role change, activate / deactivate, unlock, password reset and change. Passwords and hashes are never logged. Append-only: `ApplicationDbContext.ProtectAuditLog` throws on any attempt to update or delete an audit row, and the UI has no edit or delete actions.

## Dashboard (4.3, 17.11, 17.12)

`DashboardService` builds the cards (total customers, total leads, open leads, total / open / won / lost opportunities, pipeline value, weighted pipeline, pending follow-ups) and the three Chart.js datasets (lead status, opportunity pipeline, monthly sales) from scoped queries. Date filters: all time, today, this week, this month, custom range. The Admin sees an extra security panel.

## Search and filtering (17.13)

Customers: name, email, phone, company. Leads: name, company, status, assigned user. Opportunities: name, customer, stage, status. Follow-ups: date range, status, assigned user, related record. Activities: type, date range, status, assigned user. All lists have sorting and paging.

## REST API (4.10, 10, 17.14)

`Controllers/Api/`. DTOs in `Dtos/`. Input validation by `[ApiController]` model validation plus service validation. Authorization on every endpoint (fallback policy, plus role attributes on deletes and reports). Error bodies use `ProblemDetails` and never include stack traces.

## Evaluation criteria (17.17)

| Area | Where |
|---|---|
| CRUD | all modules above (hard delete for Admin/Manager, status changes or cancel for sales users) |
| Business rules | Opportunity, Lead and FollowUp services, `Common/Workflows.cs` |
| Authentication | `AccountController`, `AccountService` |
| Authorization | attributes + `CurrentUserService` scope |
| Dashboard | `DashboardService`, `Views/Dashboard` |
| Search | list views and services |
| REST API | `Controllers/Api` |
| Audit | `AuditService`, `Views/AuditLogs` |
| Architecture | folder layout above |
| Security | table above |
