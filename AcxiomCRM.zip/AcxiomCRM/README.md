# AcxiomCRM

A role-based CRM web application built with **ASP.NET Core 8 MVC**, **Entity Framework Core**, **ASP.NET Core Identity**, **Bootstrap 5** and **Chart.js**. It covers the full lead-to-deal lifecycle: leads, customers, opportunities, follow-ups, activities, users and roles, audit log, reports and a secured REST API.

> **Build status:** this code was written without access to the .NET SDK, so it has not been compiled or run by its author. Run `dotnet build` first. If anything fails, copy the exact error message and ask for a fix; most issues of this kind are small (a missing `using`, a package version).

## 1. Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0). Check with `dotnet --version`; it should start with `8.`.
- An internet connection when you open the site, because Bootstrap, Bootstrap Icons, jQuery, jQuery Validation, Chart.js and the IBM Plex Sans font load from CDNs.
- Optional: SQL Server or LocalDB. The default database is **SQLite**, which needs nothing installed.
- Visual Studio 2022 (17.8+) or VS Code with the C# Dev Kit.

If you only have .NET 9 installed, either install the .NET 8 SDK, or change `<TargetFramework>` to `net9.0` and the `8.0.8` package versions in `AcxiomCRM.csproj` to `9.0.0`.

## 2. Run it

```bash
cd AcxiomCRM/AcxiomCRM
dotnet restore
dotnet run --launch-profile https
```

Open `https://localhost:7080` (or `http://localhost:5080` with `--launch-profile http`). If the browser warns about the development certificate, run `dotnet dev-certs https --trust` once.

On first start the app creates the database, the three roles, four demo users and sample customers, leads, opportunities, follow-ups and activities. Delete `AcxiomCRM.db` to reset everything.

In Visual Studio: open `AcxiomCRM.sln` and press F5.

### Demo accounts (development only)

| Role | Email | Password |
|---|---|---|
| Admin | admin@acxiomcrm.com | Admin@123 |
| Manager | manager@acxiomcrm.com | Manager@123 |
| Sales Executive | sales1@acxiomcrm.com | Sales@123 |
| Sales Executive | sales2@acxiomcrm.com | Sales@123 |

Both sales executives report to the manager. The login page shows these accounts only in the Development environment. Passwords come from `appsettings.Development.json`. **Before any real deployment**, set `Seed:Enabled` to `false` in `appsettings.json` and create real accounts.

## 3. Use SQL Server instead of SQLite

In `appsettings.json`:

```json
"DatabaseProvider": "SqlServer"
```

Adjust `ConnectionStrings:SqlServer` if you do not use LocalDB. Delete any existing SQLite file. The database is created automatically on start (`EnsureCreated`). To switch to EF migrations later, run `dotnet ef migrations add Initial` and replace `EnsureCreatedAsync()` in `Data/DbSeeder.cs` with `MigrateAsync()`.

## 4. Roles at a glance

| | Admin | Manager | Sales Executive |
|---|---|---|---|
| Records visible | everything | self + direct reports | own records only |
| Create / edit CRM records | yes | team | own |
| Delete CRM records | yes | team | no |
| Users | full | view team | no |
| Roles page | yes | no | no |
| Audit log | all events | team business events | no |
| Reports | all 8 | 7 (not Audit) | 5 personal reports |

Scope is enforced in the service layer (`ICurrentUserService.GetVisibleUserIdsAsync` plus the `WhereVisible` query filter), so changing an ID in a URL or request returns 404. Menu items are only hidden as a convenience.

## 5. REST API

Swagger UI is at `/swagger` (Development). Authentication is cookie-based:

```bash
# sign in and keep the cookie (-k accepts the dev certificate)
curl -k -c jar.txt -H "Content-Type: application/json" \
  -d '{"userNameOrEmail":"manager@acxiomcrm.com","password":"Manager@123"}' \
  https://localhost:7080/api/auth/login

curl -k -b jar.txt https://localhost:7080/api/customers
curl -k -b jar.txt https://localhost:7080/api/reports/pipeline
```

In Swagger UI, run `POST /api/auth/login` first; the browser then sends the cookie on later calls.

| Method | Endpoint | Notes |
|---|---|---|
| POST | /api/auth/login, /api/auth/logout | login is rate limited; GET /api/auth/me |
| GET, POST | /api/customers | search and paging via query string |
| GET, PUT, DELETE | /api/customers/{id} | DELETE is Admin/Manager; 409 if the customer has opportunities |
| GET, POST, PUT, DELETE | /api/leads, /api/leads/{id} | POST /api/leads/{id}/convert |
| GET, POST, PUT, DELETE | /api/opportunities, /api/opportunities/{id} | |
| GET, POST | /api/followups, /api/followups/{id} | POST /api/followups/{id}/complete |
| GET | /api/reports/pipeline | Admin/Manager only |

Status codes used: 200, 201, 204, 400 (validation), 401 (not signed in), 403 (role not allowed or account locked), 404 (missing or outside your scope), 409 (conflicts such as duplicate email), 429 (rate limit).

## 6. Test it: the 14-step acceptance scenario

1. Open `/Customers` while signed out. You are redirected to the sign-in page.
2. Register at `/Account/Register` (or sign in with a demo account). You land on the dashboard.
3. Create a customer with email `abc` and phone `123`. Inline errors appear and the form does not submit.
4. In the browser developer tools, remove the `data-val` attributes (or disable JavaScript) and submit again. The **server** returns the same errors.
5. Create an opportunity with amount `0`. Rejected: "Opportunity Amount must be greater than 0."
6. Use probability `101`. Rejected: "Probability must be between 0 and 100."
7. Use a close date of yesterday. Rejected: "Expected Close Date cannot be in the past."
8. Schedule a follow-up for yesterday. Rejected: "Follow-up date cannot be earlier than today."
9. Sign in as `sales1`. You see only your own customers, leads and opportunities, and no Administration menu. Opening `/Users` shows Access denied.
10. Sign in as `manager`. You see your team's data, the pipeline board, team reports, and a read-only team list.
11. Sign in as `admin`. Users, Roles and the full audit log are available.
12. Create, edit and delete a record (as Admin or Manager), then open **Audit log**. Each action has an entry, with before/after values and your IP address.
13. While signed in, open `/api/customers`. You get authorized JSON. Signed out, you get `401`.
14. Open the dashboard. KPI cards, the pipeline strip and the three Chart.js charts show data for your scope.

Extra checks: enter a wrong password 5 times to trigger lockout (an Admin can unlock the user from the Users page); convert a Qualified lead; try to move a Won opportunity to another stage (rejected).

## 7. Project structure

```
AcxiomCRM/
  Common/        roles, constants, validation rules and attribute, workflows, paging, helpers
  Models/        entities (Customer, Lead, Opportunity, FollowUp, Activity, AuditLog, ApplicationUser)
  Data/          ApplicationDbContext, DbSeeder
  Dtos/          request/response DTOs and filter objects (shared by MVC and API)
  Services/      business logic: one service per module, plus audit, scope, reports
  ViewModels/    view-specific models
  Controllers/   MVC controllers; Controllers/Api for REST
  Views/         Razor views
  wwwroot/       css/site.css, js/site.js, validation.js, dashboard.js
  Program.cs     composition root: Identity, cookies, authorization, rate limiting, Swagger
```

See `REQUIREMENTS_MAP.md` for where each requirement from the assignment document is implemented.

## 8. Known limits

- Password reuse prevention (recommended, not mandatory in the spec) is not implemented.
- Reports export as CSV, not Excel or PDF.
- Self-registered accounts get the Sales Executive role; an Admin can change it.
- The API uses the same cookie authentication as the website (no JWT). Cookies use `SameSite=Lax`, and state-changing website forms use anti-forgery tokens.
